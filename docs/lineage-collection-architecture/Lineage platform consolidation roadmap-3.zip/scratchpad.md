# Consolidation deliverables — plan

Inputs: Approach A = "AWS Lineage Collection Platform" (Batch analyzers, Neptune/OpenSearch projections, fenced publication, two-axis confidence, runtime evidence sessions). Approach B = "Throughline" (two-plane serverless, zero-touch trigger matrix, Fargate extractors, PR gate, deployment promotion, Aurora core, Kafka path).

Constraints: Neptune mandated. Fargate is current engineering direction. 5 months (Aug–Dec 2026), 15 engineers. MVP must prove end-to-end: event → extraction → graph → review UI.

Verdict: complementary. B wins collection-plane shape, triggers, extraction compute, dev feedback. A wins governance, evidence/confidence, publication protocol, graph tier + recovery, scale gates.

## Deck title sequence (noun-phrase style)
1. Lineage Platform Consolidation
2. Two Approaches on the Table
3. Evaluation Scorecard
4. What Each Approach Contributes
5. Consolidated Architecture
6. Key Technical Decisions
7. Five-Month Roadmap
8. MVP — End-to-End Thin Slice
9. Phase 1 — Scale & Coverage
10. Phase 2 — Governance & Hardening
11. Team of Fifteen
12. Risks & Launch Gates

## Roadmap
- MVP W1–8 (Aug–Sep): receiver→EB→SQS→IncrementalCollection SFN→Fargate Tier-1 extractor→S3/DDB→proposal→minimal review UI→fenced publish to Neptune. Pilot ~100 repos. Gate: push→queryable <1h, zero manual invocation.
- P1 W9–17 (Oct–Nov): classification taxonomy, BaselineCollection Distributed Map 10k repos, priority lanes, Tier-2 tree-sitter + Tier-3 Bedrock cache, two-axis confidence, OpenSearch, PRGate observe→warn, DeploymentPromotion. Gates: 10k/12h, p95 incr 30min, PR p95 <30s.
- P2 W18–21 (Dec): runtime evidence sessions, nightly reconciliation + divergence, calibration corpus, PRGate block ramp, DR warm standby (RPO 15m/RTO 4h), load-test launch gates (100/s, 2s p95 hop, 60s publish→query).

## Team (15)
Intake & Workflows 3 · Extraction 4 · Graph & Publication 3 · Review Experience 2 · Platform & Reliability 2 · TL/Architect 1.

Palette: paper #f7f5f0 / ink #191c20, A=steel teal #2f6b80, B=rust #b05c2a. IBM Plex Sans + Mono.
