repo: awslabs/aws-icons-for-plantuml
branch: main

## Last sync
date: 2026-08-03T03:26:13Z
### Updated in this project
- Copied 23 official AWS service icons (dist/**.png) into icons/ for the architecture diagram decks

## Screen map
| Screen | Repo files |
| --- | --- |
| Architecture Diagrams v2.dc.html (all slides) | dist/**/[Service].png → icons/*.png |
