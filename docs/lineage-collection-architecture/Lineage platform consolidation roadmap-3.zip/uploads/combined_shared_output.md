# coding-agent-handoff.md

# Coding-Agent Implementation Handoff

**Status:** Normative execution contract for implementation agents
**Start here after:** README, system context, contract catalog, state/error model,
test strategy, integration matrix and implementation sequence

## 1. Mission and Completion Standard

Implement the approved AWS lineage collection application exactly as specified
by C01-C18 and the shared contracts. The goal is a deployable, secure, tested
vertical system, not a set of disconnected service stubs.

A component is complete only when:

- every P0 requirement has code and a passing component test;
- its versioned contracts/examples and compatibility cases pass;
- every touching INT row passes all six boundary dimensions in the required
  deployed environment;
- applicable E2E, security/privacy, accessibility, load, chaos and DR cases pass;
- logs/metrics/traces/audit/alarms/runbooks and cleanup are operational; and
- a signed immutable TestEvidenceManifest links the exact build and effects.

Do not report success from compilation, unit tests, a workflow SUCCEEDED state,
an HTTP 200, a manually inspected graph or an unlinked CI job.

## 2. Authority and Requirement Navigation

Use this decision order:

1. Component-package design and this PRD package.
2. Approved AWS architecture.
3. Element-level lineage v2 analyzer semantics.
4. Throughline platform PRD product language.
5. Earlier source material for context only.

For each implementation slice, write the requirement IDs in the change
description, open the component's Interfaces, Failure Semantics, Component Test
Matrix, Integration Obligations and Definition of Done, then follow the shared
traceability row. A stricter privacy, security, idempotency, immutability,
versioning, completeness or visibility rule wins until documents are reconciled.

## 3. Approved Technology and Ownership

- **TypeScript 5** owns control-plane services, APIs, web application, contract
  generation where practical, conditional state transitions and infrastructure.
- **Python 3.12** owns heavy analyzers/parsers, verification/reconciliation,
  graph export/projection and large report workers.
- **AWS CDK v2** with TypeScript owns all AWS infrastructure. No manually
  configured production dependency is an accepted implementation.
- JSON Schema 2020-12 and OpenAPI 3.1 own JSON/API contracts. OpenLineage plus
  governed versioned facets owns external lineage interchange.
- pnpm workspace owns JavaScript/TypeScript dependencies; uv with a committed
  lock owns Python environments. Tool versions are pinned at repository root.
- Container images are minimal, nonroot, digest-pinned, signed, scanned and
  recorded in SBOM/provenance.
- Amazon EventBridge routes, SQS buffers, Step Functions Standard coordinates,
  Batch analyzes, S3 preserves, DynamoDB controls, Neptune traverses,
  OpenSearch discovers, API Gateway/web presents and the user approves.

Do not replace an approved AWS service or introduce another language, database,
message bus, orchestration engine, model gateway, generic plugin/tool system or
client framework without an architecture decision and updated PRD/contracts/
tests. A library choice inside the approved boundary is allowed when pinned,
licensed, scanned and consistent with repository conventions.

## 4. Repository Layout

    apps/
      lineage-web/
    contracts/
      schemas/
      openapi/
      openlineage/
      examples/
    packages/
      contracts-ts/
      contracts-py/
      evidence-client/
      analyzer-sdk/
      api-client/
      ui-components/
      telemetry-contract/
      test-support/
    services/
      contract-registry/
      identity-registry/
      source-adapters/
      inventory-builder/
      event-normalizer/
      eligibility/
      context-index/
      run-controller/
      run-timeline/
      native-ingest/
      evidence-registry/
      cache-index/
      confidence-policy/
      proposal-review/
      review-assignment/
      ci-drift/
      artifact-binder/
      deployment-lineage-controller/
      publication-controller/
      query-api/
      runtime-session/
      agent-task-builder/
      agent-tools/
      opaque-control/
      reconciliation-controller/
      operations-api/
    workers/
      native-*/
      deterministic-*/
      agent-resolver/
      opaque-aggregate/
      reconciliation/
      verification/
      graph-exporter/
      neptune-projector/
      opensearch-projector/
      projection-reconciler/
    sidecars/
      runtime-evidence/
    source-local/
      opaque-collector/
    workflows/
      redrive/
      regional-recovery/
    infra/
      bin/
      lib/constructs/
      lib/stacks/
    policies/
    dashboards/
    docs/runbooks/
    tests/
      fixtures/lineage/
      unit/
      contract/
      integration/
      e2e/
      accessibility/
      security/
      operations/
      load/
      chaos/
      dr/

Keep business logic in pure packages/modules with explicit ports. Lambda/Batch/
Step Functions/API/SDK handlers adapt transports; they do not redefine the
domain. Do not create a generic shared package for unrelated helpers. A shared
package needs an owner, stable contract and at least two real consumers.

## 5. Component-to-Code Map

| Component | Primary code targets | Runtime |
|---|---|---|
| C01 | contracts, contracts-ts/py, contract-registry, identity-registry | TypeScript plus generated Python |
| C02 | source-adapters, inventory-builder | TypeScript control; bounded Python adapter only when SDK requires |
| C03 | event-normalizer and EventBridge/SQS/archive constructs | TypeScript |
| C04 | eligibility pure evaluator/registry | TypeScript |
| C05 | context-index/dependency/determinant workers | TypeScript control plus Python for large index jobs |
| C06 | run-controller/timeline and Step Functions/Batch constructs | TypeScript |
| C07 | native-ingest and Spark/dbt/Airflow parsers | TypeScript intake; Python workers |
| C08 | deterministic analyzers and analyzer SDK | Python workers; TypeScript control |
| C09 | task builder/tools/resolver/gateway/cache | Python resolver/tools; TypeScript admission/state |
| C10 | opaque control/source-local collector/aggregate | TypeScript control; approved source-local/Python worker |
| C11 | runtime session, sidecar, validator pipeline | TypeScript control; sidecar runtime selected per supported app |
| C12 | evidence-registry/cache-index/client and storage constructs | TypeScript |
| C13 | reconciliation/verification/confidence policy | Python workers; TypeScript policy/control |
| C14 | CI drift/binder/deployment controller | TypeScript; Python deterministic diff if reused |
| C15 | proposal/review/assignment/corpus control | TypeScript |
| C16 | publication controller and graph/search projection | TypeScript control; Python export/project workers |
| C17 | query-api, API client, UI components/web | TypeScript |
| C18 | security/observability IaC, operations/reconcile/redrive/recovery | TypeScript control/IaC; Python large reconciliation |

## 6. Contract-First and Test-Driven Loop

**Contract-first** and **test-driven** are required for every feature/fix:

1. Select the smallest requirement/test/INT slice that produces one observable
   business behavior.
2. Add/update schema, valid/invalid examples, compatibility matrix and ownership.
3. Add a failing component test and, for a boundary, producer/consumer contract
   test. Confirm failure is for the intended missing behavior.
4. Implement the pure domain/state logic; run fast unit/property/golden tests.
5. Implement persistence/transport adapter with conditional/idempotent effects.
6. Add failure, duplicate/order, timeout/recovery, privacy/security and telemetry
   tests before calling the boundary complete.
7. Deploy the slice to the phase's ephemeral AWS environment; run INT cases,
   fault injection, cleanup and evidence verification.
8. Run all affected upstream/downstream tests and applicable E2E gate.
9. Commit one coherent slice with requirement/test IDs and evidence link.

Never edit a golden solely to make a failed test pass. Explain the semantic
change, version the fixture/contract and obtain affected owner approval.

## 7. Canonical Data and Contract Rules

Every durable/event/API artifact:

- carries schema ID/semantic version and immutable business identity;
- uses additionalProperties false at privacy-sensitive boundaries;
- distinguishes absent from empty; missing identity never becomes an empty
  idempotency key;
- carries or references applicable common correlation fields;
- passes large content by immutable S3 URI, version and SHA-256 checksum;
- has producer/consumer owners, compatibility policy and valid/invalid examples;
- uses canonical UTC timestamps plus explicit source/event/processing meaning;
- records policy/analyzer/context/artifact/effective versions affecting result;
- never embeds repository archives, payload values, credentials or model
  transcript into workflow/event/log state.

Use C01 libraries for URNs/canonical serialization/checksum. Do not independently
format an identity in a service. Validate on both producer and consumer; a
consumer must not trust a producer merely because both are internal.

## 8. State, Idempotency and Failure Implementation

Model transitions as explicit pure functions returning next state, durable
effects and audit/telemetry intents. Persist with expected state/version,
conditional writes or one transaction. Include attempt and immutable operation
identity; never use last-write-wins for review, publication, policy or recovery.

At-least-once delivery is normal. Define idempotency from immutable business
identity in the component PRD. Identical duplicates return/reuse the prior
effect. Same identity with different checksum/version is CONFLICT and preserves
both claims for quarantine/review; it is never silently overwritten.

Implement the shared classes:

- TRANSIENT: bounded exponential backoff plus jitter, max attempt/time and
  idempotent checkpoint.
- DETERMINISTIC_INVALID: no repeated retry; quarantine with reason/owner/action.
- INCOMPLETE: preserve partial evidence and coverage gap; no false success or
  confidence promotion.
- CONFLICT: preserve competing versions/evidence; conditional resolution/review.
- POISON_REPEATED: DLQ after bounded attempts; governed plan/redrive/reconcile.

Finally/cleanup behavior is part of the state machine. Cancellation, timeout,
host loss and redrive must disable runtime flags, close sessions, release leases,
persist checkpoints and reconcile orphans as specified.

## 9. AWS Implementation Guardrails

- EventBridge rules route normalized envelopes; they are not a work backlog.
- SQS Standard queue delivery can duplicate/reorder. Separate priority lanes,
  DLQs and visibility/heartbeat policy; never assume FIFO unless approved.
- Step Functions Standard holds IDs, small state and immutable references only.
  Use callbacks for external review and Distributed Map for measured fan-out.
- Lambda performs bounded control actions; repository checkout, parsers, graph
  export and large reconciliation run in Batch/approved workers.
- S3 evidence buckets use versioning/KMS/Object Lock where specified. Workload
  roles cannot shorten retention/delete authoritative objects.
- DynamoDB tables use explicit partition/access patterns, conditional state,
  PITR and item-size guard. Do not store large artifacts or scan as a normal API.
- Neptune receives only immutable target-version graph data through C16.
  OpenSearch receives only versioned index builds and atomic alias/watermark.
- IAM is component/stage/environment/resource scoped; private networking and
  endpoint policies apply. Egress uses the approved broker/firewall.
- CloudTrail/application audit is not ordinary debug logging and cannot be
  sampled or deleted by workload roles.

## 10. Security and Privacy by Construction

Before coding a new data path, write:

- data classification and exact allowed fields;
- producer/consumer identities and resource scope;
- encryption key/network/egress/secret path;
- retention/legal hold/deletion and audit;
- negative cross-domain/cross-account/direct-access cases;
- prohibited-data canaries and all sinks to scan.

Production runtime field evidence is denied at AppConfig validation, organization
policy, IAM/resource policy and sidecar/session attestation. No implementation
flag may weaken that. Runtime metadata can change structural confidence only.
Opaque collection is source-local/advisory and never stores raw/reversible
values. Agent tasks are hole-only with bounded facts/tools/citations; repository
text cannot change instructions/policy.

Logs/traces/metrics use safe IDs/hashes and bounded cardinality. Do not log full
events, object bodies, headers/tokens, SQL/source spans, model prompts/results,
fingerprints, signed URLs or authorization policy internals.

## 11. Feature Flags and Rollout

**Feature flags** may:

- canary a new adapter/analyzer/parser by explicit application/domain cohort;
- shadow-compute a result without publishing/enforcing it;
- select a contract-compatible implementation or measured capacity strategy;
- pause optional Lane C/agentic/backfill work during incident/cost pressure;
- expose a C17 route only after its API/security/accessibility gate.

Feature flags must not:

- bypass contract/checksum/identity validation, review/approval, fencing,
  idempotency, G1-G5, evidence ABAC, audit or privacy;
- enable instrumented production runtime evidence;
- silently exclude UNKNOWN/incomplete/conflicting work;
- auto-publish or auto-approve at launch;
- change confidence meaning without policy/version/migration.

Flags have owner, purpose, allowed environment/cohort, default-safe state,
creation/expiry, rollback, alarm and audit. Expiry fails closed. Rollout stages
are local/unit, deployed test tenant, nonserving canary, pilot application,
domain cohort and enterprise; each stage requires prior evidence.

## 12. Local validation commands

The Phase 0 scaffold must implement these stable commands:

    corepack pnpm install --frozen-lockfile
    uv sync --frozen --all-groups
    pnpm format:check
    pnpm lint
    pnpm typecheck
    pnpm test:unit
    pnpm test:contract
    pnpm test:policy
    pnpm cdk:synth
    uv run pytest tests/unit tests/contract
    pnpm validate:docs
    pnpm validate:all

validate:all runs formatting, lint, typecheck, unit, contract, policy, secret/
dependency/license/SBOM, IaC synth and documentation checks without deploying.
Component filters must not change assertions, only selected test IDs.

## 13. Deployed Validation Commands

The test harness must implement:

    pnpm env:create -- --phase=<0-9> --test-run=<id>
    pnpm test:deployed -- --phase=<0-9> --test-run=<id>
    pnpm test:component -- --components=<Cxx-list>
    pnpm test:integration -- --ids=<INT-range/list>
    pnpm test:e2e -- --ids=<E2E-range/list>
    pnpm test:security -- --scope=<scope>
    pnpm test:accessibility
    pnpm test:load -- --profile=<LP-name>
    pnpm test:chaos -- --scope=<scope>
    pnpm test:dr -- --scenario=regional-failover-failback
    pnpm evidence:verify -- --candidate=<build>
    pnpm env:cleanup -- --test-run=<id>
    pnpm env:reconcile -- --test-run=<id>

**Deployed validation commands** require explicit account/Region/profile
confirmation, unique testRunId, cost estimate/budget, approved fault scope and
cleanup trap. They print no secrets. Environment deletion never bypasses Object
Lock; immutable test evidence stays under its approved retention class.

## 14. Environment Assumptions

Required nonproduction topology:

- separate lineage control/compute, evidence/data, application/API, central
  observability/security and integration application accounts;
- isolated primary and warm-standby Regions, Multi-AZ primary managed services,
  private DNS/subnets/endpoints, controlled egress and central audit;
- enterprise SSO/SCIM test identities/ownership/ABAC matrix;
- test integrations for SCM, Test Automation, build/release/deploy, schema/
  catalog, native engines, model gateway, SIEM/on-call and finance;
- service quotas/capacity sufficient for each declared load profile;
- synthetic fixtures only and no connection to production payload sources.

If an external integration is unavailable, implement its versioned port plus
contract emulator and continue local logic, but do not mark the touching INT/E2E
or component complete. Record the dependency as a gate, not a successful mock.

## 15. Commit Cadence and Change Shape

**Commit cadence** is one coherent, reviewable behavior:

1. failing test/contract fixture where useful;
2. minimal implementation plus tests;
3. deployed integration/IaC slice and evidence plumbing;
4. documentation/runbook update.

Small slices may combine these when still reviewable. A commit message names the
component and behavior; the body lists requirement/CT/INT/E2E IDs, migration/
rollback and evidence location. Never mix unrelated refactors, generated
goldens, dependency upgrades and behavior changes.

Before committing:

    git diff --check
    pnpm validate:all
    uv run pytest <affected-python-tests>
    pnpm test:component -- --components=<affected>

Before a phase release, run every phase Validation Command on the same immutable
candidate. Do not rewrite published Git history or delete failed-first evidence.

## 16. Non-negotiable invariants

1. Every trigger/repository/deployment/hole/evidence/proposal/approval has a
   visible durable outcome; none is silently dropped.
2. Every repository/path is included, excluded with reason, mixed or UNKNOWN;
   critical UNKNOWN cannot silently pass baseline.
3. Large payloads use immutable S3 URI/version/checksum, never workflow/event
   bodies.
4. S3 accepted evidence/manifests/labels plus controlled state are authority;
   Neptune/OpenSearch are rebuildable projections.
5. Canonical identities include environment/effective version where meaning
   differs; missing immutable identity quarantines.
6. Deterministic/native evidence is preferred. An LLM sees only a named Hole
   and emits cited result or abstention.
7. Service interaction, OTel or runtime execution alone never proves an
   internal transformation.
8. Structural confidence and derivational confidence remain independent;
   incomplete runtime cannot promote, and sole-LLM/opaque evidence stays capped.
9. Material launch proposals require explicit authorized human approval;
   corrections create immutable versions and bulk accept stays unreviewed.
10. Only C16 with current lease/fencing token and expected prior may activate a
    fully verified immutable graph target.
11. Query responses pin one active graph version and disclose projection
    watermark/lag; bounded traversal is mandatory.
12. Production cannot enable or submit instrumented runtime evidence; no raw
    integration payload or reversible fingerprint is stored.
13. Privacy/security deterministic failures quarantine and audit; they are not
    repeatedly retried.
14. Replays/redrives/recovery are planned, bounded, conditional, idempotent,
    audited and reconciled.
15. Missing/stale/conflicting/incomplete/excluded/unresolved/redacted state is
    explicit in APIs, UI, metrics and timeline.

## 17. Stop and Escalate Conditions

**Stop and escalate** to the named owners before implementation/deployment when:

- two authoritative specifications conflict on identity, evidence semantics,
  confidence, approval, publication, privacy, retention, RPO/RTO or AWS service;
- a required contract has no producer/consumer owner or stable immutable key;
- completion would require weakening a P0 invariant, expected-state check,
  Object Lock, no-payload rule, production hard-deny, ABAC or audit;
- the only solution requires arbitrary model/repository access, generic tools,
  public endpoint, unrestricted egress, wildcard cross-account trust or shared
  admin role;
- an irreversible/destructive migration lacks tested backup/restore/rollback
  and exact target resolution;
- representative load/graph/source behavior differs enough to invalidate the
  approved capacity model or SLO;
- external source API, Region, account, retention, domain SLO tier, graph
  sizing/partition or model choice is not approved and materially changes code;
- a required deployed INT/E2E/DR test cannot run because account/quota/source/
  identity/standby access is absent;
- a security/privacy test finds prohibited content outside quarantine or an
  uncontained production-enable path;
- an expired waiver, critical UNKNOWN, missing owner/runbook or failed recovery
  would be carried into release.

Continue safe contract/unit work when a deployed dependency is blocked, but
label the component incomplete and never fabricate evidence or silently choose
a materially different architecture.

## 18. Review and Pull-Request Checklist

Each change answers:

- Which requirement, CT, INT and E2E IDs change?
- What immutable business identity and idempotency rule apply?
- What exact durable state/effect and forbidden effects were asserted?
- Which contracts/examples/clients and compatibility versions changed?
- What transient, invalid, incomplete, conflict, poison and finally paths pass?
- What least-privilege/data class/network/KMS/egress/retention/audit controls
  changed and which negative tests prove them?
- What metrics/logs/traces/audit/alarms/runbooks/timeline are added?
- What scale/cost/capacity behavior and rollback/migration apply?
- Which deployed test environment and immutable evidence manifest prove it?
- Did cleanup/reconciliation finish with no orphan/active test state?

Reviewers reject vague claims such as supports, handles, resilient, secure,
tested or backwards compatible without the observable proof defined here.

## 19. Final Evidence Checklist

The **Final evidence checklist** for a release candidate contains:

- Git commit, signed container digests/SBOM/provenance, dependency locks, CDK
  assembly hash, contract/policy/analyzer/model and fixture versions.
- Passing documentation/static/type/unit/contract/policy/component results.
- C01-CT through C18-CT manifests and all 585 P0 traceability coverage.
- INT-001..INT-138 reports with all six dimensions.
- E2E-001..E2E-014 signed manifests on the same candidate.
- IAM/ABAC/network/KMS/egress/secrets/supply-chain/CloudTrail/S3-data-event and
  prohibited-data scan reports.
- Accessibility, browser, load/fairness/SLO/cost, chaos, reconciliation,
  redrive/replay, projection rebuild, backup/restore and regional failover/
  failback reports.
- Active accepted-manifest/proposal/pointer/Neptune/OpenSearch counts/checksums/
  watermarks and query/timeline captures for the launch canary.
- Dashboard/alarms/synthetics/no-data state, on-call routing and exercised
  runbooks with owners.
- Cleanup/orphan/cost/credential/flag/session/lease reconciliation.
- Current waivers with scope/owner/compensating control/expiry; none may weaken
  a non-waivable P0 launch gate.
- Product, architecture, security/privacy, governance, accessibility, QA, SRE
  and release approvals.

Only after evidence verification passes may the coding agent state that the
working lineage collection application is successfully implemented.


---

# contract-catalog.md

# Shared Contract Catalog

**Status:** Normative
**Contract owners:** C01 (schema/identity), named producer (content), C12
(immutable persistence conventions)

## 1. Contract Rules

Every externally stored or transmitted contract must have:

- `$id` or equivalent canonical contract identifier.
- Semantic schema version and producing software/policy versions.
- Immutable business identity fields; missing identity fails validation or
  enters a named quarantine path.
- UTC RFC 3339 timestamps and globally unique event/artifact identifiers.
- `additionalProperties: false` at runtime, security, review, publication, and
  other privacy-sensitive boundaries.
- Enumerated extension variants rather than arbitrary property bags.
- A named Producer, Consumers, authority, retention class, and compatibility
  policy.
- Valid, boundary, and invalid examples committed with the schema.
- For S3-referenced content: URI, SHA-256 checksum, byte count, media type,
  compression, schema ID/version, KMS key class, and creation time.

Unknown schema major versions are deterministic invalid. A consumer may accept
a newer minor version only when its compatibility suite proves every new field
optional and semantics unchanged. Consumers preserve unknown versioned
extensions only when their enclosing schema explicitly permits that typed
variant.

## 2. Canonical Artifact Inventory

| Contract | Producer | Consumers | Authority | Compatibility |
|---|---|---|---|---|
| `CanonicalUrn` | C01 | All components | C01 registry | Grammar changes require new major version |
| `IdentityAliasRecord` | C01 | C02, C07-C13, C16-C17 | S3 history/DynamoDB effective index | Additive aliases; conflict semantics stable |
| `EventEnvelope` | C03 | C04, C06, C14, C18 | EventBridge archive plus idempotency state | Typed data schema versioned independently |
| `RepositoryInventorySnapshot` | C02 | C04-C06, C18 | S3 | Additive sources/fields in minor versions |
| `RepositoryEligibilityDecision` | C04 | C05-C06, C14, C17-C18 | S3 history/DynamoDB effective | Enum additions require consumer readiness |
| `ApplicationContextSnapshot` | C05 | C06-C13, C15, C17 | S3 | Immutable version, additive context sections |
| `DependencyRecord` | C05 | C06, C14, C18 | S3/DynamoDB index | Type enum governed |
| `DeterminantSet` | C05/C08 | C06, C13-C14 | S3 | Determinant kinds are typed variants |
| `CollectionRun` | C06 | C03, C12-C18 | DynamoDB plus audit | State additions require terminal/nonterminal declaration |
| `NativeLineageRun` | C07 | C12-C13 | S3 | OpenLineage facets plus governed extensions |
| `DeterministicAnalysisPackage` | C08 | C09, C12-C14 | S3 | Analyzer version participates in identity |
| `Hole` | C08/C13 | C09, C13, C15, C17 | S3 proposal inputs | Reason enum additive only with UI fallback |
| `AgentResolution` | C09 | C12-C13 | S3/cache index | Model/prompt/tool policy in cache identity |
| `OpaqueEvidencePackage` | C10 | C12-C13 | S3 | Advisory policy version required |
| `RuntimeEvidenceSession` | C11 | C06, C12-C13, C17-C18 | DynamoDB plus S3 manifest | State machine/version fixed per session |
| `RuntimeEvidenceEnvelope` | C11 | C11 validator, C12-C13 | S3 after validation | Strict allowlist; no generic map |
| `EvidenceReference` | C12 | C06, C09, C13-C17 | S3 content plus metadata | Checksum algorithm changes require major version |
| `VerifiedLineageCandidateSet` | C13 | C14-C15 | S3 | Confidence policy/version mandatory |
| `ArtifactLineageBinding` | C14 | Deploy systems, C15-C18 | Signed S3 artifact/registry | Signature profile versioned |
| `LineageProposal` | C15 | C16-C17 | S3 plus lifecycle index | Immutable proposal version |
| `ReviewCorrection` | C15/C17 | C13, C15-C16 | S3 | New version, never in-place mutation |
| `ReviewLabel` | C15 | Calibration analytics/C13 | S3/analytics catalog | Immutable per material edge decision |
| `AcceptedLineageManifest` | C16 | C12, C16-C18 | S3 Object Lock | Immutable graph version |
| `PublicationReservation` | C16 | C16 | DynamoDB | Token/lease semantics require major version |
| `ActiveGraphPointer` | C16 | C17-C18 | DynamoDB | Conditional transaction only |
| `ProjectionWatermark` | C16 | C17-C18 | DynamoDB/OpenSearch metadata | Monotonic per graph version |

## 3. `CanonicalUrn`

Canonical URNs use normalized UTF-8 and percent-encoding for reserved
characters:

```text
urn:lineage:<organization>:<environment>:<kind>:<namespace>:<name>[@<effective-version>][#<element-path>]
```

- `organization`, `environment`, `kind`, and `namespace` are lower-case governed
  slugs.
- `name` retains authoritative case only for case-sensitive sources; its
  normalized comparison key is stored separately.
- `kind` is one of `application`, `repository`, `artifact`, `service`, `job`,
  `dataset`, `schema`, `field`, `endpoint`, `topic`, `queue`, `file`, or a
  registered extension kind.
- Dataset/field identity uses the authoritative catalog/schema key when
  available; source-specific names become aliases.
- `effective-version` is an immutable artifact digest, schema version, graph
  version, or governed run version appropriate to the kind.
- `element-path` uses JSON Pointer escaping for nested fields.

Examples:

```text
urn:lineage:acme:integration:dataset:kafka.orders:created@v3#/gross_amount
urn:lineage:acme:prod:artifact:payments:api@sha256-741abc
urn:lineage:acme:prod:dataset:warehouse.analytics:fct_orders@2026-08-02#/total_revenue_usd
```

## 4. `EventEnvelope`

```json
{
  "eventId": "01J...",
  "eventType": "repository.commit.observed",
  "occurredAt": "2026-08-02T14:31:22Z",
  "receivedAt": "2026-08-02T14:31:24Z",
  "organizationId": "acme",
  "correlation": {
    "collectionRunId": "run-...",
    "traceId": "..."
  },
  "schema": {"id": "urn:contract:event-envelope", "version": "1.0.0"},
  "source": {"system": "github", "account": "enterprise", "deliveryId": "..."},
  "data": {}
}
```

Typed `data` variants include:

- `repository.commit.observed`: organization, repository ID, commit SHA,
  branch/ref, changed paths, source delivery identity.
- `artifact.deployed`: organization, repository, artifact digest, environment,
  deployment ID, application, deploy time, emergency-path flag.
- `baseline.requested`: application, requested snapshot watermark, requester.
- `runtime.session.requested`: application/repository/test run, commit, digest,
  expected sidecars, allowlist and budgets.
- `proposal.decision.recorded`: proposal/version, reviewer, decision and
  immutable decision reference.
- `publication.requested/completed`: proposal/version, expected prior/target
  graph version and manifest reference.

SCM idempotency identity:

```text
organization + repository + commitSha + eventType
+ analyzerVersion + policyVersion
```

Deployment idempotency identity:

```text
organization + repository + artifactDigest + environment + eventType
+ analyzerVersion + policyVersion
```

## 5. `RepositoryInventorySnapshot`

Identity: organization plus inventory watermark. The immutable body includes:

- Application/domain/owner associations with evidence and precedence.
- Every discovered repository, default branch, active/archive state, immutable
  HEAD commit, and source watermark.
- Deployed artifacts and environments with digests.
- Build/deployment descriptors, manifests, schemas/contracts, native jobs,
  test scenarios, and selected interaction context references.
- Source-by-source status: `COMPLETE`, `PARTIAL`, `UNAVAILABLE`, or `STALE`, with
  page/watermark, failure reason, retry history, and collected time.
- Counts/checksums enabling later source-to-snapshot reconciliation.

## 6. `RepositoryEligibilityDecision`

Identity: repository/path plus policy version and effective time. Fields:

- Classification: `APPLICATION_RUNTIME`, `DATA_PIPELINE`,
  `CONTRACT_SCHEMA_SOURCE`, `SHARED_LIBRARY`, `INFRASTRUCTURE`, `DOCUMENTATION`,
  `TEST_AUTOMATION`, `MIXED_MONOREPO`, or `UNKNOWN`.
- Eligible paths and excluded paths for a mixed monorepo.
- Lane assignment `A`, `B`, or `C` per producer/workload; absence is a coverage
  gap, not a default.
- Inclusion/exclusion reason codes and ranked evidence references.
- Application/domain/owner, dependencies, policy version, effective/expiry,
  override reviewer/rationale, content signature, and reconciliation time.

## 7. `ApplicationContextSnapshot`, `DependencyRecord`, and `DeterminantSet`

`ApplicationContextSnapshot` identity is application plus snapshot version. It
pins inventory version, repository/path decisions, commit/digest, schemas,
native jobs, deployment bindings, test scenarios, interaction context, and
dependency-index version.

`DependencyRecord` variants:

- Library consumer: library/package/version range -> repository/artifact.
- Infrastructure binding: route/topic/queue/endpoint/config -> application.
- Contract relationship: schema/contract -> producer or consumer workload.
- Test mapping: scenario -> application/workload/expected sidecar.

`DeterminantSet` records every file, symbol, schema, config key, dependency
version, generated input, analyzer/policy version, and source digest that could
change an edge or hole. Determinants are content-addressed and reverse-indexed.

## 8. `CollectionRun`

Identity: `collectionRunId`. Required fields:

- Run type: baseline, incremental, runtime, verification, publication,
  reconciliation, projection rebuild, or recovery.
- Application/repository/commit/artifact/environment identities as applicable.
- Policy/analyzer/contract versions.
- Trigger event and immutable context references.
- Current stage, ordered stage attempts, start/end, retry/redrive, error class,
  owner action, progress counters, and terminal outcome.
- Child workflow/job/session IDs and common correlation fields.

No stage embeds a large evidence body. It records an `EvidenceReference`.

## 9. Analysis Contracts

### 9.1 `NativeLineageRun`

Contains engine, job/run, artifact digest, input/output dataset/field URNs,
exact mapping/transform when provided by the engine, OpenLineage facet version,
resolved/unresolved status and reason, execution time, schema/catalog
references, and completeness checksum.

### 9.2 `DeterministicAnalysisPackage`

Identity: repository/artifact digest plus analyzer version and policy version.
Contains source snapshot checksum, workload/archetype, canonical candidate
edges, evidence spans, call/data-flow facts, `DeterminantSet`, `Hole` records,
coverage by supported construct, unsupported constructs, and a stable canonical
serialization checksum.

### 9.3 `Hole`

```json
{
  "holeId": "hole-content-id",
  "sourceLocation": {"path": "src/...", "startLine": 14, "endLine": 21},
  "reason": "DYNAMIC_DISPATCH",
  "affectedSinkUrn": "urn:lineage:...",
  "determinantsRef": "s3://...#sha256=...",
  "state": "OPEN"
}
```

Closure requires a deterministic resolution, verified agent resolution, or
review disposition. A dropped candidate returns the same hole identity to
`OPEN` with a verification reason.

### 9.4 `AgentResolution`

Identity/cache key:

```text
codeSliceHash + schemaHash + modelVersion + promptVersion + toolPolicyVersion
```

Contains hole ID, tool-call transcript references, bounded cited file:line
spans with quote hashes, candidate edges, budget usage, completion status,
unresolved reason, gateway/model/prompt versions, and checksum. It cannot
contain a whole-repository context dump or uncited emitted edge.

### 9.5 `OpaqueEvidencePackage`

Contains system/environment/digest, observation window/count, allowlisted field
URNs, session-scoped/nonreversible fingerprint comparison, match ambiguity,
collision/precision policy, evidence strength, retention, and permanent
advisory designation.

## 10. Runtime Contracts

### 10.1 `RuntimeEvidenceSession`

Identity: runtime session ID. Required fields:

- Test run, application, repository, commit, artifact digest.
- Environment exactly `integration`.
- Requested/start/expiry times and signed authorization reference.
- Expected sidecar IDs and minimum versions.
- Schema/field allowlist, maximum events/bytes, fingerprint policy, sampling/
  truncation policy, and Kinesis routing policy.
- State and each transition attempt.
- Registration, heartbeat, sequence-range, final-manifest and checksum status
  per expected sidecar.

### 10.2 `RuntimeEvidenceEnvelope`

Allowed keys are closed and typed:

- session/sidecar/event ID and monotonic sequence.
- application/repository/commit/artifact/test/trace/span identity.
- schema URN/hash, field path, logical type, nullability/presence.
- protocol, operation, direction, observation window/count.
- session-scoped keyed fingerprint where policy allows.
- instrumentation version, observed time, and envelope checksum.

Forbidden content includes raw/encoded values, payload/body, headers,
credentials, authentication material, SQL parameters, exception text carrying
payloads, reversible tokens, and arbitrary attributes/maps.

## 11. Evidence and Trust Contracts

### 11.1 `EvidenceReference`

Contains immutable S3 URI/version, SHA-256, byte count, media type, schema
ID/version, evidence type, provenance, producer version, artifact/effective
version, retention/legal-hold class, KMS data class, and creation identity/time.

### 11.2 Candidate edge

Every `LineageEdgeCandidate` contains:

- Canonical source and target URNs plus level.
- Transformation as a typed expression/reference where known.
- Channel and path guard.
- Artifact/environment/effective version.
- Evidence references and provenance set.
- Determinants and open/closed hole references.
- Structural and derivational confidence objects, never a shared float.

### 11.3 `VerifiedLineageCandidateSet`

Contains base graph version, deduplicated candidates, G1-G5 results, dropped
edges and returned holes, downgrades, conflicts, unresolved holes, coverage,
both confidence axes with policy/calibration version, and deterministic checksum.

## 12. Review and Publication Contracts

### 12.1 `LineageProposal`

Identity: proposal ID plus immutable version. Contains application, base graph
version, before/after manifests, added/removed/modified/confidence/coverage/
unresolved diffs, evidence/provenance, repository/commit/digest/test context,
lifecycle state, creator, prior proposal version, and checksum.

### 12.2 `ReviewCorrection` and `ReviewLabel`

A correction contains proposal/version, material edge, proposed and corrected
representation, reviewer, rationale, time, and prior checksum. It creates a new
proposal version.

A label contains `engineSaid`, `humanSaid`, edge, provenance, archetype,
repository, commit, reviewer, acknowledgement mode, and time. Bulk acceptance
uses `unreviewed`; only material per-edge acknowledgement becomes a labelled
calibration example.

### 12.3 `AcceptedLineageManifest`

Contains graph version, proposal/version/checksum, expected prior graph version,
application/environment, complete canonical nodes/edges/evidence/confidence,
reviewer/decision/time, policy/analyzer/contract versions, content checksum,
and signature. It is immutable under Object Lock.

### 12.4 Publication control

`PublicationReservation` contains application/environment, proposal/version,
expected prior/target graph versions, lease owner/expiry, monotonically issued
fencing token, and state.

`ActiveGraphPointer` contains environment/application/domain, graph version,
accepted manifest reference/checksum, fencing token, changed time, and
projection watermarks. It advances only in the conditioned publication
transaction.

## 13. Confidence Contract

Each axis uses:

```json
{
  "band": "UNCALIBRATED",
  "evidenceRefs": ["s3://...#sha256=..."],
  "policyVersion": "confidence-v1",
  "calibrationVersion": null,
  "calibrated": false,
  "reasons": ["DETERMINISTIC_REACHABILITY"]
}
```

Bands and numeric thresholds are policy data. Until calibrated against the
labelled corpus, both axes render `UNCALIBRATED`. Lane B exact plan evidence is
the only initial derivational oracle. OTel/runtime execution changes structural
evidence only. Sole-LLM provenance remains capped below the top band.

## 14. Contract Conformance Evidence

Before a contract version is released, retain:

- JSON Schema/OpenAPI lint results.
- Valid, boundary, invalid, privacy, and oversized examples.
- Backward/forward producer-consumer compatibility matrix.
- Canonical serialization and checksum golden files.
- Consumer tests for unknown minor and rejected major versions.
- Proof that forbidden runtime fields and generic maps fail closed.
- Ownership, review, release note, and deprecation date where applicable.


---

# dependency-and-integration-matrix.md

# Dependency and Integration Test Matrix

**Status:** Normative implementation and launch specification
**Applies to:** C01-C18, external producers, AWS dependencies, user clients and
enterprise control systems

## 1. Purpose

This matrix is the authoritative definition of every INT-nnn obligation named
by the component PRDs. A component is not integrated because its happy-path API
call succeeds. Its boundary is complete only when the common six-path protocol,
the row-specific invariant, security policy, recovery behavior and retained
evidence pass in the required deployed environment.

The component PRD owns behavior on its side of a boundary. This matrix owns the
joint producer-consumer proof. If the documents conflict, the stricter
validation, privacy, idempotency, versioning or visibility rule applies and the
contract owners must reconcile the specifications before promotion.

## 2. Component Dependency and Release Gates

| Component | Required upstream before implementation integration | Required downstream proof before component complete | Primary gate |
|---|---|---|---|
| C01 | Schema registry, KMS, policy and identity fixtures | C02/C07/C08/C11/C13/C15/C16/C17/C18 consume one pinned identity meaning | Foundation contracts |
| C02 | C01, enterprise inventory sources and scoped credentials | C03-C05/C17/C18 receive complete or explicit partial snapshots | Inventory |
| C03 | C01/C02, authenticated producers, EventBridge/SQS | C04/C06/C14/C17/C18 account for every accepted/quarantined trigger | Intake |
| C04 | C01-C03 and eligibility policy registry | C05-C11/C14/C15/C17/C18 preserve class/lane/unknown decisions | Classification |
| C05 | C01/C02/C04 and source dependency metadata | C06/C08/C11/C13/C14/C17/C18 use one pinned context/determinant set | Context |
| C06 | C03-C05 and scheduler/service quotas | C07-C18 stage, retry, redrive, fairness and timeline proofs | Orchestration |
| C07 | C01/C04-C06 and native engines | C12/C13/C15/C17/C18 preserve exact/unresolved native semantics | Native collection |
| C08 | C01/C04-C06 and deterministic toolchains | C09/C12-C15/C17/C18 preserve byte-stable proof and holes | Deterministic analysis |
| C09 | C06/C08, enterprise model gateway and tool policy | C12/C13/C15/C17/C18 preserve citations, caps, budgets and abstention | Agentic residual |
| C10 | C01/C04-C06 and source-local privacy controls | C12-C15/C17/C18 preserve advisory scope/cap/expiry/abstention | Opaque advisory |
| C11 | C01/C03/C05/C06, AppConfig, sidecars and test service | C12/C13/C15/C17/C18 prove complete metadata-only integration sessions | Runtime evidence |
| C12 | C01 and C02-C11 producer schemas, S3/DynamoDB/KMS | C13/C15-C18 read immutable exact versions and recover authority | Evidence |
| C13 | C01/C05/C07-C12 and policy/calibration versions | C14/C15/C17/C18 preserve gates, drops, holes and two axes | Trust |
| C14 | C03/C05/C06/C08/C13 and CI/build/deploy/signing | C15-C18 bind every deployment digest to a freshness decision | CI/freshness |
| C15 | C12-C14 and enterprise ownership/SSO | C16-C18 preserve immutable review, labels and exact approval | Governance |
| C16 | C06/C12/C14/C15 and DynamoDB/Neptune/OpenSearch | C17/C18 prove fenced pointer, projection watermark and rebuild | Publication |
| C17 | C01/C06/C12-C16 and enterprise identity | Browser/API users and C18 prove authorized version-consistent experience | Experience |
| C18 | Enterprise organization/security/network/audit/incident/finance | Every component passes local plus cross-cutting controls and recovery | Security/operations/DR |

## 3. Mandatory Six-Path Boundary Protocol

Every matrix row creates these six executable cases. The test ID is the matrix
ID plus the suffix shown; the integration report must list all six.

| Suffix | Dimension | Required assertion |
|---|---|---|
| POS | positive | Contract-valid input produces the exact durable business effect and consumer acknowledgement. |
| NEG | negative | Invalid, unauthorized, incomplete, conflicting and privacy-prohibited input is rejected/quarantined with no forbidden effect. |
| DUP | duplicate | Duplicate and, when applicable, out-of-order delivery produces one idempotent effect or a documented conflict, never silent loss. |
| COMPAT | compatibility | Current and supported prior schema/client versions interoperate; unsupported major/semantic changes fail before business mutation. |
| REC | timeout/recovery | Producer/consumer/dependency timeout, throttling and partial failure follows bounded retry/checkpoint/redrive/reconcile without false success. |
| OBS | observability | Logs, metrics, traces, audit, state and C17 timeline carry safe correlation and make result/retry/quarantine/conflict visible. |

For read-only browser or control boundaries, DUP means repeated request/action
identity and REC includes stale cache/version/dependency recovery. For recovery
boundaries, COMPAT covers backup/schema/IaC/policy compatibility. A row may add
stronger cases but may not omit a dimension. Each case records fixture version,
producer/consumer builds, contract/policy versions, fault, timestamps, IDs,
expected/observed effects, checksums and artifact URIs as retained evidence.

## 4. Authoritative Boundary Matrix

### C01 contracts and identity

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-001 | C01↔C02 | Inventory aliases under pinned registry/environment/effective version | Every observation resolves once or is visibly ambiguous; snapshot checksum binds registry version. |
| INT-002 | C01↔C07/C08/C11 | Multi-lane canonical entity fixture | Native/static/runtime references converge to identical URNs without changing evidence meaning. |
| INT-003 | C01↔C13 | Candidate identity resolution | Ambiguity blocks deduplication/promotion and retains competing aliases/evidence. |
| INT-004 | C01↔C15/C17 | Alias inspection/correction | Authorized correction creates immutable version; old/new identities remain traceable and UI never rewrites history. |
| INT-005 | C01↔C16 | Published canonical nodes/edges | Target graph validates URN grammar, environment/effective version and manifest checksum before activation. |
| INT-006 | C01↔C18 | Registry security/rollback/recovery | Outage/rollback/cross-account denial/audit/restore preserves last valid pinned semantics. |

### C02 inventory and adapters

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-007 | C01↔C02 | Adapter observation and identity registry | Same as INT-001 plus invalid aliases cannot enter an authoritative snapshot. |
| INT-008 | C02↔C03 | Snapshot-created/reconciliation EventEnvelope | Exact snapshot URI/checksum/watermark is authenticated, deduplicated and routed once. |
| INT-009 | C02↔C04 | Repository/path inventory | Every discovered item receives included/excluded/mixed/unknown decision; none disappear. |
| INT-010 | C02↔C05 | Deployment/schema/native/test/context observations | One checksummed snapshot produces version-pinned context; explicit missing sources remain partial. |
| INT-011 | C02↔C17 | Inventory/source completeness | Counts, source watermarks, partial state and reconciliation gaps match snapshot truth and ABAC. |
| INT-012 | C02↔C18 | Source credentials/outage/audit/recovery | Throttle/outage/secret scan/restore yields bounded retry or PARTIAL, never leaked credentials or false complete. |

### C03 intake and queues

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-013 | C02↔C03 | Inventory trigger payload reference | Checksum/schema/source/identity validate before idempotent intake and archive. |
| INT-014 | External producers↔C03 | SCM/deploy/test signatures and immutable IDs | Forged/missing commit or digest quarantines; valid burst is accepted without loss. |
| INT-015 | C03↔C04 | Repository classification trigger | Exact repository/path/commit/snapshot identity reaches one governed eligibility decision. |
| INT-016 | C03↔C06 | Routed work trigger | Each accepted trigger maps to one visible workflow, coalesced membership, no-impact or deferral record. |
| INT-017 | C03↔C14 | Deployment/hotfix trigger | Every deployed digest/environment creates one freshness decision, including emergency paths. |
| INT-018 | C03↔C18 | Queue/DLQ/archive/replay | Enqueue/dequeue/DLQ/redrive/replay counts reconcile and poison messages cannot consume unbounded retry. |
| INT-019 | C03↔C17 | Intake timeline/status | Accepted/duplicate/coalesced/quarantined/deferred reason and correlation are user-visible without payload. |

### C04 eligibility and lane routing

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-020 | C02↔C04 | Inventory cohort/path evidence | Complete decision cardinality equals discovered items and critical unknown blocks baseline completion. |
| INT-021 | C03↔C04 | Duplicate/out-of-order policy triggers | Same input/policy reuses decision; newer evidence supersedes conditionally; stale event cannot overwrite. |
| INT-022 | C04↔C05 | Class/lane/override policy | Context and determinants include effective class/path reasons, policy/expiry and conflicts. |
| INT-023 | C04↔C06/C07-C11 | Lane assignment | Eligible workload routes exactly to approved lane(s); excluded/unknown never runs expensive collector silently. |
| INT-024 | C04↔C14 | Class/lane/policy invalidation | Effective change invalidates the exact artifact binding and triggers governed reanalysis. |
| INT-025 | C04↔C15/C17 | Unknown/conflict/override review | Reviewer sees evidence/expiry/history; authorized immutable decision updates downstream state. |
| INT-026 | C04↔C18 | Policy activation/expiry/reconciliation | Rollback/outage/waiver expiry/load and audit preserve last valid policy and expose every mismatch. |

### C05 context, dependencies and determinants

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-027 | C01/C02/C04↔C05 | Pinned inventory, class and identities | One context version resolves repository/path/application/schema/environment without mixed snapshots. |
| INT-028 | C05↔C06 | Invalidation manifest | Planned work cardinality/reasons exactly match scheduled/coalesced/no-impact outcomes. |
| INT-029 | C05↔C08/C13 | Determinant round trip | Edge/hole determinants reference existing versioned facts and can reproduce invalidation decision. |
| INT-030 | C05↔C14 | Config/library/infra/contract/test change | Correct consumers/artifacts invalidate; capacity-only/docs-only changes produce explainable no-impact. |
| INT-031 | C05↔C11 | Test/scenario/sidecar mapping | Expected session participants and tests are exact; missing/conflict becomes INCOMPLETE before confidence use. |
| INT-032 | C05↔C17 | Context/dependency explanation | Authorized UI/API shows reason path, conflicts, versions and fan-out without sensitive source leakage. |
| INT-033 | C05↔C18 | Index outage/fan-out/rebuild | Reconciliation and full scan detect missing consumers; rebuild matches source checksums within fairness limits. |

### C06 orchestration and scheduling

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-034 | C03↔C06 | Accepted route to run | Exactly one run/no-impact/deferred record per idempotency/coalescing membership and priority. |
| INT-035 | C04/C05↔C06 | Lane/context/invalidation plan | Workflow pins inputs and schedules exact eligible work under version/priority policy. |
| INT-036 | C06↔C07-C10 | Analysis job protocol | Budget/heartbeat/checkpoint/result/finally/retry semantics produce one durable stage outcome. |
| INT-037 | C06↔C11 | Runtime session orchestration | Tests start after READY; drain/disable finally executes; closing completeness controls downstream. |
| INT-038 | C06↔C12/C13 | Stage artifacts to verification | Checksummed immutable outputs feed one verification input; missing/conflict stays INCOMPLETE. |
| INT-039 | C06↔C15/C16 | Review wait/resume/publication | External callback identity/state is conditional; retry cannot duplicate decision or active pointer advance. |
| INT-040 | C06↔C17 | Run timeline/redrive action | All stages/attempts/reasons/artifacts correlate; permitted operator action is bounded and current-state checked. |
| INT-041 | C06↔C18 | Fairness/orphan/DR operations | Tier-1 start SLO holds under load; orphan/retry/quota/failure reconciles and restores safely. |

### C07 native lineage

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-042 | C01/C04/C05↔C07 | Lane B pinned job/context/aliases | Collector accepts only eligible exact engine/artifact context and emits canonical versioned mappings. |
| INT-043 | C06↔C07 | Expected native-run workflow | Missing listener/artifact, retry and reconciliation yield exact run outcome without fabricated mapping. |
| INT-044 | Spark/dbt/Airflow↔C07 | Native facets/manifests/plans | Exact columns/transforms and unresolved select-star/dynamic cases match engine goldens and artifact digest. |
| INT-045 | C07↔C12 | Native package persistence | First immutable checksum wins; identical duplicate reuses, conflicting same identity quarantines. |
| INT-046 | C07↔C13 | Native derivational oracle | Exact mappings can verify derivation; execution-only/unresolved evidence cannot. |
| INT-047 | C07↔C15/C17 | Native review/query provenance | Users see run/digest/exactness/unresolved/coverage and can trace evidence authorization. |
| INT-048 | C07↔C18 | Native fault/privacy/load/DR | Missing facets, outage, secret scan, capacity and restore produce visible exact/incomplete outcomes. |

### C08 deterministic analysis

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-049 | C01/C04/C05↔C08 | Lane A request and DeterminantSet | Analyzer pins commit/context/tool/config/schema and rejects unsupported/mixed identity. |
| INT-050 | C06↔C08 | Batch job lifecycle/cache | Admission/budget/heartbeat/checkpoint/result/retry/redrive creates one byte-stable stage result. |
| INT-051 | C08↔C09 | Named Hole handoff | Only open hole and approved bounded facts/tools pass; deterministic proof is never reanalyzed. |
| INT-052 | C08↔C12 | Package/fact/cache persistence | Content key reproduces byte-identical package; conflict/partial write quarantines. |
| INT-053 | C08↔C13 | Provable edge/hole verification | G1/G2/G4 pass only with cited resolvable evidence; hole counters balance. |
| INT-054 | C08↔C14/C15/C17 | Drift/review/evidence presentation | Changed determinants produce exact diff; proof/holes/versions remain visible end to end. |
| INT-055 | C08↔C18 | Sandbox/determinism/load/recovery | No network/secret leak; repeated analysis is byte-identical and recoverable within quotas. |

### C09 agentic residual resolution

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-056 | C08↔C09 | Open hole/fact/tool scope | Hole identity, facts and allowed operations round-trip; closed/nonexistent hole is rejected. |
| INT-057 | C06↔C09 | Residual queue and budget | Admission/retry/defer prevents starvation and produces resolved/abstained/budget-exhausted outcome once. |
| INT-058 | C09↔Enterprise gateway | Model/Region/tool/CI identity policy | Only approved model and bounded prompt/tool path executes; outage degrades to unresolved. |
| INT-059 | C09↔C12 | Task/result/content cache | Result checksum binds hole/facts/model/prompt/tools; duplicate reuses and conflict quarantines. |
| INT-060 | C09↔C13 | Citation/evidence verification | Each emitted edge cites existing file:line/fact; G1-G5 drops unsupported edges and reopens hole. |
| INT-061 | C09↔C15/C17 | Agent provenance/review | UI exposes LLM provenance, citations, cap, budget and unresolved reason without model transcript. |
| INT-062 | C09↔C18 | IAM/privacy/injection/cost/DR | Prompt injection, arbitrary search/egress, secret context and spend limits are denied/audited; outage is safe. |

### C10 opaque advisory evidence

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-063 | C01/C04/C05↔C10 | Lane C enrollment/field policy | Only approved opaque sources/fields/windows enter collection; sensitive/low-cardinality fields suppress. |
| INT-064 | C06↔C10 | Advisory job/budget/kill/finally | Optional work sheds before critical paths; failure/kill closes state and never blocks launch. |
| INT-065 | Source-local collector↔C10/C12 | Fingerprint key/window/aggregate package | Raw values never leave source; session/window-key expiry and minimum observation enforce privacy. |
| INT-066 | C10↔C13 | G1/G3/G5 advisory semantics | Nonmatch/ambiguity/expiry abstains; confidence cap prevents verified derivation. |
| INT-067 | C10↔C14/C15 | Nonblocking evidence/review | Opaque evidence never enters deterministic blocking; reviewers see advisory label/cap. |
| INT-068 | C10↔C17 | Advisory query presentation | Scope/window/support/ambiguity/expiry and no raw values render accurately under ABAC. |
| INT-069 | C10↔C18 | Privacy kill/key/source fault/load | Incident revokes keys/stops collection; outage/cost/load/recovery retains safe advisory state. |

### C11 integration runtime evidence

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-070 | C01/C05/C06↔C11 | Test/context/digest/expected sidecars | Session binds exact integration environment/scenarios/artifact and rejects missing/mismatched participants. |
| INT-071 | AppConfig↔C11 | Signed enable/readiness/disable/expiry | Flag enables only attested integration session and disables in finally/expiry even after fault. |
| INT-072 | Sidecar↔CloudWatch/validator/Kinesis/C12 | Evidence schema/sequence/closing manifest | Allowed metadata arrives in order per sidecar, checksum closes, forbidden values quarantine. |
| INT-073 | C11↔C13 | Runtime completeness semantics | COMPLETE may raise structural only; incomplete/truncated/failed cannot; derivational never changes. |
| INT-074 | C11↔C15/C17 | Session evidence/coverage UI | Tests, participants, gaps, truncation and privacy state remain versioned and visible. |
| INT-075 | C11↔C18 | Production hard-deny/security ops | AppConfig/IAM/resource/attestation layers each deny production and emit incident-grade audit. |
| INT-076 | C11↔C03/C06 | Callback replay/redrive | Duplicate/stale READY/event/close cannot rerun tests, reopen session or duplicate evidence. |
| INT-077 | C11↔C18 load/DR | Storm/quota/Region failure | Sequence/completeness/final disable and recovery meet overhead/fairness/RPO/RTO. |

### C12 immutable evidence and cache

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-078 | C01/C02-C11↔C12 | Producer schema/prefix/data class | Each producer writes only allowed contract/prefix/key; checksum/URN/version/privacy validate first. |
| INT-079 | C06↔C12 | Stage start/result reference | Workflow records exact immutable URI/checksum/schema; partial/missing write never marks success. |
| INT-080 | C08/C09/C10↔C12 | Content-addressed caches | Complete key includes all determinants/policy/tool inputs; identical hit safe, conflicting identity quarantined. |
| INT-081 | C11↔C12 | Runtime validator-only write | Direct sidecar/write is denied; sequence/manifest/privacy validator determines immutable completeness. |
| INT-082 | C12↔C13/C15 | Evidence/proposal/label exact reads | Consumers verify checksum/version/Object Lock and cannot mutate or read outside ABAC. |
| INT-083 | C12↔C16/C17 | Accepted manifest/export/query reference | Publication/query uses approved exact artifacts; pointer/projection are not evidence authority. |
| INT-084 | C12↔C18 security/records | IAM/KMS/private/Object Lock/legal hold/audit | Unauthorized/delete/tamper attempts fail and required data access is centrally audited. |
| INT-085 | C12↔C18 operations | Integrity/replication/backup/restore/rebuild | Inventory/checksum/CRR/RPO/RTO reconcile exact immutable truth under load and Region fault. |

### C13 trust engine

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-086 | C01/C05↔C13 | Identity/context/schema/determinants | Candidate merge uses one version and blocks ambiguity/staleness/conflict visibly. |
| INT-087 | C07↔C13 | Native oracle/unresolved coverage | Exact native maps verify derivation; missing/duplicate/conflict preserves coverage and evidence. |
| INT-088 | C08/C09↔C13 | Proof/hole/citation verification | G1-G5 deterministic results are repeatable; dropped agent edge returns open hole/reason. |
| INT-089 | C10↔C13 | Advisory scope/cap/expiry | Opaque evidence affects only allowed structural advisory result and abstains when invalid. |
| INT-090 | C11↔C13 | Runtime complete/incomplete | Runtime changes structural only under complete session and cannot prove transform/exclude paths. |
| INT-091 | C13↔C14/C15 | Blocking set and proposal input | Deterministic-only policy, gates, holes/conflicts/coverage/checksum transfer immutably. |
| INT-092 | C13↔C17 | Trust rendering/API | Both axes/gates/caps/calibration/evidence/drop/coverage render separately and accurately. |
| INT-093 | C13↔C18 | Policy/load/chaos/recovery | Policy authorization, determinism, reconciliation and restore reproduce exact verified set/checksum. |

### C14 CI, artifact binding and freshness

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-094 | C05/C08/C13↔C14 | Determinant-scoped drift package | Changed determinants/proof/holes/gates yield exact deterministic drift/no-drift output. |
| INT-095 | C03/C06↔C14 | Deployment/hotfix/waiver-expiry flow | Every digest/environment gets one current/missing/stale/blocked/suppressed decision and run. |
| INT-096 | CI/SCM↔C14 | Status/comment/patch contract | Exact user strings/status, no-auto-commit and untrusted-fork security behave compatibly/idempotently. |
| INT-097 | Build/release/signing↔C14 | Already-built artifact/package signature | Binding names immutable digest and approved package/provenance; tag-only or unsigned input fails. |
| INT-098 | C14↔C15/C16 | Approved package to publication | Exact proposal/package/digest/freshness/base binds accepted manifest; stale cannot activate. |
| INT-099 | Deployment↔C14/C17 | Freshness and incident query | Decision becomes visible quickly; stale-suppressed lineage is excluded from current incident result. |
| INT-100 | C14↔C18 | Policy/signing/audit/reconcile/DR | Phase/waiver/security/load/outage/restore maintains a decision for every deployment. |
| INT-101 | C14↔Incident queries | Stale-suppression enforcement | Current query filters known stale bindings and explains exclusion with authorized evidence. |

### C15 proposal, review and corpus

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-102 | C13↔C15 | Verified set to immutable proposal | Deterministic before/after/diff/checksum/base/materiality reproduces exactly; blockers transfer. |
| INT-103 | C14↔C15 | Artifact/freshness/blocker input | Review shows exact digest/phase/decision; stale/expired policy blocks approval until rebased. |
| INT-104 | C15↔C16 | Approved manifest handoff | Exact approved version/checksum/base/reviewer/policy publishes once; reject/supersede never publishes. |
| INT-105 | C15↔C17 | Review API/UI | Assignment/diff/evidence/two axes/holes/conflicts/materiality and optimistic concurrency match C15. |
| INT-106 | SSO/SCIM/catalog↔C15 | Ownership/role/delegation/separation | Current authorized reviewer only; revoked/expired/cross-domain decision denies and audits. |
| INT-107 | C15↔C12 | Immutable review artifacts | Proposal/correction/decision/label checksums and Object Lock retain history and exact reads. |
| INT-108 | C15↔C18 | Review SLO/security/recovery | Notification/escalation/audit/privacy/export/backup restore preserves decisions and no duplicate publish. |
| INT-109 | C15↔C13/C14 corpus | Label/calibration gate | At least 200 valid material labelled edges across six archetypes/hard cases; bulk unreviewed excluded. |

### C16 fenced publication and projections

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-110 | C12/C15↔C16 | Approved Object-Locked manifest/base | Signature/checksum/approval/base validate before reservation; draft/reject/unlocked fails. |
| INT-111 | C06↔C16 | Publication workflow | Submit/retry/redrive/cancel/reconcile preserves request identity/fence and one terminal callback. |
| INT-112 | C16↔DynamoDB/Neptune | Lease/fence/stage/pointer transaction | Only current fence and expected prior activate fully verified immutable target; stale worker loses. |
| INT-113 | C16↔OpenSearch | Active projection/alias/watermark | Build exact active version, atomically expose alias/watermark; failure lags visibly and retries. |
| INT-114 | C16↔C17 | Active graph/search version | Query pins pointer/watermark, never mixes version, and handles lag/rebuild/rollback explicitly. |
| INT-115 | C16↔C15 | Publication callbacks | Publishing/active/failed/conflict callback is conditional on exact proposal/version and idempotent. |
| INT-116 | C16↔C18 | Publication controls/operations | IAM/network/KMS/audit/alarm/reconcile/chaos/cleanup preserve prior active and immutable truth. |
| INT-117 | C12/C16/C18 DR | Projection recovery | Restore accepted manifests/pointer history and rebuild exact Neptune/OpenSearch within RPO/RTO. |

### C17 query APIs, UI and timeline

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-118 | C16↔C17 | Pointer/namespace/checksum/watermark | Every response pins permitted active graph and labels projection lag/version; pointer race never mixes. |
| INT-119 | C15↔C17 | Proposal/review conditional command | UI/API mirrors immutable C15 state and stale edit cannot overwrite newer proposal. |
| INT-120 | C12↔C17 | Evidence/export authorization | Checksum/Object Lock/purpose/ABAC/redaction/expiry/audit pass; no existence leakage. |
| INT-121 | C13↔C17 | Gates/confidence/coverage display | Separate axes/caps/calibration/holes/conflicts/drop reasons/denominator match trust output. |
| INT-122 | C03/C06/C14/C16↔C17 | Run timeline events | Attempts/decisions/gaps/retry/redrive/publication/watermark order under common correlation. |
| INT-123 | C01↔C17 | URN/OpenAPI/client/deep links | Supported contracts round-trip canonical identity; ambiguous/unsupported version rejects safely. |
| INT-124 | C18↔C17 | Identity/WAF/network/audit/SLO/DR | API/UI/export controls, synthetics, alarms and regional behavior pass with no payload telemetry. |
| INT-125 | Neptune/OpenSearch↔C17 | Bounded query/load/lag | Depth/result/time/cost guards and replica/index failures meet SLO or explicit safe error. |
| INT-126 | Browser↔C17 | User journeys/accessibility | Supported browsers/assistive tech pass search, graph, review, timeline, stale/error/concurrency states. |

### C18 cross-cutting security, operations and recovery

| ID | Boundary | Contract and fixture focus | Exact joint pass invariant |
|---|---|---|---|
| INT-127 | C01-C03↔C18 | Foundation/intake controls | Contract policy, identity, network, secret/egress, audit, queue/DLQ and trigger reconciliation pass. |
| INT-128 | C04-C06↔C18 | Classification/context/orchestration controls | Unknown/determinant/fairness/retry/redrive/run gaps remain visible and recoverable. |
| INT-129 | C07-C10↔C18 | Analysis compute controls | Role/sandbox/egress/Bedrock/privacy/cost/fault controls pass without hiding incomplete work. |
| INT-130 | C11↔C18 | Runtime privacy/production hard-deny | Every deny layer, metadata sequence/completeness, cleanup, incident and DR path passes. |
| INT-131 | C12↔C18 | Evidence records/security/DR | KMS/Object Lock/retention/legal hold/data audit/CRR/checksum/restore preserve authority. |
| INT-132 | C13-C15↔C18 | Trust/review governance controls | RBAC/ABAC/separation/audit/backlog/waiver/retention/recovery preserves verified decisions. |
| INT-133 | C16↔C18 | Publication operational controls | Fence/pointer/capacity/alarm/reconcile/rebuild/chaos prove no partial or stale activation. |
| INT-134 | C17↔C18 | Experience controls | Identity/WAF/private/ABAC/export/audit/SLO/synthetic/stale/recovery pass. |
| INT-135 | External systems↔C18 | Trust/credentials/egress/outage | Scoped access and audit pass; dependency failure circuits to explicit partial/retry. |
| INT-136 | Audit/SIEM/incident↔C18 | Audit/finding/alarm/response | Required events arrive immutable/correlated, route on time and retain incident evidence. |
| INT-137 | Primary↔warm standby | Replication/backup/key/IaC/quota/recovery | Exercise restores/rebuilds/cuts over/fails back within RPO/RTO and exact reconciliation. |
| INT-138 | Finance/governance↔C18 | Tags/cost/budget/control/waiver | Spend attributes correctly, guardrails preserve critical work, waivers alert/expire/fail closed. |

## 5. Execution Ownership and Evidence

The producer team owns valid/invalid/duplicate payload fixtures and producer
telemetry. The consumer team owns validation, idempotent durable effects,
failure injection and recovery. Both owners sign the joint report. C18 owns the
deployed control evidence; QA owns fixture integrity and report completeness.

An integration result is valid only when run against immutable producer and
consumer builds with the production contract, IAM, KMS, network, queue/workflow,
data-store and telemetry topology appropriate to the gate. Local mocks may
prove logic but cannot close an INT row involving a managed-service semantic,
cross-account authorization, projection, load, chaos or recovery guarantee.

Failed rows block the dependent component gate. A waived nonfunctional case
must be P1/P2, cannot weaken a platform invariant or P0 requirement, and follows
C18 scoped expiry. Security/privacy, approval/fencing, immutable truth,
idempotency, complete visibility and RPO/RTO cases cannot be waived for launch.


---

# end-to-end-acceptance-tests.md

# End-to-End Acceptance Tests

**Status:** Normative launch specification
**Execution environment:** Production-shaped nonproduction AWS organization,
primary Region and warm-standby Region
**Result authority:** Signed TestEvidenceManifest in immutable evidence storage

## 1. Purpose and Global Rules

These steel threads prove that independently implemented components compose into
one governed lineage application. Each test uses immutable component/image/IaC/
contract/policy versions and canonical fixture manifests. The test fails on a
forbidden business effect, hidden incomplete state, missing audit/telemetry,
cleanup failure or evidence gap even when the main workflow reports success.

All tests use the shared test strategy, common correlation contract, five-class
error model and applicable INT matrix rows. Unless a test is expressly a load
or disaster-recovery case, it runs in the primary production-shaped staging
Region with the real managed-service topology and isolated application IDs.

## 2. Steel-Thread Inventory

| ID | Steel thread | Components | Launch gate |
|---|---|---|---|
| E2E-001 | Approved mixed-application baseline | C01-C18 | Functional pilot |
| E2E-002 | Lane B native exactness | C01-C07, C12-C18 | Accuracy/native |
| E2E-003 | Lane A hole resolution | C01, C04-C09, C12-C18 | Accuracy/agentic |
| E2E-004 | Verification gates and confidence | C01, C05, C07-C13, C15, C17-C18 | Trust |
| E2E-005 | Runtime complete and incomplete | C01, C03, C05-C06, C11-C13, C15, C17-C18 | Privacy/runtime |
| E2E-006 | Application incremental determinant change | C01, C03-C08, C12-C18 | Incremental |
| E2E-007 | Shared library and infrastructure | C01-C08, C12-C18 | Dependency invalidation |
| E2E-008 | Documentation no-impact and contract reclassification | C01-C08, C12-C18 | Explainability |
| E2E-009 | UNKNOWN quarantine and replay | C01-C06, C12-C18 | Classification/visibility |
| E2E-010 | Hotfix missing lineage | C01, C03-C06, C12-C18 | Artifact freshness |
| E2E-011 | Human correction and fenced publication | C01, C06, C12-C18 | Governance/publication |
| E2E-012 | DLQ redrive and regional recovery | C01-C18 | Resilience/DR |
| E2E-013 | Production runtime hard-deny | C01, C03, C06, C11-C12, C17-C18 | Privacy/security |
| E2E-014 | 10,000-repository enterprise load | C01-C18 | Scale/performance |

## 3. Common Execution Record

Every E2E result records these fields:

- Purpose, owner, components/builds and INT rows exercised.
- Environment/accounts/Regions, fixtures/checksums and policy/contract versions.
- Preconditions and observed source/control/projection watermarks.
- Exact numbered actions and Injected failures with activation point.
- Pass/fail rules including required effects, forbidden effects and counts.
- SLO/capacity/fairness assertion and raw measurement report.
- Security assertion, privacy scan and authorization/audit evidence.
- Cleanup and final reconciliation.
- Retained evidence manifest, run/workflow/session/proposal/graph IDs, checksums,
  traces, audit, dashboards, screenshots/reports and owner approvals.

## 4. E2E-001 — Approved Mixed-Application Baseline

**Purpose:** Prove the complete intake-to-query application for a mixed business
application containing Spring/FastAPI Lane A, Spark/dbt/Airflow Lane B, a
mixed-monorepo, shared library/infrastructure, optional Lane C advisory evidence
and governed integration runtime evidence.

**Components:** C01-C18. **Environment:** Primary production-shaped staging
accounts with real EventBridge, SQS, Step Functions, Batch, AppConfig, Kinesis,
S3 Object Lock, DynamoDB, Neptune, OpenSearch, enterprise SSO and C18 controls.
**Fixtures:** FX-PILOT, FX-MIXED-MONOREPO, FX-NATIVE, FX-STATIC-HOLES,
FX-RUNTIME, FX-OPAQUE, FX-REVIEW and FX-PUBLICATION.

**Preconditions:** Fixture inventory sources, schemas, commits, artifact
digests, test mappings, owners/reviewers and empty application active pointer
are checksummed and healthy; all component/INT prerequisite gates pass.

**Steps:**

1. Submit authenticated baseline; inventory all fixture sources and archive the
   normalized trigger.
2. Classify every repository/path, create pinned application context,
   dependencies and DeterminantSet, then schedule lanes with priority fairness.
3. Collect native and deterministic packages, resolve only named agent holes,
   collect optional opaque advisory and complete metadata-only runtime session.
4. Persist immutable evidence; reconcile identities, apply G1-G5, retain holes/
   conflicts/coverage and independent confidence axes.
5. Create immutable proposal, sign in as application reviewer, inspect before/
   after and approve exact checksum/base.
6. Reserve/fence/stage/verify/activate Neptune, project OpenSearch watermark,
   then search, traverse one hop, inspect evidence/coverage and run timeline.

**Injected failures:** Duplicate baseline trigger and one transient Batch
throttle. Both must recover inside the same visible run/effect identity.

**Pass/fail rules:** Every inventory member has a class/outcome; native/static/
runtime/advisory meanings stay distinct; hole counters balance; approved
manifest checksum matches active pointer/Neptune counts/OpenSearch watermark;
query shows one active version and complete timeline. Fail on silent item,
unapproved publish, mixed version, missing stage, forbidden confidence promotion
or mismatch from fixture oracle.

**SLO:** Pilot baseline completes within the approved pilot target, projection
is queryable within 60 seconds of activation, and one-hop query is within two
seconds p95 for the repeated query sample.

**Security assertion:** Domain ABAC, proposer/approver policy, evidence purpose,
private paths, no-payload scans, KMS and CloudTrail/S3 data audit pass.

**Cleanup:** Close sessions, stop workers, expire exports, remove mutable
ephemeral resources and application projection through governed test cleanup;
retain immutable test artifacts and reconcile no active test pointer remains.

**Retained evidence:** Full TestEvidenceManifest, all stage artifact checksums,
proposal/decision/manifest/pointer/watermark, graph/search counts, Playwright
trace, accessibility result, distributed trace, audit and cleanup report.

## 5. E2E-002 — Lane B Native Exactness

**Purpose:** Prove Lane B native exactness for Spark OpenLineage, dbt manifest/
catalog and Airflow/SQL without guessing unresolved mappings.

**Components:** C01-C07, C12-C18. **Environment:** Production-shaped primary
staging with native engine adapters and approved graph/query path.
**Fixtures:** FX-NATIVE plus the native portion of FX-PILOT.

**Preconditions:** Engine run IDs, immutable artifact digests, schema versions,
listener/config and expected exact/unresolved goldens are installed.

**Steps:** Emit valid Spark/dbt/Airflow runs; ingest facets/artifacts; normalize
canonical identities; persist native packages; verify/diff/review/approve; query
each field and evidence. Repeat identical runs and submit a conflicting same-
identity checksum.

**Injected failures:** Missing Spark listener facet, dbt select-star without
schema, late duplicate and conflicting artifact digest.

**Pass/fail rules:** Exact native mappings equal golden transforms/endpoints and
may be derivational oracle; unresolved dynamic/UDF/select-star stays unresolved;
duplicates create one effect and conflicts quarantine. Fail on inferred mapping,
digest mixing, coverage inflation or silent missing run.

**SLO:** Native ingestion through proposal input meets component latency and
projection/query targets under the representative run volume.

**Security assertion:** Engine role/prefix, artifact access, payload/secret scan
and evidence ABAC/audit pass.

**Cleanup:** Drain native test streams/queues, close runs and delete ephemeral
engine/test projections while retaining packages and audit.

**Retained evidence:** Engine inputs, normalized packages, exact/unresolved
golden diff, duplicate/conflict state, proposal/graph/query and audit manifest.

## 6. E2E-003 — Lane A Hole Resolution

**Purpose:** Prove one deterministic edge plus a named Hole resolved by a cited
agent edge, with bounded tools, content-addressed cache and safe abstention.

**Components:** C01, C04-C09, C12-C18. **Environment:** Staging Batch plus
enterprise model gateway in approved Region. **Fixtures:** FX-STATIC-HOLES.

**Preconditions:** Pinned commit/context/DeterminantSet/parser/analyzer/model/
prompt/tool policy and exact deterministic/hole/citation goldens.

**Steps:** Run C08 twice and compare byte identity; submit only the open hole to
C09; allow search/read_span/resolve_symbol/call_graph/schema_lookup; emit one
file:line-cited edge and one abstention; verify through C13, review and query.
Repeat to exercise content cache.

**Injected failures:** Prompt injection in source comment, attempted arbitrary
file/network read, invalid citation and gateway timeout after tool use.

**Pass/fail rules:** C08 proof is byte-identical and never reanalyzed by model;
only scoped facts are exposed; cited edge passes resolvability/gates and remains
confidence-capped; invalid citation drops/reopens hole; timeout yields unresolved
or cached exact result. Fail on uncited edge, whole-repository prompt, secret
leak, unsupported tool or highest confidence from sole LLM provenance.

**SLO:** Budget/token/tool/time caps hold and residual work cannot starve Tier-1
deterministic analysis.

**Security assertion:** Model/Region/IAM/egress/prompt privacy policy and bounded
transcript/audit pass; source secrets never leave approved context.

**Cleanup:** Revoke task credentials, remove ephemeral workspace and retain
content-keyed task/result/citations plus privacy scan.

**Retained evidence:** Determinism diff, Hole lifecycle, tool audit, model usage/
cost, citations, G1-G5 result, cache proof and user-visible provenance.

## 7. E2E-004 — Verification Gates and Confidence

**Purpose:** Prove verification drop for G1/G2/G4 and downgrade for G3/G5 while
keeping structural confidence and derivational confidence independent.

**Components:** C01, C05, C07-C13, C15, C17-C18. **Environment:** Primary
staging trust engine with production policy registry. **Fixtures:** Combined
FX-NATIVE, FX-STATIC-HOLES, FX-OPAQUE and FX-RUNTIME gate corpus.

**Preconditions:** Pinned identity/context/schema/policy/calibration versions and
candidate oracle for each gate, provenance type and incomplete state.

**Steps:** Submit valid and invalid endpoint identity (G1), nonexistent field
(G2), unsupported evidence citation (G4), ambiguous match (G3), and conflicting/
expired evidence (G5); include native exact, deterministic, LLM-only, opaque and
runtime candidates. Generate proposal/query output.

**Injected failures:** Identity registry timeout and conflicting producer claims
arriving in reverse order.

**Pass/fail rules:** G1/G2/G4 invalid edges drop with visible reason/hole and
balanced counters; G3/G5 downgrade/cap or abstain without inventing consensus;
runtime affects structural only; derivational oracle rules and UNCALIBRATED
state hold; order/retry produces identical result. Fail on single confidence
score, hidden drop/conflict or incomplete promotion.

**SLO:** Repeatable verification meets target throughput and deterministic
checksum for both delivery orders.

**Security assertion:** Trust policy changes are authorized/audited; response
redaction does not alter gate computation.

**Cleanup:** Remove mutable test policy activation and projections; retain every
candidate, decision, gate report, policy checksum and reconciliation.

**Retained evidence:** Gate-by-gate golden, confidence bands/caps/calibration,
holes/conflicts/coverage, proposal and C17 rendering captures.

## 8. E2E-005 — Runtime Complete and Incomplete

**Purpose:** Prove metadata-only runtime completion and an incomplete-session
no-promotion case.

**Components:** C01, C03, C05-C06, C11-C13, C15, C17-C18. **Environment:**
Integration application accounts only, with real AppConfig, sidecars,
CloudWatch validator and Kinesis. **Fixtures:** FX-RUNTIME.

**Preconditions:** Signed integration attestation, exact artifact/tests/expected
sidecars, session policy/key and baseline structural confidence.

**Steps:** Run a complete session through REQUESTED, ENABLING, READY, COLLECTING,
DRAINING and COMPLETE; then run a second session with a missing sequence/closing
manifest and force finally disable. Verify evidence, confidence, proposal and
timeline for both.

**Injected failures:** Duplicate/out-of-order evidence, one sidecar timeout,
Kinesis throttle and prohibited raw/encoded secret event.

**Pass/fail rules:** Tests wait for all READY; valid metadata closes with exact
manifest; duplicate/order preserves one sequence set; incomplete closes
INCOMPLETE/TRUNCATED and cannot promote; runtime never proves derivation or
excludes unexecuted path; flag disables after every outcome; prohibited bytes
exist in no downstream sink.

**SLO:** Instrumentation resource/latency budget, drain deadline and ten-times
event profile pass without silent sampling.

**Security assertion:** Integration-only attestation, session-scoped keyed HMAC,
IAM/resource policy, privacy schema/quarantine and audit pass.

**Cleanup:** Confirm AppConfig disabled and expired, keys revoked, sidecars
stopped, buffers drained and workspace clean; retain manifests/audit.

**Retained evidence:** Session state/heartbeats/events/manifests/checksums,
privacy scan, Kinesis sequence report, confidence before/after and timeline.

## 9. E2E-006 — Application Incremental Determinant Change

**Purpose:** Prove an application change schedules only affected analysis and
produces an accurate immutable before/after diff.

**Components:** C01, C03-C08, C12-C18. **Environment:** Primary staging.
**Fixtures:** FX-PILOT application commit pair plus FX-CONTRACT.

**Preconditions:** Approved baseline/active graph, artifact binding, context and
determinant indexes match the prior commit.

**Steps:** Send duplicate SCM event for a handler/schema-binding change; compute
changed determinants and affected paths; run exact Lane A/B work; verify and
review added/removed/modified/no-impact diff; bind new built digest and publish.
Run scheduled full scan and compare.

**Injected failures:** Context index timeout after trigger and stale prior
artifact callback.

**Pass/fail rules:** One visible incremental run analyzes exactly affected
workloads; unaffected cache hits are justified; stale callback cannot mutate;
diff and artifact digest equal golden; full-scan divergence is zero; active
query changes only after approval/fence.

**SLO:** Incremental analysis completes within 30 minutes p95 excluding human
review/deferred runtime and Tier-1 starts within five minutes p95.

**Security assertion:** SCM signature, commit checkout, build provenance,
review authorization and audit pass with controlled egress.

**Cleanup:** Retain new approved version for test evidence, remove mutable
fixtures/projections through version-aware cleanup and reconcile deployments.

**Retained evidence:** Trigger/coalescing, determinant plan, cache decisions,
analysis/diff/full-scan, binding, proposal/pointer/query and trace.

## 10. E2E-007 — Shared Library and Infrastructure

**Purpose:** Prove Shared library and infrastructure changes route to affected
consumers without treating capacity changes as lineage changes.

**Components:** C01-C08, C12-C18. **Environment:** Primary staging with
dependency/index fan-out. **Fixtures:** FX-SHARED-LIBRARY and FX-INFRASTRUCTURE.

**Preconditions:** Three consumer applications have pinned dependency versions,
artifact bindings and approved active graphs.

**Steps:** Change an exported shared-library symbol; then change an endpoint
binding; then change only replica/CPU capacity. Process triggers and compare
planned/scheduled/verified/no-impact outcomes across consumers.

**Injected failures:** Delete one reverse-index row before incremental planning,
then allow scheduled full scan/reconciliation to detect it.

**Pass/fail rules:** Exact version-range consumers reanalyze for library change;
exact topology consumers reanalyze for endpoint change; nonconsumer and
capacity-only change record explainable no-impact; missing index is detected and
repaired, not accepted as zero impact. Fail on global fan-out without reason or
missed affected consumer.

**SLO:** Fan-out obeys domain/priority fairness and incremental target; repair
does not starve deployments.

**Security assertion:** Cross-application metadata access uses service scope;
users see only authorized dependency explanation.

**Cleanup:** Restore index through governed repair, close runs and remove
ephemeral versions while retaining divergence/reconciliation evidence.

**Retained evidence:** Dependency graph/versions, invalidation manifests,
schedules/results, no-impact records, divergence and repair report.

## 11. E2E-008 — Documentation No-Impact and Contract Reclassification

**Purpose:** Prove Documentation no-impact and contract-source reclassification
are explicit, deterministic and reviewable.

**Components:** C01-C08, C12-C18. **Environment:** Primary staging.
**Fixtures:** Documentation and contract paths from FX-MIXED-MONOREPO plus
FX-CONTRACT.

**Preconditions:** Baseline class/path policies, contract registry and active
artifact binding are current.

**Steps:** Submit a README-only commit and verify no expensive analysis/no
lineage impact; then change a documentation path into a governed contract source
with policy evidence, reclassify it, rebuild context and analyze consumers.

**Injected failures:** Out-of-order old eligibility-policy activation and
unsupported contract major version.

**Pass/fail rules:** Documentation change has a visible signed reason and no
lineage/artifact freshness mutation; reclassification creates immutable new
decision and exact consumer invalidation; stale policy cannot overwrite;
unsupported contract quarantines before downstream effect.

**SLO:** No-impact closes quickly within control-plane target; reclassification
meets incremental target.

**Security assertion:** Policy activation/override role, source access and audit
pass; contract data contains no payload values.

**Cleanup:** Roll policy fixture to prior version through normal versioning,
retain both decisions and reconcile path coverage.

**Retained evidence:** Commits, decisions/history, no-impact reason, contract
validation, consumer plan, audit and C17 timeline.

## 12. E2E-009 — Mixed Monorepo UNKNOWN Quarantine and Replay

**Purpose:** Prove mixed-monorepo path routing and UNKNOWN quarantine and replay
without silent exclusion.

**Components:** C01-C06, C12-C18. **Environment:** Primary staging.
**Fixtures:** FX-MIXED-MONOREPO with one critical unknown path.

**Preconditions:** Inventory snapshot is complete; eligibility policy lacks one
intentional critical construct; classification-review owner is active.

**Steps:** Trigger baseline, classify known paths and quarantine unknown path;
verify critical baseline cannot complete/approve; reviewer adds a scoped,
expiring governed decision/policy version; redrive exact quarantined item and
continue allowed lanes.

**Injected failures:** Duplicate quarantine/redrive command and override expiry
during a later event.

**Pass/fail rules:** Cardinality matches inventory paths; known paths route
correctly; unknown is visible with evidence/owner and blocks critical completion;
one conditional review decision enables one replay; duplicate safe; expiry
returns affected path to review. Fail on repository-wide class, skipped unknown
or unowned quarantine.

**SLO:** Classification/control actions meet API/queue SLO and replay does not
restart unaffected completed work.

**Security assertion:** Reviewer scope/separation, policy signature/expiry,
evidence ABAC and audit pass.

**Cleanup:** Expire/remove test override by new policy version, close quarantine
items and reconcile all path decisions.

**Retained evidence:** Snapshot/decision cardinality, quarantine/DLQ, reviewer
change, replay/coalescing, expiry behavior and timeline.

## 13. E2E-010 — Hotfix Missing Lineage

**Purpose:** Prove a Hotfix missing lineage alert and unskippable artifact
binding for an already-built image.

**Components:** C01, C03-C06, C12-C18. **Environment:** Staging deployment
system and CI/release/signing integration. **Fixtures:** FX-PILOT hotfix digest.

**Preconditions:** Prior active graph/binding exists; new signed already-built
digest is deployable through emergency path but has no lineage package.

**Steps:** Emit hotfix deployment event; create missing-lineage decision/alert;
attempt suppression with unauthorized and authorized time-bounded exception;
analyze exact deployed digest, review/package/bind it, then reconcile deployment
to active graph/query.

**Injected failures:** Normal CI was bypassed, deployment event duplicated and
exception expires before binding.

**Pass/fail rules:** Every duplicate maps to one deployment decision; missing/
stale lineage remains visible and current incident queries exclude stale
suppressed result; unauthorized/permanent bypass fails; expiry realerts/blocks
per phase; eventual package binds exact digest, never mutable tag.

**SLO:** Tier-1 deployment decision/alert within five minutes and incremental
analysis target; no baseline/backfill starvation.

**Security assertion:** Deployment signature, exception role/expiry, artifact
provenance, review and CloudTrail audit pass.

**Cleanup:** Close test exception, undeploy fixture, reconcile deployment and
retain both missing and resolved decision history.

**Retained evidence:** Deploy events/idempotency, alert/notification, exception
attempts, package signature/binding, proposal/pointer/query and audit.

## 14. E2E-011 — Human Correction and Fenced Publication

**Purpose:** Prove Human correction and fenced publication from immutable
before/after review through active version-consistent query.

**Components:** C01, C06, C12-C18. **Environment:** Primary production-shaped
review/publication/query stack. **Fixtures:** FX-REVIEW and FX-PUBLICATION.

**Preconditions:** Active prior graph, two immutable competing proposals against
the same base, authorized reviewer and separate publication role.

**Steps:** Reviewer corrects a material edge, creating a new version; attempt
stale-tab approval; approve exact new checksum; start two publication workers,
expire the first lease and issue a higher fencing token; stage/verify target,
advance pointer, lag/retry search and query evidence/timeline.

**Injected failures:** Concurrent review edit, stale worker late commit, partial
Neptune stage and OpenSearch failure after pointer activation.

**Pass/fail rules:** Prior proposal/decision stays immutable; stale review loses;
only exact approved manifest reserves; partial target never active; lower fence
cannot commit; one pointer transition occurs; graph remains active during search
lag; eventual watermark/count/checksum matches; correction emits proper label.

**SLO:** Standard review API within two seconds p95 and 95 percent approved
changes queryable within 60 seconds after successful activation.

**Security assertion:** Reviewer authorization/separation, C16-only mutation,
Object Lock, KMS/private network and decision/export/audit pass.

**Cleanup:** Retain graph versions per rollback policy, remove orphan test
targets only after reconciliation and close all leases/exports/sessions.

**Retained evidence:** Proposal versions/diff/label/decision, reservation/leases/
tokens/stage verification/pointer history, lag/retry/watermark and UI trace.

## 15. E2E-012 — Duplicate Storm, DLQ Redrive and Regional Recovery

**Purpose:** Prove duplicate event storm, governed DLQ redrive, projection
rebuild and regional recovery without truth loss or duplicate business effects.

**Components:** C01-C18. **Environment:** Primary and warm-standby production-
shaped staging Regions/accounts. **Fixtures:** FX-PILOT, FX-PUBLICATION and FX-DR.

**Preconditions:** Approved active application plus recovery point, healthy
replication/backups, standby IaC/keys/quotas and signed recovery plan.

**Steps:** Send duplicate/out-of-order events including poison schema; exhaust
bounded retries to DLQ; plan/dry-run/approve/redrive compatible subset; reconcile
effects; delete/corrupt operational projections and rebuild; then simulate
primary Region loss, select recovery point, restore truth/control, rebuild
projections, verify/cut traffic, and execute planned failback.

**Injected failures:** Callback loss, redrive cancellation/resume, OpenSearch
partial rebuild, replication lag within/outside objective and failover step retry.

**Pass/fail rules:** One effect per business identity; poison remains owned;
redrive scope/count/checkpoint reconcile; immutable artifacts unchanged;
rebuild exact; only one Region has write/fence authority; recovery/failback
checksums/pointers/watermarks/audit match oracle. Fail on silent item, unapproved
redrive, split brain, unverifiable loss or traffic before validation.

**SLO:** Recovery meets 15-minute RPO and four-hour RTO; queue/backlog recovery
and query availability measurements meet component objectives.

**Security assertion:** Recovery identities/approvals, keys/ABAC, audit
immutability, no public endpoints and evidence-preservation controls pass.

**Cleanup:** Return traffic/write authority to declared normal Region, remove
ephemeral restored projections only after evidence capture and reconcile both
Regions, queues, roles, costs and replication.

**Retained evidence:** Storm/event ledger, DLQ/redrive plan/result, rebuild
checksums, recovery clocks/point/data-loss assessment, cutover/failback, traces,
audit, dashboards and signed DR report.

## 16. E2E-013 — Production Runtime Hard-Deny

**Purpose:** Prove Production runtime hard-deny for both enablement and direct
evidence submission, with containment and audit.

**Components:** C01, C03, C06, C11-C12, C17-C18. **Environment:** Dedicated
synthetic production-class account with no customer payload and identical
organization/IAM/resource controls. **Fixtures:** Production attacks from
FX-RUNTIME and FX-SECURITY.

**Preconditions:** Production environment attestation/resources are deployed;
test identities include integration controller, compromised application role,
operator and cross-account principal.

**Steps:** Attempt AppConfig enable, session creation, sidecar attestation,
CloudWatch/Kinesis validator write, direct evidence S3/API write and replay of a
valid integration token from production context.

**Injected failures:** Tag/environment spoof, expired signature, confused deputy,
direct cross-account call and raw/encoded secret payload.

**Pass/fail rules:** AppConfig validation, organizational policy, IAM, resource
policy, session/environment attestation and schema validator independently deny
their path; no runtime evidence/session reaches accepted C12 state; attempts are
centrally audited/alerted without raw values; ordinary production context
collection remains unaffected. Any single allowed instrumented path fails test.

**SLO:** Denial and critical security alarm arrive within incident-routing
objective; protected action fails closed during audit/policy degradation.

**Security assertion:** This test is the security assertion: cross-layer hard-
deny, no-existence leakage, containment, break-glass prohibition and audit.

**Cleanup:** Revoke attack sessions/roles, verify flags absent/disabled, purge
quarantined mutable bytes under incident policy and retain only approved hashes/
audit; reconcile zero accepted runtime objects.

**Retained evidence:** Deny result at every layer, policy/IAM simulation,
CloudTrail/findings/alarms, sink-wide canary scan and incident runbook result.

## 17. E2E-014 — Enterprise Load, Fairness and Query SLO

**Purpose:** Prove the 10,000-repository enterprise load, 10,000-event burst,
priority fairness and projection/query SLOs in one capacity exercise.

**Components:** C01-C18. **Environment:** Production-shaped staging at approved
quotas/instance classes with primary Multi-AZ graph/search and central
operations. **Fixtures:** FX-SCALE-10K plus representative native/static/runtime/
review/publication/query distributions.

**Preconditions:** Signed capacity model, generator seed/manifest, 500 planned
Batch slots or measured approved equivalent, 30 percent headroom/autoscaling
plan, Tier-1 reservations, warmed monitoring and cost budgets.

**Steps:** Ingest 10,000-event burst while starting the 10,000 repositories
baseline; add continuous 100 triggers/second, Tier-1 releases, shared-library
fan-out, runtime ten-times burst, review activity, 100 concurrent application
publishes and 500 query requests/second including high-degree graph nodes.

**Injected failures:** Batch capacity reduction, one Kinesis shard throttle,
OpenSearch node degradation, Neptune reader failover and low-priority retry storm.

**Pass/fail rules:** No trigger/repository/deployment/evidence loss; explicit
incomplete/quarantine cardinalities reconcile; baseline completes within 12
hours; Tier-1 starts within five minutes p95; incremental within 30 minutes p95;
optional work sheds first; no domain starvation; 95 percent projections within
60 seconds; bounded one-hop within two seconds p95; query bounds and audit/
privacy hold. Fail on averages hiding percentile/error/fairness violation.

**SLO:** The preceding pass rules are the mandatory performance gate; report
p50/p95/p99/max, saturation, backlog recovery, capacity, cost and fairness.

**Security assertion:** Load cannot bypass ABAC, rate/query bounds, no-payload
validation, approval/fencing, audit delivery or production hard-deny.

**Cleanup:** Stop generators, drain/reconcile queues/workflows, close sessions,
remove ephemeral scale resources/projections, validate no active test pointer/
credential/cost remains and retain immutable sampled/golden artifacts.

**Retained evidence:** Generator/seed/checksums, full raw metrics, queue/run/
repository/deployment ledgers, load/chaos/cost report, graph/search query plans,
SLO dashboard snapshots, audits and cleanup reconciliation.

## 18. Suite Completion and Launch Decision

The suite passes only when E2E-001 through E2E-014 all pass against the same
release-candidate contract/policy/IaC/application build set, or a test explicitly
documents a later phase and its safe launch behavior in the traceability matrix.
No P0 steel thread, security/privacy invariant, human approval/fencing rule,
immutable-truth check, enterprise performance gate or RPO/RTO exercise can be
waived for launch.

The signed launch decision links every E2E TestEvidenceManifest, all failed-first
and rerun records, open corrective actions, component/INT results, cleanup and
current dashboards. A statement that testing occurred without these immutable
references is not acceptance evidence.


---

# implementation-sequence.md

# Implementation Sequence and Phase Gates

**Status:** Normative build order for the first production implementation
**Audience:** Coding agents, engineering owners, QA, security, SRE and release
management

## 1. Sequencing Rules

The sequence builds contract and truth foundations before producers, then the
earliest reviewable vertical slice, then optional/higher-risk evidence lanes,
and finally enterprise scale/recovery. C18 security/observability constructs are
implemented incrementally in every phase; Phase 9 validates the complete system.

**No component may skip** its component tests, every touching INT row, P0
traceability, deployed controls, cleanup or retained evidence because an E2E
test happens to pass. A phase may develop independent components in parallel
only after their shared upstream contracts are frozen for that phase.

Each phase uses one immutable release-candidate set: Git commit, contract and
policy versions, container digests, IaC assembly and fixture manifest. Exit
evidence from a different incompatible set cannot unlock the next phase.

## 2. Dependency DAG

```mermaid
flowchart TD
    P0["Phase 0: repository and security/audit skeleton"]
    P1["Phase 1: C01 contracts and identity"]
    P2["Phase 2: C12 evidence/control state and C18 foundations"]
    P3["Phase 3: C02-C06 inventory through orchestration"]
    P4["Phase 4: C07 native and C08 deterministic"]
    P5["Phase 5: C13 trust and C15 proposal/review"]
    P6["Phase 6: C14 binding, C16 publication, C17 query/UI"]
    P7["Phase 7: C11 runtime and C09 agentic residual"]
    P8["Phase 8: C10 opaque advisory"]
    P9["Phase 9: enterprise security, scale, chaos and DR"]

    P0 --> P1 --> P2 --> P3 --> P4 --> P5 --> P6
    P4 --> P7
    P5 --> P7
    P6 --> P7
    P7 --> P8 --> P9
    P6 --> P9
```

Cross-phase rules:

- C01 schema/URN meaning gates every producer and consumer.
- C12 immutable write/read/checksum and C18 account/IAM/KMS/network/audit
  foundations gate any real evidence.
- C02-C06 produce pinned, visible work before a lane collector is integrated.
- C13 and C15 are required before any C16 active pointer can exist.
- C14 binding is required for deployed-artifact currentness; C16/C17 may first
  demonstrate a nondeployed pilot baseline, then must integrate C14.
- C11 and C09 add evidence only to already safe deterministic/native/trust
  paths. C10 is advisory and cannot delay the launch-critical vertical slice.
- C18 controls and telemetry are acceptance dependencies in every phase, not a
  hardening task deferred to Phase 9.

## 3. Phase Summary

| Phase | Components/capability | Entry Criteria | Repository Targets | Exit Criteria |
|---|---|---|---|---|
| Phase 0 | Monorepo/toolchain and C18 control skeleton | Approved PRD package | Root manifests, CI, infra, policies, test support | Reproducible build; policy/audit skeleton; empty-account deployment |
| Phase 1 | C01 contracts/identity | Phase 0 green | contracts, contract libraries, identity registry | Canonical goldens and INT-001..006 pass |
| Phase 2 | C12 evidence/cache plus C18 foundations | Phase 1 frozen | evidence registry/client and evidence/security/audit stacks | Immutable truth/control read/write/restore and INT-078..085 foundations pass |
| Phase 3 | C02-C06 control plane | Phase 2 truth/state | adapters, inventory, intake, eligibility, context, run controller/workflows | Inventory-to-visible-run and INT-007..041 pass |
| Phase 4 | C07/C08 collection | Phase 3 pinned work | native ingest/workers, deterministic workers, analyzer SDK | Native/static packages and INT-042..055 pass |
| Phase 5 | C13/C15 trust/governance | Phase 4 goldens | verification/confidence/proposal/review | Reviewable baseline and INT-086..093/102..109 pass |
| Phase 6 | C14/C16/C17 | Phase 5 approval contract | CI/binder/deploy, publication/projections, query API/web | Fenced active query/UI and INT-094..126 pass |
| Phase 7 | C11/C09 | Safe Phase 6 slice and privacy/AI controls | runtime session/sidecar and agent tools/resolver | Runtime/agent paths and INT-056..062/070..077 pass |
| Phase 8 | C10 advisory | Phase 7 caps/privacy | opaque control/source-local/aggregate | Advisory/abstention/privacy and INT-063..069 pass |
| Phase 9 | Full C18 launch | Phases 0-8 complete | reconciliation, operations, redrive, DR, dashboards/runbooks/tests | All P0, INT and E2E-001..014 pass |

## 4. Phase 0 — Repository, Toolchain and Control Skeleton

### Entry Criteria

- Component PRD package and source precedence are approved.
- Engineering owners approve monorepo access, CI runners, nonproduction AWS
  organization/accounts/Regions and cost boundary.
- Security approves bootstrap roles and no production deployment permission.

### Repository Targets

    package.json
    pnpm-workspace.yaml
    tsconfig.base.json
    pyproject.toml
    uv.lock
    .tool-versions
    .github/workflows/
    contracts/
    packages/test-support/
    infra/bin/
    infra/lib/constructs/security/
    infra/lib/constructs/observability/
    policies/
    tests/fixtures/lineage/
    tests/contract/
    tests/security/foundation/
    docs/runbooks/foundation/

Create formatting, lint, typecheck, unit/contract, SBOM, secret, dependency,
IaC/policy and documentation checks. Bootstrap separate control, evidence,
application and observability/security staging accounts with private network/
KMS/audit constructs and mandatory tags.

### Exit Criteria

- Clean checkout reproduces locked TypeScript/Python dependencies and tests.
- CI has least-privilege OIDC role and cannot assume production runtime roles.
- Empty stacks synthesize/deploy/destroy in an ephemeral account; central audit,
  KMS and network conformance probes pass.
- Fixture manifest, deterministic clock/ID/checksum package and signed
  TestEvidenceManifest schema pass.

### Validation Commands

    corepack pnpm install --frozen-lockfile
    uv sync --frozen --all-groups
    pnpm format:check
    pnpm lint
    pnpm typecheck
    pnpm test:unit
    pnpm test:contract
    pnpm test:policy
    pnpm cdk:synth
    pnpm test:deployed -- --phase=0

## 5. Phase 1 — C01 Contracts and Identity

### Entry Criteria

- Phase 0 evidence is signed and current.
- Contract owners approve canonical URN grammar, environment/effective version,
  schema versioning and compatibility policy.

### Repository Targets

    contracts/schemas/
    contracts/openapi/
    contracts/examples/
    contracts/openlineage/
    packages/contracts-ts/
    packages/contracts-py/
    services/contract-registry/
    services/identity-registry/
    infra/lib/stacks/identity-stack.ts
    tests/contract/identity/
    tests/integration/identity/
    tests/load/identity/

Implement schema libraries/generators before service endpoints. Use identical
canonical JSON/SHA-256 goldens across TypeScript/Python; add a Go golden only if
a Go sidecar SDK is later selected.

### Exit Criteria

- C01 P0 and C01-CT-001..012 pass.
- INT-001..006 pass all six dimensions in deployed staging.
- Registry rollback/outage/restore, alias ambiguity and cross-language
  canonicalization retain evidence.
- Contract compatibility workflow blocks unsupported change.

### Validation Commands

    pnpm test:contract -- --component=C01
    pnpm test:component -- --component=C01
    uv run pytest tests/contract/identity tests/unit/identity
    pnpm test:integration -- --ids=INT-001..INT-006
    pnpm test:load -- --component=C01

## 6. Phase 2 — C12 Immutable Evidence and C18 Foundations

### Entry Criteria

- Phase 1 contract artifact is versioned and compatibility-tested.
- Retention/Object Lock, KMS data classes, account boundaries and audit owners
  are approved for staging.

### Repository Targets

    contracts/schemas/evidence/
    packages/evidence-client/
    services/evidence-registry/
    services/cache-index/
    infra/lib/stacks/evidence-stack.ts
    infra/lib/stacks/audit-stack.ts
    infra/lib/stacks/security-stack.ts
    infra/lib/constructs/evidence-store.ts
    infra/lib/constructs/operational-state.ts
    policies/evidence/
    tests/contract/evidence/
    tests/integration/evidence/
    tests/security/evidence/
    tests/dr/evidence/

### Exit Criteria

- C12 P0 and C12-CT-001..012 pass; applicable C18 foundation cases pass.
- Immutable put/get, first-writer cache, conflict/quarantine, Object Lock,
  legal hold, data events, PITR/CRR/restore and checksum inventory are proven.
- Producer SDK cannot write outside its contract/prefix/data class.
- INT-078..085 pass with generic producer harness; each real producer repeats
  its INT-078 path in its phase.

### Validation Commands

    pnpm test:component -- --component=C12
    uv run pytest tests/unit/evidence tests/integration/evidence
    pnpm test:security -- --scope=evidence-foundation
    pnpm test:integration -- --ids=INT-078..INT-085
    pnpm test:dr -- --scenario=evidence-restore

## 7. Phase 3 — Inventory, Intake, Classification, Context and Orchestration

### Entry Criteria

- Phase 2 evidence client and operational-state constructs are published.
- Staging contracts/credentials/sandboxes for Test Automation, SCM, deployment,
  catalog/schema, native and CloudWatch context sources are available.

### Repository Targets

    contracts/schemas/{inventory,events,eligibility,context,runs}/
    services/source-adapters/
    services/inventory-builder/
    services/event-normalizer/
    services/eligibility/
    services/context-index/
    services/run-controller/
    services/run-timeline/
    infra/lib/stacks/workflow-stack.ts
    infra/lib/constructs/{inventory-state,event-bus,priority-queues,event-archive,eligibility-registry,lineage-workflows,batch-capacity}.ts
    tests/{contract,integration,load,chaos}/{inventory,event-intake,eligibility,context,workflows}/

Implement C02/C03 in parallel after schemas; C04/C05 evaluators/indexes next;
C06 consumes their immutable outputs and must not duplicate business logic.

### Exit Criteria

- C02-C06 P0 and each component suite pass.
- INT-007..041 pass, including source outage, duplicate/out-of-order,
  UNKNOWN/mixed monorepo, library/infra no-impact, priority fairness, finally
  and redrive.
- FX-PILOT reaches a visible pinned run with stub lane results; every inventory
  member and trigger has an outcome.
- E2E-009 control path and control-plane load targets pass.

### Validation Commands

    pnpm test:component -- --components=C02,C03,C04,C05,C06
    pnpm test:integration -- --ids=INT-007..INT-041
    pnpm test:e2e -- --ids=E2E-009
    pnpm test:load -- --profile=LP-INGRESS-BURST
    pnpm test:load -- --scope=control-plane
    pnpm test:chaos -- --scope=control-plane

## 8. Phase 4 — Native and Deterministic Collection

### Entry Criteria

- Phase 3 produces exact lane job/context/budget/result contracts.
- Approved Spark/dbt/Airflow and language/framework fixtures are pinned;
  analyzer images have sandbox/no-egress controls.

### Repository Targets

    contracts/schemas/{native-lineage,deterministic-analysis}/
    services/native-ingest/
    workers/native-{spark,dbt,airflow}/
    workers/deterministic-{spring,fastapi,dask,sql}/
    packages/analyzer-sdk/
    infra/lib/constructs/{native-lineage-intake,analysis-jobs}.ts
    tests/fixtures/{native,static-holes}/
    tests/contract/{native-lineage,deterministic-analysis}/
    tests/integration/{native-lineage,deterministic-analysis}/
    tests/load/{native-lineage,deterministic-analysis}/

### Exit Criteria

- C07/C08 P0 and suites pass; outputs are immutable and reproducible.
- INT-042..055 pass with exact native mappings, unresolved cases,
  deterministic proof/Holes, cache and sandbox/fault behavior.
- E2E-002 passes. E2E-003 deterministic half produces its exact open Hole.
- Same deterministic request yields byte-identical package/checksum.

### Validation Commands

    uv run pytest tests/unit/native tests/unit/deterministic
    pnpm test:component -- --components=C07,C08
    pnpm test:integration -- --ids=INT-042..INT-055
    pnpm test:e2e -- --ids=E2E-002
    pnpm test:load -- --scope=collection

## 9. Phase 5 — Trust Engine and Human Governance

### Entry Criteria

- Phase 4 native/static packages and hole/candidate goldens are immutable.
- G1-G5, two-axis confidence, proposal materiality, reviewer ownership and
  launch no-auto-approval policy are approved.

### Repository Targets

    contracts/schemas/{verification,confidence,proposal,review-label}/
    workers/{reconciliation,verification}/
    services/confidence-policy/
    services/proposal-review/
    services/review-assignment/
    infra/lib/constructs/{verification-jobs,proposal-state}.ts
    tests/fixtures/{verification-microworld,review}/
    tests/{contract,integration,load,security}/{verification,proposal-review}/

### Exit Criteria

- C13/C15 P0 and suites pass; INT-086..093 and INT-102..109 pass.
- E2E-004 passes, including drop/downgrade, balanced holes, separate axes and
  deterministic ordering.
- FX-PILOT produces immutable before/after proposal; correction/version/
  concurrent decision and explicit approval rules pass.
- Corpus validation excludes bulk-unreviewed and reports progress to the
  200-edge/six-archetype gate.

### Validation Commands

    uv run pytest tests/unit/verification
    pnpm test:component -- --components=C13,C15
    pnpm test:integration -- --ids=INT-086..INT-093,INT-102..INT-109
    pnpm test:e2e -- --ids=E2E-004
    pnpm test:security -- --scope=trust-review

## 10. Phase 6 — CI Binding, Publication, Query API and UI

### Entry Criteria

- Phase 5 produces an exact approved manifest request against a known base.
- Staging CI/build/deploy/signing, Neptune, OpenSearch, SSO/SCIM and browser
  test identities are available.

### Repository Targets

    contracts/schemas/{ci-drift,artifact-binding,publication}/
    contracts/openapi/lineage-query-v1.yaml
    services/{ci-drift,artifact-binder,deployment-lineage-controller}/
    services/publication-controller/
    workers/{graph-exporter,neptune-projector,opensearch-projector,projection-reconciler}/
    services/query-api/
    apps/lineage-web/
    packages/{api-client,ui-components}/
    infra/lib/stacks/{projection,experience}-stack.ts
    tests/{contract,integration,load,chaos,security,accessibility,e2e}/

### Exit Criteria

- C14/C16/C17 P0 and suites pass; INT-094..126 pass.
- E2E-001, E2E-006, E2E-008, E2E-010 and E2E-011 pass through active,
  version-consistent query/UI.
- Stale worker, partial graph, pointer race, search lag and rebuild preserve
  prior active truth.
- Query bounds/two-axis/coverage/stale states, review concurrency, accessibility
  and artifact freshness/hotfix controls pass.

### Validation Commands

    pnpm test:component -- --components=C14,C16,C17
    uv run pytest tests/unit/graph-exporter tests/unit/projection
    pnpm test:integration -- --ids=INT-094..INT-126
    pnpm test:e2e -- --ids=E2E-001,E2E-006,E2E-008,E2E-010,E2E-011
    pnpm test:accessibility
    pnpm test:load -- --profiles=LP-PUBLICATION,LP-QUERY
    pnpm test:chaos -- --scope=publication-query

## 11. Phase 7 — Runtime Evidence and Agentic Residuals

### Entry Criteria

- Phase 6 deterministic/native review/publication/query path is safe.
- Security approves integration-only runtime hard-deny and enterprise model
  gateway bounded-context/tool/model/Region policy.

### Repository Targets

    contracts/schemas/{runtime-evidence,agent-resolution}/
    services/runtime-session/
    sidecars/runtime-evidence/
    services/agent-task-builder/
    services/agent-tools/
    workers/agent-resolver/
    infra/lib/constructs/{runtime-session,runtime-evidence-pipeline,agent-gateway,agent-cache}.ts
    tests/fixtures/{runtime,agent-holes}/
    tests/{contract,integration,security,load}/{runtime-evidence,agent-resolver}/

### Exit Criteria

- C11/C09 P0 and suites pass; INT-056..062 and INT-070..077 pass.
- E2E-003 and E2E-005 pass; runtime changes structural only and incomplete
  sessions never promote.
- E2E-013 production hard-deny passes every layer.
- Prompt injection/arbitrary tools/whole repository/secret leakage fail; cited
  agent edge remains capped and invalid citation reopens hole.

### Validation Commands

    uv run pytest tests/unit/agent-resolver tests/unit/runtime-validator
    pnpm test:component -- --components=C09,C11
    pnpm test:integration -- --ids=INT-056..INT-062,INT-070..INT-077
    pnpm test:e2e -- --ids=E2E-003,E2E-005,E2E-013
    pnpm test:security -- --scope=runtime-agentic
    pnpm test:load -- --profile=LP-RUNTIME-10X

## 12. Phase 8 — Opaque Advisory Collection

### Entry Criteria

- Phase 7 trust engine enforces advisory confidence cap/abstention.
- Privacy approves source-local fields, minimum observation, key lifecycle and
  kill path for the selected opaque substrate.

### Repository Targets

    contracts/schemas/opaque-evidence/
    services/opaque-control/
    source-local/opaque-collector/
    workers/opaque-aggregate/
    infra/lib/constructs/opaque-collection.ts
    tests/fixtures/opaque/
    tests/{contract,integration,security,load}/opaque/

### Exit Criteria

- C10 P0 and suite pass; INT-063..069 pass.
- Raw/reversible/sensitive/low-cardinality values appear in no sink.
- Ambiguous/insufficient/expired/nonmatch evidence abstains; advisory cannot
  block deploy or reach verified derivation.
- Failure/kill/cost shedding leaves launch-critical paths unaffected.

### Validation Commands

    uv run pytest tests/unit/opaque tests/integration/opaque
    pnpm test:component -- --component=C10
    pnpm test:integration -- --ids=INT-063..INT-069
    pnpm test:security -- --scope=opaque
    pnpm test:load -- --scope=opaque

## 13. Phase 9 — Enterprise Security, Operations, Scale and DR

### Entry Criteria

- Phases 0-8 have current signed evidence on one release-candidate set.
- All 585 P0 requirements map through component/INT/E2E evidence; no expired P0
  waiver, critical UNKNOWN or unowned alarm/runbook.
- Production-shaped primary and warm-standby quotas/topology are approved.

### Repository Targets

    services/reconciliation-controller/
    services/operations-api/
    workflows/redrive/
    workflows/regional-recovery/
    infra/lib/stacks/{operations,dr}-stack.ts
    packages/telemetry-contract/
    policies/
    dashboards/
    docs/runbooks/
    tests/{security,operations,load,chaos,dr,e2e}/
    evidence/launch-manifest-schema/

### Exit Criteria

- C18 P0/C18-CT-001..012 and INT-127..138 pass; all other component/INT tests
  rerun where topology/load/Region semantics change.
- E2E-001..014 pass on the same release candidate.
- 10k baseline/burst/fairness/publication/query SLOs and cost/headroom pass.
- Audit/privacy/accessibility/supply-chain/reconciliation/DLQ-redrive/zone-chaos/
  projection rebuild/warm-standby failover and failback pass exact rules.
- Signed launch checklist links all manifests, builds, dashboards, alarms,
  runbooks, cleanup and approvals; recovery meets 15-minute RPO/four-hour RTO.

### Validation Commands

    pnpm validate:all
    pnpm test:component -- --components=C01..C18
    pnpm test:integration -- --ids=INT-001..INT-138
    pnpm test:e2e -- --ids=E2E-001..E2E-014
    pnpm test:security
    pnpm test:load -- --all-required-profiles
    pnpm test:chaos
    pnpm test:dr -- --scenario=regional-failover-failback
    pnpm evidence:verify -- --candidate=current

## 14. Change, Rollback and Re-entry Rules

- A contract semantic change returns affected producer/consumer phases to
  contract and INT gates; compatibility decides whether older E2E evidence is
  valid.
- A security/IAM/network/KMS/retention/audit change returns affected phases to
  deployed conformance/security tests.
- An analyzer/model/policy change invalidates its component, downstream trust/
  proposal/publication and applicable accuracy E2E evidence.
- A graph/search/query schema or publication change reruns C16/C17, rebuild,
  E2E-011/012 and query/load tests.
- A topology/Region/backup/replication change reruns Phase 9 DR.
- Rollback uses a previously tested immutable build/policy/IaC set and governed
  state protocol; it never edits accepted evidence/manifests or bypasses fence.

Phase completion is a reproducible evidence state, not a calendar milestone.


---

# requirements-traceability-matrix.md

# Requirements Traceability Matrix

**Status:** Normative machine-validated coverage register
**Scope:** All P0 functional, nonfunctional, security and observability
requirements in C01-C18

## 1. P0 Coverage Invariant

The **P0 coverage invariant** is:

    source decision -> Requirement set -> Component test -> Integration test
    -> E2E steel thread -> Phase gate -> Expected evidence

Every P0 requirement must appear in exactly one component requirement table and
be covered by a row below. Range notation is inclusive: for example,
C01-FR-001..C01-FR-015 expands to every numbered ID from 001 through 015.
The documentation validator expands ranges and fails on any uncovered P0 ID.

The component test column names the complete component suite because the
component PRD's Traceability section narrows each behavioral cluster to specific
cases. The integration column points to the authoritative INT matrix, where
every ID expands into positive, negative, duplicate, compatibility,
timeout/recovery and observability cases. Expected evidence conforms to the
TestEvidenceManifest in the shared test strategy.

## 2. Evidence Classes

| Class | Required contents |
|---|---|
| FUNC | Contract/golden, state transitions, immutable input/output checksums, idempotent/forbidden effects, integration report and applicable E2E manifest |
| NFR | Production-shaped configuration, raw latency/throughput/error/fairness/capacity/cost, fault/recovery timeline and SLO calculation |
| SEC | IAM/policy/network/KMS/egress/privacy/accessibility scan as applicable, deny/allow matrix, immutable CloudTrail/data/application audit and incident evidence |
| OBS | Correlation completeness, safe logs/metrics/traces/audit, dashboard/alarms/no-data behavior, tested runbook and timeline capture |

## 3. Foundation and Control Plane Traceability

| Component | Requirement set | Component test | Integration test | E2E steel thread | Phase gate | Expected evidence |
|---|---|---|---|---|---|---|
| C01 | C01-FR-001..C01-FR-015 | C01-CT-001..C01-CT-012 | INT-001..INT-006 | E2E-001/002/003/004/006/009/011/012/014 | Phase 1 contracts/identity | FUNC: schemas/examples, cross-language canonicalization, alias/ambiguity/state report |
| C01 | C01-NFR-001..C01-NFR-004 | C01-CT-001..C01-CT-012 | INT-001..INT-006 | E2E-012/014 | Phase 1 plus Phase 9 scale/DR | NFR: registry/resolve load, availability, backup/restore and checksum report |
| C01 | C01-SEC-001..C01-SEC-004 | C01-CT-001..C01-CT-012 | INT-004/006 | E2E-001/012/013 | Phase 1 security gate | SEC: registry/IAM/ABAC/KMS/tamper/cross-account deny and audit report |
| C01 | C01-OBS-001..C01-OBS-004 | C01-CT-001..C01-CT-012 | INT-006 | E2E-001/012/014 | Phase 1 operations gate | OBS: resolution/ambiguity/version/rollback signals, correlation and alarms |
| C02 | C02-FR-001..C02-FR-015 | C02-CT-001..C02-CT-012 | INT-007..INT-012 | E2E-001/007/009/014 | Phase 3 inventory | FUNC: source goldens/watermarks, snapshot cardinality/checksum, partial/reconcile report |
| C02 | C02-NFR-001..C02-NFR-004 | C02-CT-001..C02-CT-012 | INT-012 | E2E-012/014 | Phase 3 plus Phase 9 scale/DR | NFR: 10k inventory/quota/fairness/outage/recovery raw report |
| C02 | C02-SEC-001..C02-SEC-005 | C02-CT-001..C02-CT-012 | INT-007/012 | E2E-001/012/013 | Phase 3 security gate | SEC: scoped credentials/egress/KMS/secret scan/ABAC/audit evidence |
| C02 | C02-OBS-001..C02-OBS-005 | C02-CT-001..C02-CT-012 | INT-011/012 | E2E-001/012/014 | Phase 3 operations gate | OBS: source completeness/lag/error/reconcile dashboards and alerts |
| C03 | C03-FR-001..C03-FR-015 | C03-CT-001..C03-CT-012 | INT-013..INT-019 | E2E-001/005/006/009/010/012/013/014 | Phase 3 intake | FUNC: auth/normalize/idempotency/coalesce/route/archive/quarantine ledger |
| C03 | C03-NFR-001..C03-NFR-004 | C03-CT-001..C03-CT-012 | INT-018 | E2E-012/014 | Phase 3 plus Phase 9 scale | NFR: 10k burst/100 rps/priority/backpressure/DLQ recovery report |
| C03 | C03-SEC-001..C03-SEC-005 | C03-CT-001..C03-CT-012 | INT-014/018 | E2E-001/012/013 | Phase 3 security gate | SEC: source signature/replay/size/schema/payload/IAM/audit proof |
| C03 | C03-OBS-001..C03-OBS-005 | C03-CT-001..C03-CT-012 | INT-018/019 | E2E-001/012/014 | Phase 3 operations gate | OBS: queue age/depth/throughput/DLQ/route/idempotency timeline |
| C04 | C04-FR-001..C04-FR-015 | C04-CT-001..C04-CT-012 | INT-020..INT-026 | E2E-001/006/007/008/009/014 | Phase 3 classification | FUNC: inventory-decision cardinality, lane/path policy/unknown/override history |
| C04 | C04-NFR-001..C04-NFR-003 | C04-CT-001..C04-CT-012 | INT-026 | E2E-009/012/014 | Phase 3 plus Phase 9 scale | NFR: 10k decision p95/determinism/availability/restore report |
| C04 | C04-SEC-001..C04-SEC-005 | C04-CT-001..C04-CT-012 | INT-025/026 | E2E-001/009/012/013 | Phase 3 security gate | SEC: policy signing/role/ABAC/LLM-nonexclusion/expiry/audit evidence |
| C04 | C04-OBS-001..C04-OBS-005 | C04-CT-001..C04-CT-012 | INT-025/026 | E2E-001/009/014 | Phase 3 operations gate | OBS: class/lane/unknown/stale/override/reconcile dashboards and alerts |
| C05 | C05-FR-001..C05-FR-016 | C05-CT-001..C05-CT-012 | INT-027..INT-033 | E2E-001/003/006/007/008/010/014 | Phase 3 context/indexes | FUNC: snapshot/dependency/determinant/reverse-index/no-impact/divergence report |
| C05 | C05-NFR-001..C05-NFR-004 | C05-CT-001..C05-CT-012 | INT-033 | E2E-007/012/014 | Phase 3 plus Phase 9 scale | NFR: invalidation/fan-out/full-context/load/fairness/rebuild metrics |
| C05 | C05-SEC-001..C05-SEC-005 | C05-CT-001..C05-CT-012 | INT-032/033 | E2E-001/007/012/013 | Phase 3 security gate | SEC: source/context ABAC, secrets/egress, policy and audit report |
| C05 | C05-OBS-001..C05-OBS-006 | C05-CT-001..C05-CT-012 | INT-032/033 | E2E-001/007/012/014 | Phase 3 operations gate | OBS: context completeness/fan-out/divergence/rebuild correlation |
| C06 | C06-FR-001..C06-FR-018 | C06-CT-001..C06-CT-012 | INT-034..INT-041 | E2E-001/003/005/006/007/009/010/011/012/014 | Phase 3 orchestration | FUNC: workflow definitions, stage/idempotency/finally/redrive/fairness ledger |
| C06 | C06-NFR-001..C06-NFR-004 | C06-CT-001..C06-CT-012 | INT-041 | E2E-012/014 | Phase 3 plus Phase 9 scale/DR | NFR: 10k baseline/Tier-1 start/availability/concurrency/recovery report |
| C06 | C06-SEC-001..C06-SEC-005 | C06-CT-001..C06-CT-012 | INT-037/041 | E2E-001/005/012/013 | Phase 3 security gate | SEC: task/workflow roles, reference-only state, callback/auth/audit proof |
| C06 | C06-OBS-001..C06-OBS-006 | C06-CT-001..C06-CT-012 | INT-040/041 | E2E-001/012/014 | Phase 3 operations gate | OBS: stage latency/state/retry/incomplete/fairness/cost/timeline signals |

## 4. Collection and Analysis Plane Traceability

| Component | Requirement set | Component test | Integration test | E2E steel thread | Phase gate | Expected evidence |
|---|---|---|---|---|---|---|
| C07 | C07-FR-001..C07-FR-017 | C07-CT-001..C07-CT-012 | INT-042..INT-048 | E2E-001/002/004/006/014 | Phase 4 native collection | FUNC: Spark/dbt/Airflow exact/unresolved/artifact/duplicate package goldens |
| C07 | C07-NFR-001..C07-NFR-004 | C07-CT-001..C07-CT-012 | INT-048 | E2E-002/012/014 | Phase 4 plus Phase 9 scale/DR | NFR: native run/mapping load, freshness, availability and restore report |
| C07 | C07-SEC-001..C07-SEC-005 | C07-CT-001..C07-CT-012 | INT-044/048 | E2E-001/002/012/013 | Phase 4 security gate | SEC: engine/source/IAM/KMS/privacy/artifact/audit evidence |
| C07 | C07-OBS-001..C07-OBS-006 | C07-CT-001..C07-CT-012 | INT-047/048 | E2E-001/002/012/014 | Phase 4 operations gate | OBS: run/facet/mapping/unresolved/coverage/lag/cost signals |
| C08 | C08-FR-001..C08-FR-015 | C08-CT-001..C08-CT-012 | INT-049..INT-055 | E2E-001/003/004/006/007/008/014 | Phase 4 deterministic analysis | FUNC: pinned request, byte-identical edges/holes/determinants/cache goldens |
| C08 | C08-NFR-001..C08-NFR-004 | C08-CT-001..C08-CT-012 | INT-055 | E2E-003/012/014 | Phase 4 plus Phase 9 scale | NFR: repository/candidate throughput, resource budget, availability/recovery |
| C08 | C08-SEC-001..C08-SEC-005 | C08-CT-001..C08-CT-012 | INT-049/055 | E2E-001/003/012/013 | Phase 4 security gate | SEC: sandbox/read-only checkout/no-network/secret scan/evidence audit |
| C08 | C08-OBS-001..C08-OBS-006 | C08-CT-001..C08-CT-012 | INT-054/055 | E2E-001/003/014 | Phase 4 operations gate | OBS: edges/holes/balance/cache/determinism/resource/stage correlation |
| C09 | C09-FR-001..C09-FR-017 | C09-CT-001..C09-CT-012 | INT-056..INT-062 | E2E-001/003/004/014 | Phase 7 agentic residual | FUNC: hole/task/tool/citation/abstention/cache/budget immutable reports |
| C09 | C09-NFR-001..C09-NFR-004 | C09-CT-001..C09-CT-012 | INT-057/062 | E2E-003/012/014 | Phase 7 plus Phase 9 scale/DR | NFR: budget/latency/queue fairness/gateway outage/cost/recovery report |
| C09 | C09-SEC-001..C09-SEC-006 | C09-CT-001..C09-CT-012 | INT-058/062 | E2E-001/003/012/013 | Phase 7 security/AI gate | SEC: bounded context/tools/model/Region/IAM/egress/injection/privacy audit |
| C09 | C09-OBS-001..C09-OBS-006 | C09-CT-001..C09-CT-012 | INT-061/062 | E2E-003/012/014 | Phase 7 operations gate | OBS: admitted/resolved/abstained/dropped/tool/token/cache/cost signals |
| C10 | C10-FR-001..C10-FR-015 | C10-CT-001..C10-CT-012 | INT-063..INT-069 | E2E-001/004/014 | Phase 8 opaque advisory | FUNC: enrollment/window/fingerprint/support/ambiguity/expiry/abstention report |
| C10 | C10-NFR-001..C10-NFR-004 | C10-CT-001..C10-CT-012 | INT-064/069 | E2E-012/014 | Phase 8 plus Phase 9 scale/DR | NFR: optional capacity/latency/kill/fail-open/cost/recovery evidence |
| C10 | C10-SEC-001..C10-SEC-006 | C10-CT-001..C10-CT-012 | INT-065/069 | E2E-001/012/013 | Phase 8 privacy gate | SEC: source-local key, minimum support, sensitive suppression, no-raw scan |
| C10 | C10-OBS-001..C10-OBS-006 | C10-CT-001..C10-CT-012 | INT-068/069 | E2E-001/012/014 | Phase 8 operations gate | OBS: source/window/eligible/suppressed/ambiguous/kill/cost signals |
| C11 | C11-FR-001..C11-FR-017 | C11-CT-001..C11-CT-012 | INT-070..INT-077 | E2E-001/005/012/013/014 | Phase 7 runtime evidence | FUNC: signed session/readiness/sequence/manifest/finally/completeness ledger |
| C11 | C11-NFR-001..C11-NFR-004 | C11-CT-001..C11-CT-012 | INT-077 | E2E-005/012/014 | Phase 7 plus Phase 9 load/DR | NFR: overhead/10x storm/drain/availability/RPO-RTO report |
| C11 | C11-SEC-001..C11-SEC-006 | C11-CT-001..C11-CT-012 | INT-071/072/075/077 | E2E-005/012/013 | Phase 7 privacy/hard-deny gate | SEC: integration attestation/key/schema/prod multilayer deny/canary audit |
| C11 | C11-OBS-001..C11-OBS-007 | C11-CT-001..C11-CT-012 | INT-074/075/077 | E2E-001/005/012/014 | Phase 7 operations gate | OBS: state/readiness/sequence/gap/truncation/flag/overhead timeline |
| C12 | C12-FR-001..C12-FR-017 | C12-CT-001..C12-CT-012 | INT-078..INT-085 | E2E-001/002/003/004/005/006/011/012/013/014 | Phase 2 immutable evidence | FUNC: prefix/schema/checksum/Object Lock/content-cache/index/integrity report |
| C12 | C12-NFR-001..C12-NFR-004 | C12-CT-001..C12-CT-012 | INT-085 | E2E-012/014 | Phase 2 plus Phase 9 scale/DR | NFR: write/read/load/storage/cost/CRR/restore RPO-RTO evidence |
| C12 | C12-SEC-001..C12-SEC-005 | C12-CT-001..C12-CT-012 | INT-084 | E2E-001/005/012/013 | Phase 2 security/records gate | SEC: IAM/KMS/private/Object Lock/legal hold/data events/privacy scan |
| C12 | C12-OBS-001..C12-OBS-007 | C12-CT-001..C12-CT-012 | INT-084/085 | E2E-001/012/014 | Phase 2 operations gate | OBS: write/read/conflict/integrity/replication/cache/cost/audit signals |

## 5. Trust, Governance, Publication and Experience Traceability

| Component | Requirement set | Component test | Integration test | E2E steel thread | Phase gate | Expected evidence |
|---|---|---|---|---|---|---|
| C13 | C13-FR-001..C13-FR-021 | C13-CT-001..C13-CT-012 | INT-086..INT-093 | E2E-001/002/003/004/005/006/011/014 | Phase 5 trust engine | FUNC: identity/dedup/conflict/G1-G5/drop/hole/coverage/two-axis checksum |
| C13 | C13-NFR-001..C13-NFR-004 | C13-CT-001..C13-CT-012 | INT-093 | E2E-004/012/014 | Phase 5 plus Phase 9 scale/DR | NFR: 100k/10M/500-job determinism/availability/recovery report |
| C13 | C13-SEC-001..C13-SEC-005 | C13-CT-001..C13-CT-012 | INT-086/093 | E2E-001/004/012/013 | Phase 5 security gate | SEC: policy/ABAC/evidence/provenance/no-single-score/audit proof |
| C13 | C13-OBS-001..C13-OBS-007 | C13-CT-001..C13-CT-012 | INT-092/093 | E2E-001/004/012/014 | Phase 5 operations/accuracy gate | OBS: candidates/drops/gates/holes/conflicts/coverage/confidence distribution |
| C14 | C14-FR-001..C14-FR-019 | C14-CT-001..C14-CT-012 | INT-094..INT-101 | E2E-001/006/007/008/010/011/014 | Phase 6 CI/freshness | FUNC: exact drift strings/determinants/signature/binding/deployment decision |
| C14 | C14-NFR-001..C14-NFR-004 | C14-CT-001..C14-CT-012 | INT-100 | E2E-010/012/014 | Phase 6 plus Phase 9 scale/DR | NFR: CI/binding/deploy rate/availability/divergence/RPO-RTO report |
| C14 | C14-SEC-001..C14-SEC-005 | C14-CT-001..C14-CT-012 | INT-096/097/100 | E2E-001/010/012/013 | Phase 6 supply-chain/security gate | SEC: scoped identities/signer separation/provenance/waiver/audit evidence |
| C14 | C14-OBS-001..C14-OBS-007 | C14-CT-001..C14-CT-012 | INT-099/100 | E2E-001/010/012/014 | Phase 6 operations gate | OBS: drift/binding/deploy decision/stale/hotfix/divergence/waiver signals |
| C15 | C15-FR-001..C15-FR-019 | C15-CT-001..C15-CT-012 | INT-102..INT-109 | E2E-001/002/003/004/005/006/011/014 | Phase 5 proposal/review | FUNC: immutable versions/diff/correction/decision/labels/corpus/checksums |
| C15 | C15-NFR-001..C15-NFR-004 | C15-CT-001..C15-CT-012 | INT-108/109 | E2E-011/012/014 | Phase 5 plus Phase 9 scale/DR | NFR: 100k diff/API/backlog/SLO/availability/recovery report |
| C15 | C15-SEC-001..C15-SEC-005 | C15-CT-001..C15-CT-012 | INT-105..INT-108 | E2E-001/011/012/013 | Phase 5 governance/security gate | SEC: SSO/SCIM/RBAC/ABAC/separation/no-direct-publish/privacy/audit |
| C15 | C15-OBS-001..C15-OBS-007 | C15-CT-001..C15-CT-012 | INT-108/109 | E2E-001/011/012/014 | Phase 5 operations/calibration gate | OBS: state/backlog/conflict/correction/labels/corpus/rates/publication signals |
| C16 | C16-FR-001..C16-FR-018 | C16-CT-001..C16-CT-012 | INT-110..INT-117 | E2E-001/006/011/012/014 | Phase 6 publication | FUNC: manifest/reservation/lease/fence/stage/verify/pointer/watermark/rebuild |
| C16 | C16-NFR-001..C16-NFR-004 | C16-CT-001..C16-CT-012 | INT-112/113/117 | E2E-011/012/014 | Phase 6 plus Phase 9 scale/DR | NFR: publication latency/concurrency/availability/rebuild RPO-RTO report |
| C16 | C16-SEC-001..C16-SEC-005 | C16-CT-001..C16-CT-012 | INT-110/112/116/117 | E2E-001/011/012/013 | Phase 6 publication-security gate | SEC: C16-only mutation/stage-commit separation/KMS/private/audit proof |
| C16 | C16-OBS-001..C16-OBS-006, C16-OBS-008 | C16-CT-001..C16-CT-012 | INT-113..INT-117 | E2E-001/011/012/014 | Phase 6 operations gate | OBS: attempt/lease/fence/stage/pointer/lag/reconcile/rebuild alarms |
| C17 | C17-FR-001..C17-FR-020 | C17-CT-001..C17-CT-012 | INT-118..INT-126 | E2E-001/002/003/004/005/009/010/011/012/014 | Phase 6 API/UI | FUNC: OpenAPI/client/query/search/evidence/review/timeline/export/UI result |
| C17 | C17-NFR-001..C17-NFR-005 | C17-CT-001..C17-CT-012 | INT-124..INT-126 | E2E-001/011/012/014 | Phase 6 plus Phase 9 scale/DR | NFR: one-hop/search/Web Vitals/500-rps/availability/version-lag report |
| C17 | C17-SEC-001..C17-SEC-006 | C17-CT-001..C17-CT-012 | INT-120/124/126 | E2E-001/011/012/013 | Phase 6 experience-security gate | SEC: SSO/RBAC/ABAC/WAF/browser/query injection/export/audit evidence |
| C18 | C18-FR-001..C18-FR-030 | C18-CT-001..C18-CT-012 | INT-127..INT-138 | E2E-001/005/007/009/010/011/012/013/014 | Phase 0 foundation and Phase 9 launch | FUNC: conformance/telemetry/reconcile/redrive/backup/rebuild/recovery/cost |
| C18 | C18-NFR-001..C18-NFR-005 | C18-CT-001..C18-CT-012 | INT-127..INT-138 | E2E-012/014 | Phase 9 enterprise scale/DR | NFR: audit latency/reconcile coverage/headroom/SLO/RPO-RTO/availability |
| C18 | C18-SEC-001..C18-SEC-008 | C18-CT-001..C18-CT-012 | INT-127..INT-138 | E2E-001/005/012/013/014 | Phase 0 and Phase 9 security/privacy | SEC: SCP/IAM/ABAC/KMS/network/egress/audit/no-payload/supply-chain proof |

## 6. Matrix Maintenance

- Adding a P0 requirement requires updating its component test matrix, affected
  INT rows, an E2E/phase gate and this register in the same change.
- Moving a requirement to P1/P2 requires product/architecture approval and a
  safe observable launch behavior; it is not a way to make a failed test pass.
- A test ID alone is not evidence. The linked immutable TestEvidenceManifest
  must name the requirement/range, expected/observed effects and cleanup.
- Traceability is evaluated on the exact release candidate. Evidence from
  incompatible contracts, policies, IaC, images or fixture versions is stale.
- Completion requires zero uncovered P0 IDs, zero failed required component/INT/
  E2E cases and zero expired waiver.


---

# state-and-error-model.md

# Shared State and Error Model

**Status:** Normative
**Applies to:** C01-C18

## 1. Design Rule

Transport delivery is at least once. Business state is idempotent by immutable
identity and conditional write. A successful retry or replay produces the same
observable business result, while preserving attempt-level operational history.

Every operation ends in a success state, a visible incomplete/conflict state,
a deterministic quarantine with an owner action, or a retry/redrive path. No
repository, deployment, hole, candidate edge, evidence envelope, proposal,
decision, or publication attempt disappears silently.

## 2. Common Operation Record

Every asynchronous consumer records:

- Idempotency identity and payload checksum.
- Contract, producer, policy, and software versions.
- First/last received time and delivery/attempt count.
- Current processing state and lease/fencing token where applicable.
- Immutable input/output `EvidenceReference` values.
- Error class/code, sanitized detail, dependency, retry eligibility, next
  attempt, and owner action.
- Common correlation identifiers and audit event reference.

Conditional creation chooses one of:

1. `NEW`: reserve the business identity and process.
2. `DUPLICATE_SAME_CONTENT`: acknowledge and return the prior result.
3. `DUPLICATE_CONFLICTING_CONTENT`: enter `CONFLICT`; preserve both checksums.
4. `IN_PROGRESS`: do not start a second writer; retry after lease or return the
   existing run.
5. `TERMINAL_REDRIVE_ALLOWED`: create a new attempt linked to prior history.

## 3. Error Classes

| Class | Meaning | Examples | Retry | Required terminal/next state |
|---|---|---|---|---|
| `TRANSIENT` | Same valid input may succeed without correction | Throttle, timeout, network reset, temporary Batch capacity, Neptune conflict | Bounded exponential backoff with jitter | Retry, then `POISON_REPEATED` after policy limit |
| `DETERMINISTIC_INVALID` | Input/policy/implementation cannot succeed unchanged | Schema failure, missing immutable identity, unsupported syntax, prohibited evidence | No automatic retry | Quarantine with reason and named remediation |
| `INCOMPLETE` | Expected evidence/input did not arrive | Missing inventory page, sidecar manifest, dependency, native facet | Retry only when missing dependency can arrive | Explicit incomplete state; block completion/promotion as specified |
| `CONFLICT` | Two individually valid claims cannot be selected safely | Identity collision, evidence disagreement, expected graph version changed | No blind retry | Preserve claims; deterministic resolver or human review |
| `POISON_REPEATED` | Delivery repeatedly fails beyond bounded policy | Consumer crash on one envelope, persistent dependency defect | DLQ; governed redrive only | DLQ/quarantine with alert, runbook, audit |

Privacy violations are always `DETERMINISTIC_INVALID`, even when the sender
could retry after removing the field. The invalid content is not copied into
operational logs; only allowlisted metadata, field name/path, reason code, and
content hash are retained under the security policy.

## 4. Retry Policy

- Retry only `TRANSIENT` failures or explicitly waiting `INCOMPLETE` states.
- Use capped exponential backoff with full jitter and a component-specific
  maximum elapsed time.
- Respect dependency `Retry-After` and service quotas.
- Do not retry schema, authorization, privacy, unsupported-language, missing
  immutable identity, or verification correctness failures.
- Each attempt rechecks lease/fencing ownership before side effects.
- Retries reuse business identity and output location; they do not create a new
  proposal, graph version, or accepted manifest unless the prior attempt did
  not make that business transition.
- Exhaustion produces a durable terminal record, metric, alert where P0, and
  owner/runbook link.

## 5. Quarantine

A quarantine record contains business identity, sanitized source metadata,
input checksum/reference where policy permits, contract/policy version, error
class/code, first/last occurrence, owner/domain, required correction, replay
eligibility, and correlation fields.

Required rules:

- Quarantine is queryable through C17 and measurable through C18.
- Corrected data creates a new source event/version and links to the quarantine.
- Replay requires authorization and records actor, reason, selected records,
  target contract/policy version, and new run IDs.
- An UNKNOWN classification quarantine cannot be auto-resolved by an LLM into
  an exclusion.
- A forbidden runtime envelope is never forwarded to Kinesis or the general
  evidence store.

## 6. DLQ, Redrive, and Replay

Every SQS work queue has a dedicated DLQ with:

- Maximum receive count based on operation cost and expected transience.
- Alarm on first Tier-1 item and on age/depth thresholds for other priorities.
- Runbook naming validation, dependency-health, code rollback, and replay steps.
- Redrive allowlist, batch limit, concurrency limit, and circuit breaker.
- Attempt linkage so redrive cannot bypass idempotency or create duplicate
  business effects.

EventBridge archive replay re-enters C03 validation and idempotency. Step
Functions redrive resumes from recorded stage outputs when valid rather than
repeating completed Batch work. Projection rebuild reads accepted manifests,
not mutable Neptune/OpenSearch state.

## 7. Baseline Run State

```text
REQUESTED -> INVENTORY -> CLASSIFICATION -> CONTEXT -> ANALYSIS
          -> VERIFICATION -> PROPOSAL -> AWAITING_REVIEW
          -> PUBLICATION -> COMPLETE
```

Alternative visible states: `INCOMPLETE`, `QUARANTINED`, `FAILED`, `CANCELLED`,
and `SUPERSEDED`.

- A critical `UNKNOWN` repository prevents `COMPLETE` but does not erase work
  completed for other repositories.
- A source inventory marked partial propagates an incomplete coverage reason.
- Human review time is not counted as workflow compute failure.
- Publication failure after approval remains redrivable; the proposal stays
  approved and the active pointer remains unchanged until fencing succeeds.

## 8. Incremental Run State

```text
RECEIVED -> NORMALIZED -> CLASSIFIED -> INVALIDATION_PLANNED
         -> ANALYSIS -> VERIFICATION -> DIFF_READY
         -> AWAITING_REVIEW -> BOUND -> PUBLISHED -> COMPLETE
```

- Documentation no-impact may transition from `CLASSIFIED` to `COMPLETE` with
  an immutable reason record.
- An event awaiting UNKNOWN resolution remains replayable from the normalized
  trigger.
- A deployment must reach a lineage decision: current binding, approved new
  binding, explicit stale/missing alert, or governed blocked deployment.
- Superseding an undeployed PR commit records both identities. A deployed
  artifact is never coalesced away.

## 9. Runtime Session State

```text
REQUESTED -> ENABLING -> READY -> COLLECTING -> DRAINING
          -> DISABLED -> COMPLETE
```

Terminal alternatives: `INCOMPLETE`, `TRUNCATED`, `FAILED`, `EXPIRED`, and
`CANCELLED`.

Normative transition rules:

- `READY` requires every expected sidecar to attest the integration environment,
  compatible version, matching digest, and active signed session.
- Test start before `READY` is rejected and audited.
- `DRAINING` waits for expected sequence ranges and closing manifests subject
  to the session deadline.
- The flag-disable action executes in a finally path for every outcome.
- Expiry is an independent kill switch and cannot be extended by a sidecar.
- `COMPLETE` requires all manifests, no sequence gap, matching checksum, and
  persisted evidence.
- `INCOMPLETE` or `TRUNCATED` cannot promote confidence.

## 10. Proposal State

```text
DRAFT -> AWAITING_REVIEW -> APPROVED -> PUBLISHING -> ACTIVE
                         -> REJECTED
                         -> SUPERSEDED
AWAITING_REVIEW -> DRAFT  (correction creates a new version)
PUBLISHING -> FAILED -> PUBLISHING  (governed redrive)
```

- State transitions use proposal ID/version plus expected current state.
- Reviewer corrections never mutate the prior proposal.
- A stale browser edit receives a conflict response containing current version;
  it cannot overwrite a newer decision.
- Rejection, supersession, and failed publication preserve evidence and audit.
- Approval records the exact proposal checksum reviewed.

## 11. Publication State and Fencing

```text
RESERVING -> STAGING -> VERIFYING -> COMMITTING -> PROJECTING -> ACTIVE
                         \-> FAILED_REDRIVABLE
RESERVING -> VERSION_CONFLICT
```

1. Conditional reservation requires expected active graph version.
2. The reservation issues target version, lease expiry, and monotonic fencing
   token.
3. Staging writes an immutable target-version namespace.
4. Verification checks accepted-manifest checksum, expected counts, endpoint
   identities, and target namespace.
5. The committing transaction rechecks reservation owner, unexpired lease,
   fencing token, and expected prior pointer.
6. A worker that loses lease can finish local work but cannot advance state.
7. OpenSearch projection lag does not roll back an already active Neptune graph;
   it produces a watermark/alert and idempotent projection retry.

## 12. Evidence Conflict State

Conflicts are data, not exceptions to discard:

- `IDENTITY_AMBIGUITY`: multiple canonical endpoints remain possible.
- `STRUCTURAL_DISAGREEMENT`: collectors disagree whether an edge/path exists.
- `DERIVATION_DISAGREEMENT`: mappings/transforms disagree.
- `VERSION_MISMATCH`: evidence refers to different commits/digests/environments.
- `SCHEMA_MISMATCH`: field/type/catalog versions cannot be reconciled.

C13 records all claims and precedence decisions. A deterministic higher-
authority claim may resolve a conflict automatically under versioned policy;
otherwise C15 exposes it for review. Conflict never becomes a high-confidence
edge merely by averaging sources.

## 13. Cancellation and Expiry

- Cancellation is authorized, idempotent, and records actor/reason.
- Batch cancellation cleans ephemeral workspaces and leaves immutable completed
  stage outputs addressable for audit.
- Runtime cancellation disables collection and drains only within the remaining
  privacy/session deadline.
- Lease/session expiry uses a service-side trusted clock.
- TTL may remove temporary lease/session-operational rows only after immutable
  terminal evidence exists. TTL never applies to accepted manifests, labels,
  decisions, graph pointers, or required audit history.

## 14. Operator Evidence

For every P0 failure/recovery test, retain:

- Trigger/input identity and checksum.
- Run/workflow/job/session/proposal/graph IDs.
- Before/after durable state.
- Attempt/retry/redrive history.
- Sanitized error class/code and emitted metrics/alarms.
- Operator action and runbook revision.
- Proof of idempotent result and absence of duplicate business effects.
- For privacy/security failures, the corresponding audit record without the
  prohibited content.


---

# test-strategy-and-fixtures.md

# Test Strategy and Canonical Fixtures

**Status:** Normative implementation, integration, and launch specification
**Applies to:** All C01-C18 code, contracts, infrastructure, clients and
operational workflows

## 1. Quality Contract

Testing proves business effects and invariants, not merely process exit codes.
Every requirement test states its fixture, immutable input versions, action or
fault, expected durable state/output, forbidden effects, observability, cleanup
and retained evidence. A successful API response, workflow state or empty diff
is insufficient if evidence, idempotency, coverage, authorization, projection
or recovery is not verified.

Required principles:

- Contract-first: producer and consumer tests use the same versioned schemas
  and golden examples from contracts/.
- Test-driven implementation: a requirement or defect begins with a failing
  test at the lowest layer that proves the behavior.
- Deterministic core: fixed inputs, deterministic clock, seeded randomness,
  stable IDs and pinned tool/model/policy versions produce reproducible results.
- Truth-aware assertions: S3 immutable artifacts plus control-state records are
  asserted before rebuildable Neptune/OpenSearch projections.
- Failure is first-class: invalid, incomplete, conflict, duplicate, out-of-
  order, timeout, partial dependency, privacy and authorization cases accompany
  every happy path.
- No hidden test bypass: environment flags may select a fixture/dependency but
  cannot disable identity, authorization, privacy, approval, fencing,
  idempotency, visibility or checksum validation.

## 2. Required Test Layers

| Layer | Runs on | Required coverage | Gate it can close |
|---|---|---|---|
| Static specification layer | Developer/CI | Documentation validator, schema lint, OpenAPI, IaC/policy lint, typecheck, dependency/license/secret checks | Documentation/foundation only |
| Component unit layer | Developer/CI | Pure parsing, identity, state transition, determinant, gate, confidence, redaction and query-bound logic | Individual deterministic requirement |
| Local contract layer | Developer/CI | Producer/consumer schema examples, compatibility, serializers, generated clients, fake clock/IDs and invalid corpus | Contract semantics without AWS claims |
| Local integration layer | CI container | Real language runtime, filesystem, parser/DB emulator/LocalStack where semantic fidelity is documented | Internal adapter/store logic only |
| Deployed integration layer | Ephemeral AWS account/Region | EventBridge/SQS/Step Functions/Batch/S3/DynamoDB/KMS/IAM/AppConfig/Kinesis/API and pairwise INT rows | Managed-service and cross-component gates |
| Production-shaped acceptance layer | Isolated staging accounts/primary plus standby Region | Neptune/OpenSearch, multi-account ABAC, full steel threads, security, load/fairness, chaos, backup/rebuild and DR | Launch and enterprise gates |
| Production verification layer | Production canary/synthetic | Read-only/safe nonserving canaries, SLO, audit delivery, replication, expiry and reconciliation | Continued operation; never replaces prelaunch tests |

The Local contract layer must be fast enough for every pull request. Emulators
do not close tests for Object Lock, IAM/SCP/resource policies, KMS grants,
Step Functions redrive, AppConfig validators, Kinesis ordering, Neptune
transactions, OpenSearch aliases, cross-Region replication or warm standby.
Those require the Deployed integration layer or Production-shaped acceptance
layer.

## 3. Canonical Fixture Catalog

All fixtures live under tests/fixtures/lineage/ with a fixture-manifest.json
containing fixture ID/version, file/object checksums, seed, expected IDs,
allowed data classification, golden outputs, owners and change approval.
Fixtures contain synthetic data only; no copied production payload or secret.

### FX-PILOT — representative 70-repository cohort

Purpose: validate pilot behavior across Spring Boot, FastAPI, Dask, Spark, dbt,
Airflow/SQL, shared libraries, IaC and documentation repositories.

Contents and oracle:

- 70 repositories across six application/domain owners, with active, archived,
  fork, template, infrastructure, shared-library and documentation examples.
- Included/excluded/mixed/unknown eligibility goldens and explicit evidence
  precedence/override/expiry.
- Commits, signed artifact digests, deployments, schemas, test associations,
  native runs and expected application context snapshots.
- Exact baseline nodes/edges, open holes, conflicts, coverage denominators,
  before/after proposal and active manifest checksums.
- At least one secret canary in a prohibited input path that must quarantine and
  never appear in output/telemetry.

### FX-MIXED-MONOREPO — path-scoped classification and lanes

Purpose: prove one repository can contain application runtime, Spark/dbt,
shared library, infrastructure and documentation paths without repository-wide
misclassification.

Oracle:

- Path rules assign Lane A/B or no expensive analysis exactly.
- A critical unknown path blocks completion and is visible in review.
- A change touching multiple paths coalesces one run while preserving every
  determinant and per-path outcome.
- Published URNs retain repository/path/application/environment/effective
  version without duplicate edges.

### FX-SHARED-LIBRARY — determinant fan-out

Purpose: prove library changes invalidate only actual version-range consumers
and respect artifact/deployment bindings.

Oracle:

- Two applications consume the changed exported symbol; one application pins a
  nonaffected version; one merely shares a repository label.
- Symbol/API change schedules the two actual consumers; documentation change
  closes with no lineage impact.
- A missing consumer index is detected by scheduled full-scan divergence and
  inventory/dependency reconciliation.

### FX-INFRASTRUCTURE — topology versus capacity

Purpose: distinguish endpoint/routing/binding changes from CPU/memory/replica
capacity changes.

Oracle:

- Endpoint/queue/topic/schema binding changes invalidate affected lineage.
- Capacity-only change records explainable no-impact and never invents an edge.
- An ambiguous template expression creates a visible hole/conflict rather than
  selecting a plausible resource.

### FX-CONTRACT — schema evolution and compatibility

Purpose: validate canonical contracts, OpenLineage facets, OpenAPI clients,
events and stored artifacts across supported versions.

Contents:

- Current and prior compatible producer/consumer pairs.
- Unknown additive fields at permitted boundaries, reordered JSON, Unicode,
  size limits, null/absent distinctions and additionalProperties violations.
- Unsupported major, semantic meaning change, checksum mismatch, missing
  immutable identity and privacy-prohibited property.
- Golden serialization/checksum/canonicalization and migration results.

Oracle: supported versions interoperate without meaning change; incompatible
inputs fail before durable business mutation with version/correlation evidence.

### FX-RUNTIME — metadata-only integration session

Purpose: validate C11 sidecar/session behavior and C13 structural-only use.

Contents:

- Three expected sidecars, two tests, signed integration attestation, artifact
  digest, schema registry and deterministic session key.
- Valid monotonic events/heartbeats/closing manifests plus duplicate, reorder,
  gap, truncation, timeout and late-event variants.
- Raw strings, encoded values, known secrets, low-cardinality sensitive fields,
  reversible fingerprints and production attestation attacks.

Oracle:

- Tests start only after all expected READY; disable executes in finally.
- Valid metadata closes COMPLETE with exact checksums; gaps/truncation close
  INCOMPLETE/TRUNCATED and cannot increase confidence.
- Every prohibited/production attempt is denied/quarantined/audited with no
  forbidden bytes in evidence, logs, traces or DLQs.

### FX-NATIVE — engine-native exactness

Contains Spark OpenLineage facets/plans, dbt manifest/catalog/run results and
Airflow/SQL examples bound to immutable artifacts. Goldens cover aliases,
select-star with schema, UDF/dynamic unresolved cases, multi-producer fields,
missing listeners and duplicate runs. Only engine-proven exact mappings are
derivational oracle.

### FX-STATIC-HOLES — deterministic and agentic boundary

Contains Spring Boot and FastAPI handlers, Dask code, configuration keys,
reflection/dynamic SQL, resolvable symbols and explicitly unsupported
constructs. C08 goldens define byte-identical provable edges and named Holes;
C09 goldens allow only search/read_span/resolve_symbol/call_graph/schema_lookup
over bounded facts and require file:line citations or abstention.

### FX-OPAQUE — advisory privacy boundary

Synthetic source-local windows include high/low cardinality, sensitive and
non-sensitive fields, insufficient observations, collision/ambiguity, key
expiry and nonmatching dependencies. Goldens contain only approved aggregate/
fingerprint metadata and advisory confidence caps; no raw value is stored.

### FX-REVIEW — immutable proposal and labels

Contains before/after proposals, exact material edges, two concurrent reviewer
versions, assignment/revocation, correction/reject/approve, stale base and bulk
accept. The corpus subfixture contains at least 200 material labelled edges
across six archetypes plus dynamic SQL, opaque UDF and multi-producer hard cases.
Bulk-unreviewed edges never enter correctness/correction statistics.

### FX-PUBLICATION — lease, fencing and projection

Contains approved/draft/rejected/unlocked manifests, two proposals against the
same expected prior graph, staged partial/corrupt targets, expired worker,
OpenSearch lag and prior versions. Oracle allows one current fencing token to
activate a fully verified immutable target and provides exact graph/search
rebuild checksums.

### FX-SECURITY — multi-account authorization and prohibited data

Defines enterprise identities, domains, roles/attributes, proposer/approver,
operators/break-glass, revoked users, cross-organization principals, resource
tags, KMS/network/egress policies and secret/payload canaries. Expected access
matrix covers positive, denied, redacted, no-existence-leak, audit and expiry.

### FX-SCALE-10K — enterprise load profile

Generates 10,000 repositories with recorded size/language/lane/domain/tier
distribution, 10,000 daily artifact decisions, graph degree distribution,
release burst, baseline backlog, reviewer activity and query mix. Seed and
generator version are fixed; the generated manifest/checksums are retained.

### FX-DR — backup, replication and regional recovery

Defines one consistent recovery point plus later writes within/outside RPO,
S3 versions/Object Lock/CRR, DynamoDB state/pointers/idempotency, proposal
history, accepted manifests, graph/search projections, audit and IaC versions.
The recovery oracle lists exact retained/lost-within-objective records, counts,
checksums, pointer/watermark, authorization and failback result.

## 4. Deterministic Time, Identity and Ordering

The test support package supplies:

- A deterministic clock with explicit advance/freeze and separate event,
  processing, lease, expiry and observation timestamps.
- UUIDv7/ULID fixture generators seeded by test case; canonical run, event,
  artifact, proposal, graph, session, evidence and operation IDs.
- Deterministic SHA-256 content and canonical JSON helpers.
- Seeded backoff/jitter, property-based generators and load distributions.
- Monotonic per-producer sequence generators plus deliberate duplicate,
  reorder, gap, rollover and delayed delivery controls.

Production code receives clock/ID/random interfaces; it must not patch global
time or rely on test-only branches. Tests involving AWS-issued timestamps record
tolerance and compare ordering/expiry behavior, not byte equality.

## 5. Contract and Golden Testing

For every schema:

1. Validate the canonical valid example and at least one invalid example per
   constraint/security boundary.
2. Serialize, canonicalize, checksum, deserialize and compare semantic equality.
3. Run current producer against current and supported prior consumers, and
   supported prior producer against current consumer.
4. Prove unsupported major/semantic change fails before side effects.
5. Verify missing versus empty identity, large-payload S3 reference/checksum,
   unknown field policy and redaction.
6. Snapshot only stable, reviewed output. Dynamic timestamps/IDs are normalized
   by fixture interfaces, never erased from correctness assertions.

Golden updates require a fixture version bump, human-readable semantic diff,
contract owner and affected consumer approval. A test is not fixed by blindly
regenerating a golden.

## 6. Fault Injection

The fault injection library names the boundary and activation count/time so a
test can fail before, during and after durable mutation:

- Throttle, timeout, connection reset, DNS/network partition and dependency
  unavailable.
- Duplicate, reorder, delay, drop, poison, old schema and checksum corruption.
- Process kill, Batch host interruption, Lambda timeout, Step Functions retry/
  redrive and callback loss.
- S3 partial/mismatched reference, DynamoDB conditional conflict/throttle,
  Kinesis shard throttle/sequence gap, AppConfig propagation/validator failure.
- Neptune partial stage/transaction conflict/writer loss and OpenSearch partial
  bulk/alias/watermark lag.
- KMS deny/key unavailable, secret rotation/revocation, IAM/ABAC/tag/ownership
  change, egress deny and audit delivery degradation.
- Availability Zone and Region loss, replication lag, stale backup, corrupt
  projection and recovery cutover/failback interruption.

Each fault test asserts the shared error class, retryability, terminal state,
idempotent durable effects, cleanup/finally, alarm/audit/timeline and safe
operator action. Fault hooks are unavailable in production application APIs.

## 7. Load, Performance and Fairness Profiles

| Profile | Workload | Mandatory assertions |
|---|---|---|
| LP-INGRESS-BURST | 10,000 events then 100 normalized triggers/second | No loss; duplicate safety; queue age/DLQ/latency and archive reconcile |
| LP-BASELINE-10K | FX-SCALE-10K full baseline | Complete within 12 hours at measured capacity; explicit incomplete; 70 percent planning utilization target measured |
| LP-RELEASE-STORM | Tier-1 deployments plus baseline/backfill | Tier-1 starts within five minutes p95; lower priority cannot starve forever |
| LP-INCREMENTAL | Representative determinant changes | Finish analysis within 30 minutes p95 excluding review/deferred runtime |
| LP-RUNTIME-10X | Ten times forecast sidecar events and sequence cardinality | Overhead budget, no silent sampling, complete/truncated semantics and finally cleanup |
| LP-PUBLICATION | 100 applications plus 100,000-edge changes | Per-app serialization, cross-app parallelism, 95 percent queryable within 60 seconds |
| LP-QUERY | 500 rps, high-degree/cyclic graph and concurrent reviewers | One-hop within two seconds p95, hard bounds, fair quotas, no mixed versions |
| LP-RECONCILE | Full inventory/deployment/evidence/pointer comparison | 100 percent scope, bounded cost/checkpoints and exact discrepancy counts |

Reports include workload generator/seed, quotas, infrastructure versions/sizes,
warm-up, duration, raw latency distributions, errors, saturation, cost,
autoscaling, backlog recovery and fairness by domain/tier. Averages alone do
not pass percentile SLOs.

## 8. Security, Privacy and Accessibility Testing

Security tests cover authentication, session expiry, least privilege,
cross-account trust/confused deputy, RBAC/ABAC/count/existence leakage, KMS,
network/public access, SSRF/egress, injection, supply chain, direct storage/
projection access, audit and break-glass.

Privacy tests seed unique canaries in raw, encoded, compressed and nested forms,
then scan S3/DynamoDB/Neptune/OpenSearch, queues/DLQs, workflow state, Batch
workspace/images, logs/traces/metrics/audit, exports, tickets and test reports.
The canary must exist only in the intentionally quarantined protected fixture
location and approved security incident record hash, never a copied value.

C17 primary journeys run automated semantic/accessibility checks on every
change and manual keyboard, screen-reader, 200 percent zoom/reflow, contrast and
reduced-motion checks before release. Graph views require an equivalent
navigable textual/table representation.

## 9. Test Environment and Data Lifecycle

Each deployed run creates a unique environment/testRunId prefix and tags every
resource/object/state record. Tests may reuse foundation accounts but not mutable
business state. Parallel runs use isolated application/environment/URN
namespaces and quota reservations.

Setup verifies account/Region, identity, network, KMS, contract/policy versions,
service quotas, clean namespace and fault-hook scope. Cleanup:

1. Disable runtime flags/sessions and stop optional workers in a finally path.
2. Cancel executions/exports and drain test-only queues after result capture.
3. Delete ephemeral mutable resources/state through IaC lifecycle.
4. Retain immutable evidence/audit required by the test under a dedicated test
   retention class; never weaken Object Lock to make cleanup pass.
5. Reconcile that no active pointer, public endpoint, role session, secret,
   orphan namespace or cost-incurring worker remains.

Cleanup failure fails the test and pages the environment owner. Synthetic
fixtures must never share production application IDs or destinations.

## 10. Retained Evidence and Result Schema

Every component, INT and E2E execution emits a signed TestEvidenceManifest:

- requirement/test IDs, result and failure reason;
- fixture IDs/versions/checksums and random seed;
- code/image/IaC/contract/policy/analyzer/model versions;
- account/Region/environment and approved resource configuration hashes;
- start/end/phase timestamps, deterministic clock plan and correlation IDs;
- actions/faults, expected and observed durable effects, forbidden-effect scan;
- S3/DynamoDB/Neptune/OpenSearch counts/checksums/versions/watermarks as relevant;
- API/UI/trace/audit/alarm/runbook/load/accessibility/security/recovery artifact
  references and checksums;
- cleanup/reconciliation status, owner/reviewer and waiver reference/expiry.

The manifest and material logs/reports/screenshots/traces are retained evidence
in C12/audit storage under the approved test class. Secrets/raw payloads are
redacted before evidence creation. A CI link without immutable manifest and
checksums is not launch evidence.

## 11. Flaky-Test Policy

The flaky-test policy is zero silent reruns and zero quarantined P0 gate tests.

- CI records the first failure before any diagnostic rerun. Automatic rerun may
  occur once only for tests explicitly tagged as transient-diagnostic; it does
  not convert the original result to pass.
- A nondeterministic test creates an owned defect with first-seen build, layer,
  fixture/seed, frequency, artifacts and seven-day remediation target.
- A temporarily quarantined P1/P2 test must keep executing nonblocking, display
  status, have owner/expiry and cannot be the sole proof of a P0 requirement,
  security/privacy invariant, publication fence, data integrity or RPO/RTO.
- Test code fixes must identify root cause: product race, environment capacity,
  unordered assertion, uncontrolled clock/ID, eventual-consistency bound or
  faulty fixture. Increasing sleep/retry without evidence is not a fix.
- Release candidates require all required cases pass on the same immutable
  build/environment set and no unexpired P0 quarantine.

## 12. Completion Rule

A component is successfully implemented only when:

- its component matrix passes at the required layer;
- every dependency-and-integration-matrix row touching it passes all six paths;
- applicable E2E steel threads, performance, security/privacy, accessibility,
  chaos and recovery gates pass;
- the implementation matches current contracts and no fixture golden was
  changed without approved semantic review;
- retained evidence and cleanup reconciliation are complete; and
- no open failure is hidden as success, empty, omitted telemetry or an
  indefinite waiver.


---

