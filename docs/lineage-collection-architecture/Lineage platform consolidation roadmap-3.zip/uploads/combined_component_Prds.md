# 00-system-context-and-architecture.md

# System Context and Architecture

**Status:** Normative shared specification
**Scope:** Baseline, incremental, and integration-runtime collection through
approved graph/search publication and operation

## 1. Product Boundary

The product inventories an enterprise software estate, collects element-level
lineage evidence, verifies and reconciles that evidence into reviewable
proposals, publishes only approved state, and exposes trusted traversal,
discovery, evidence, and operational status.

The platform owns lineage metadata and its audit history. It does not own
source repositories, deployment systems, data-plane payloads, business schemas,
test execution, or the applications it observes.

## 2. Authoritative Architecture Rules

> EventBridge routes, SQS buffers, Step Functions coordinates, Batch analyzes,
> S3 preserves, DynamoDB controls, Neptune traverses, OpenSearch discovers, and
> a user approves.

- OpenLineage plus governed extensions and the LineageSpec package are the
  external interchange contracts.
- S3 evidence, accepted manifests, and reviewer labels are immutable truth.
- DynamoDB holds operational state, idempotency, indexes, leases, fencing
  tokens, and active pointers.
- Neptune and OpenSearch contain rebuildable approved projections only.
- Application context and repository analysis are separately versioned and
  reusable.
- Deterministic/native evidence is preferred. An LLM receives only named holes.
- Runtime field evidence is integration-only and metadata-only. Production is
  hard-denied.
- Runtime execution strengthens structural confidence only; it cannot prove an
  internal derivation.
- Structural and derivational confidence are stored and rendered separately.
- Missing, stale, conflicting, incomplete, excluded, or unresolved work is
  always visible.
- Material proposals require explicit human approval at launch.

## 3. Actors and External Systems

| Actor/system | Supplies or consumes | Trust boundary |
|---|---|---|
| Application owner | Application selection, ownership corrections, proposal decisions | Enterprise SSO; domain-scoped authorization |
| Data/platform engineer | Schemas, native plans, operational remediation | Privileged metadata access; no payload access |
| Reviewer/approver | Edge corrections, rationale, approval/rejection | Optional separation of proposer and approver |
| Incident responder | Search and bounded blast-radius traversal | Active approved versions only by default |
| Platform operator | Redrive, reconciliation, rebuild, recovery | Break-glass and audited operations |
| SCM providers | Repositories, commits, pull-request events | Short-lived read credentials and controlled egress |
| Test Automation Service | Application-to-repository and scenario mappings | Governed cross-account/API integration |
| Deployment systems | Immutable artifact digests and environment decisions | Signed/authenticated event source |
| Schema/catalog systems | Canonical datasets, fields, types, contracts | Read-only metadata integration |
| Spark/dbt/Airflow | Native run and column-plan evidence | Engine/run identity and artifact binding |
| Integration applications | Metadata-only sidecar evidence | Signed expiring session; integration environment attestation |
| Production applications | Deployment and ordinary interaction context | No instrumented field-evidence grant |

## 4. Component Topology

```mermaid
flowchart LR
    EXT["External inventory, SCM, deploy, schema, test, native sources"]
    C01["C01 Contracts and identity"]
    C02["C02 Adapters and inventory"]
    C03["C03 Intake and queues"]
    C04["C04 Eligibility and routing"]
    C05["C05 Context, dependencies, determinants"]
    C06["C06 Orchestration and scheduling"]
    C07["C07 Lane B native"]
    C08["C08 Lane A deterministic"]
    C09["C09 Lane A agentic"]
    C10["C10 Lane C opaque"]
    C11["C11 Runtime session and sidecar"]
    C12["C12 Evidence and cache"]
    C13["C13 Reconcile, verify, confidence"]
    C14["C14 CI, binding, freshness"]
    C15["C15 Proposal, review, corpus"]
    C16["C16 Fenced publication"]
    C17["C17 APIs, UI, timeline"]
    C18["C18 Security, operations, DR"]

    EXT --> C02 --> C03 --> C04 --> C05 --> C06
    C01 -. "schemas and URNs" .-> C02
    C01 -. "schemas and URNs" .-> C07
    C01 -. "schemas and URNs" .-> C08
    C01 -. "schemas and URNs" .-> C11
    C06 --> C07
    C06 --> C08 --> C09
    C06 --> C10
    C06 --> C11
    C07 --> C12
    C08 --> C12
    C09 --> C12
    C10 --> C12
    C11 --> C12
    C12 --> C13 --> C15 --> C16 --> C17
    C14 <--> C06
    C14 <--> C15
    C18 -. "controls and observes" .-> C01
    C18 -. "controls and observes" .-> C06
    C18 -. "controls and observes" .-> C16
    C18 -. "controls and observes" .-> C17
```

## 5. Component Responsibilities

| ID | Component | Owns | Key output |
|---|---|---|---|
| C01 | Contracts and identity | Canonical schemas, URNs, aliases, resolution | Versioned contracts and resolved IDs |
| C02 | Adapters and inventory | External discovery and immutable inventory snapshots | `RepositoryInventorySnapshot` |
| C03 | Intake and queues | Validation, normalization, idempotency, routing, buffering | `EventEnvelope` plus queue decision |
| C04 | Eligibility and routing | Repository/path classification and Lane A/B/C assignment | `RepositoryEligibilityDecision` |
| C05 | Context and indexes | Application snapshot, dependencies, determinants | `ApplicationContextSnapshot`, indexes |
| C06 | Orchestration | Baseline/incremental/runtime/publish/reconcile workflows | `CollectionRun` stage history |
| C07 | Lane B | Engine-native exact column evidence | `NativeLineageRun` |
| C08 | Lane A deterministic | Provable edges, determinants, explicit holes | `DeterministicAnalysisPackage` |
| C09 | Lane A agentic | Bounded cited hole resolution | `AgentResolution` |
| C10 | Lane C | Advisory opaque-system fingerprint evidence | `OpaqueEvidencePackage` |
| C11 | Runtime | Signed sessions and metadata-only execution evidence | `RuntimeEvidenceSession` and manifest |
| C12 | Evidence/cache | Immutable artifacts and content-addressed reuse | `EvidenceReference` and cache records |
| C13 | Trust engine | Merge, G1-G5, conflicts, coverage, two confidence axes | `VerifiedLineageCandidateSet` |
| C14 | CI/freshness | Drift, signed artifact binding, deployment freshness | `ArtifactLineageBinding` and decisions |
| C15 | Review/corpus | Proposal state, corrections, decisions, labels | `LineageProposal`, `ReviewLabel` |
| C16 | Publication | Fenced graph version and rebuildable projections | `AcceptedLineageManifest`, graph pointer |
| C17 | Experience | Query/search/review/timeline APIs and UI | User-visible approved lineage and status |
| C18 | Operations | Common security, telemetry, runbooks, reconcile, recovery | Audit, alarms, recovery evidence |

## 6. Baseline Collection Flow

1. A user or governed schedule selects a business application.
2. C02 queries the Test Automation Service, SCM, deployment, schema/catalog,
   native-lineage, and selected CloudWatch context sources. It writes a complete
   or explicitly partial inventory snapshot through C12.
3. C03 accepts a baseline trigger, assigns correlation fields, and routes it to
   the baseline queue. C06 starts one visible baseline workflow.
4. C04 classifies every repository or monorepo workload path before expensive
   checkout. `UNKNOWN` blocks critical baseline completion.
5. C05 creates the application context and indexes libraries, infrastructure
   bindings, contracts, test scenarios, and initial determinants.
6. C06 schedules C07-C11 according to classification, substrate lane, policy,
   and evidence need. Work is bounded by priority, domain, and downstream quota.
7. Collectors write immutable outputs to C12. They return small checksummed S3
   references, not large workflow payloads.
8. C13 resolves identities, deduplicates candidates, applies G1-G5, returns
   dropped-edge holes, records conflicts/coverage, and assigns structural and
   derivational bands.
9. C15 produces an immutable baseline proposal with included/excluded/mixed/
   unknown counts and before/after evidence.
10. A reviewer corrects, rejects, or approves. C16 publishes only an approved
    accepted manifest and C17 shows the active graph and complete timeline.

Baseline completion is not merely a successful workflow state. A critical
active repository cannot remain unknown; incomplete evidence and unresolved
holes must be visible; and no graph becomes active before approval and fenced
publication.

## 7. Incremental Collection Flow

1. C03 validates an SCM event by commit SHA or a deployment event by artifact
   digest and environment. Missing immutable identity is quarantined, never
   deduplicated under an empty key.
2. C04 loads repository class and path policy. C05 resolves affected
   determinants, consumers, bindings, contracts, and test mappings.
3. C06 schedules targeted analysis. A shared-library change affects consuming
   applications only when their dependency/determinant relationship requires
   it; capacity-only infrastructure changes record no lineage impact.
4. C13 compares results with the accepted baseline and emits added, removed,
   transform, confidence, coverage, conflict, and unresolved differences.
5. C15 presents a new immutable proposal. C14 binds an approved LineageSpec
   package to the built artifact and reconciles every deployed artifact,
   including emergency/hotfix paths.
6. C16 publishes the approved version, then C17 reads through the new active
   pointer. A scheduled full scan measures incremental divergence; any non-zero
   divergence is a defect.

## 8. Integration Runtime Evidence Flow

1. C06 requests named integration scenarios for a repository commit and
   artifact digest.
2. C11 creates a signed, expiring `integration` session. AppConfig validators,
   organizational policy, and workload IAM deny production targets.
3. All expected sidecars attest environment and report `READY`; only then may
   tests begin.
4. Sidecars emit allowlisted schemas, field paths/types, direction, trace/test
   IDs, artifact identity, session-keyed irreversible fingerprints, monotonic
   sequences, and closing checksums. Raw or encoded payload values are forbidden.
5. CloudWatch receives evidence; a validator assigns explicit session/sidecar
   Kinesis partitioning; C12 persists validated immutable evidence.
6. C11 drains, verifies manifests, disables the flag in a finally path, and
   closes `COMPLETE`, `INCOMPLETE`, `TRUNCATED`, `FAILED`, `EXPIRED`, or
   `CANCELLED`.
7. C13 may strengthen structural confidence only for `COMPLETE` evidence.
   Runtime evidence never proves the transform and never excludes an unexecuted
   path.

## 9. Proposal and Publication Flow

1. C13 produces deterministic proposal inputs relative to an expected base
   graph version.
2. C15 transitions `DRAFT -> AWAITING_REVIEW`. A correction creates a new
   immutable draft version; rejection and supersession preserve history.
3. Approval creates a checksummed `AcceptedLineageManifest` naming reviewer,
   policy, proposal version, and expected prior graph version.
4. C16 conditionally reserves the application, issues a target version, lease,
   and fencing token, stages an immutable Neptune namespace, and checks counts
   and checksums.
5. One DynamoDB transaction advances the active pointer only if the reservation,
   token, and expected prior version still match. An expired worker cannot win.
6. OpenSearch refreshes from the active version and records a watermark. Query
   responses expose projection lag; failed projections are rebuildable from the
   accepted manifest.

## 10. AWS Runtime Mapping

| Concern | Approved service | Boundary rule |
|---|---|---|
| Event routing/replay | EventBridge rules/archive | Does not provide worker backpressure |
| Durable priority work | SQS Standard queues/DLQs | At-least-once is normal |
| Workflow coordination | Step Functions Standard/Distributed Map | Large payloads use S3 references |
| Short control action | Lambda | No repository clone or full SCA |
| Heavy analysis | AWS Batch | Ephemeral encrypted workspace |
| Bounded residual inference | Bedrock via enterprise gateway | Named holes and approved tools only |
| Runtime flag/session | AppConfig plus DynamoDB | Integration only; expiring and signed |
| Runtime transport | CloudWatch validator to Kinesis | Per-sidecar order; no silent sampling |
| Immutable truth | S3 with KMS/versioning/Object Lock | Evidence and manifests are append-only |
| Operational state | DynamoDB | Conditional idempotency and fencing |
| Approved traversal | Neptune | Immutable version namespaces |
| Approved discovery | OpenSearch | Watermarked rebuildable projection |
| Experience | API Gateway plus web application | Domain RBAC and evidence ABAC |
| Audit/operations | CloudWatch, ADOT/X-Ray, CloudTrail | Common correlation contract |

## 11. Authoritative Data Ownership

| Artifact | Authority | Projection/index |
|---|---|---|
| Inventory snapshot | S3 | DynamoDB inventory watermark |
| Eligibility decision | S3 history | DynamoDB effective registry |
| Application context | S3 | DynamoDB lookup/indexes |
| Analysis/native/agent/runtime packages | S3 | Content-addressed DynamoDB index |
| Proposal versions | S3 | DynamoDB lifecycle state |
| Review labels | S3/analytics catalog | Calibration aggregates |
| Accepted manifest | S3 Object Lock | DynamoDB active pointer |
| Active approved lineage | Accepted manifest plus active pointer | Neptune/OpenSearch |
| Run stage history | DynamoDB plus immutable audit | C17 timeline read model |

## 12. Platform Invariants

1. Every external trigger is rejected, quarantined, coalesced with recorded
   identities, or mapped to a visible run; it is never silently dropped.
2. Every repository is included, excluded with reason/evidence, mixed by path,
   or unknown and awaiting review.
3. Every candidate edge has canonical endpoints, provenance, artifact/effective
   version, evidence references, and independent confidence axes.
4. Every named hole remains open, becomes closed with evidence, or is returned
   open with a reason. Counters balance by immutable hole identity.
5. A service interaction alone is not a lineage edge.
6. OTel or sidecar execution alone cannot set derivational `VERIFIED`.
7. Sole-LLM provenance cannot reach the highest band on either axis.
8. Incomplete runtime evidence cannot promote confidence.
9. CI reports drift; it does not claim semantic validation.
10. A deployed digest without a lineage decision raises an alert.
11. An accepted manifest and reviewer label are never updated in place.
12. A graph pointer advances only through a valid fencing token and expected
    prior version.
13. Query/read projections can be deleted and rebuilt without losing approved
    state.
14. Production cannot enable or submit instrumented runtime field evidence.
15. Privacy violations are deterministic invalid input, quarantined and audited,
    not retried.

## 13. Capacity and SLO Envelope

- Inventory and baseline capacity: 10,000 repositories in 12 hours, initially
  tested with 500 Batch job slots and measured 70% planning utilization.
- Trigger intake: accept a 10,000-event burst without loss and sustain 100
  normalized triggers per second.
- Incremental analysis: 30 minutes p95 excluding human review and deferred
  runtime evidence.
- Tier-1 start latency: five minutes p95 during baseline/backfill.
- Projection visibility: 95% of approved changes queryable within 60 seconds.
- Bounded one-hop graph query: two seconds p95.
- Warm-standby objectives: 15-minute RPO and four-hour RTO.

These are launch gates requiring production-like load and quota evidence, not
guarantees inferred from service documentation.

## 14. Correlation Contract

Every applicable event, log, metric, trace, audit record, artifact metadata,
and user timeline stage carries:

`collectionRunId`, `applicationId`, `repositoryId`, `commitSha`,
`artifactDigest`, `runtimeSessionId`, `proposalId`, `graphVersion`, `traceId`,
`policyVersion`, and `analyzerVersion`.

Fields not yet known are absent, never an empty string used as identity. Child
operations retain the parent run and trace relationships.

## 15. Launch Definition

The platform is launch-ready only when all P0 component requirements and every
interface test pass; the mixed-application steel thread reaches an approved,
queryable graph; privacy and production hard-deny gates pass; duplicate/replay,
fenced publication, rebuild, chaos, load/fairness, and regional recovery tests
retain evidence; and all waivers are scoped, approved, and unexpired.


---

# 01-canonical-contracts-and-identity.md

# C01 Canonical Contracts, URNs, and Identity Resolution PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C01 |
| Status | Approved for implementation |
| Launch phase | Foundation |
| Criticality | P0; every downstream edge and artifact depends on stable identity |
| Primary owner | Lineage platform contracts team |
| Required approvers | Architecture, data governance, security, graph/query owners |
| Upstream dependencies | Governed organization/environment registry; schema/catalog source identifiers |
| Downstream dependencies | C02-C18 |
| Authoritative sources | Component package design §§6, 9; AWS architecture principles 1-4; element-level v2 open question on cross-lane identity |

## 2. Purpose and Outcomes

C01 gives every component the same meaning for an application, repository,
artifact, service, job, dataset, field, endpoint, and effective version. It
publishes versioned schemas and resolves source-native aliases into canonical
URNs without hiding ambiguity.

Measurable outcomes:

- 100% of persisted lineage candidates have resolvable canonical source and
  target URNs or an explicit `AMBIGUOUS_IDENTITY`/`UNKNOWN_IDENTITY` result.
- Replaying the same identity inputs and registry version produces a byte-
  identical resolution result.
- No two distinct authoritative assets acquire the same active canonical URN
  in contract and collision tests.
- New minor contract versions pass every registered producer-consumer
  compatibility suite before release.

## 3. Scope and Non-Goals

### In scope

- Canonical URN grammar, normalization, comparison, parsing, and rendering.
- Entity kinds, environment and effective-version identity.
- Alias registration and source-specific resolvers.
- Resolution precedence, ambiguity, conflict, split, merge, deprecation, and
  redirect behavior.
- Contract registry, semantic version policy, schema publication, examples,
  canonical serialization, and checksums.
- Batch and single-item resolution APIs plus local contract libraries.

### Non-goals

- Discovering repositories/assets (C02).
- Deciding repository eligibility or analysis lane (C04).
- Deciding whether a candidate edge is true (C13).
- Mutating accepted lineage to repair identity. A correction creates a new
  alias/registry version and a new proposal/version.
- Guessing an identity from similarity when multiple candidates remain.

## 4. Actors and Use Cases

| Actor | Job |
|---|---|
| Contract author | Publish a reviewed schema version and examples |
| Adapter/collector developer | Convert source-native IDs into canonical identity inputs |
| Analyzer | Refer to stable fields across files, schemas, engines, and versions |
| Reconciliation engine | Deduplicate evidence and surface unresolved identity conflicts |
| Reviewer | Understand aliases, redirects, environment, and version evidence |
| Query client | Address the active asset and request aliases/version history |
| Operator | Diagnose collision, registry lag, invalid contract, or compatibility failure |

Primary use cases:

1. Resolve a Spark OpenLineage field, a dbt catalog column, a static-parser
   symbol, and an integration sidecar field to the same dataset/field URN.
2. Keep the same artifact deployed to integration and production distinct while
   linking both to the same repository and application.
3. Bind an edge to artifact digest `sha256:...` without changing the logical
   identity used for current traversal.
4. Preserve two plausible candidates as ambiguity rather than selecting one by
   string similarity.
5. Migrate a renamed dataset through an explicit redirect without rewriting
   immutable evidence or accepted manifests.

## 5. Component Boundary

### Owned behavior

- The normative grammar under **Canonical URN Grammar**.
- The contract and alias registries and their immutable version history.
- Deterministic resolution against a pinned registry version.
- Contract artifacts in `contracts/{schemas,openapi,examples}/` and generated
  typed clients/models.

### Upstream inputs

- Governed organization/environment values.
- Source-native system, account, namespace, object, version, and element path.
- Catalog/schema authoritative IDs and source priority.
- Explicit human-governed alias, merge, split, and redirect decisions.

### Downstream outputs

- `CanonicalUrn`, `IdentityAliasRecord`, and `IdentityResolutionResult`.
- Contract schemas, examples, compatibility results, and released client models.

### Forbidden behavior

- Returning one candidate when precedence cannot break a tie.
- Omitting environment from environment-dependent identity.
- Using display labels, mutable repository names, branch names, or empty digest
  values as immutable identity.
- Updating evidence/manifests when an alias changes.
- Releasing a breaking schema change as a minor or patch version.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C01-FR-001 | C01 must parse, validate, normalize, and render the Canonical URN Grammar with round-trip equality for every registered entity kind. | P0 |
| C01-FR-002 | A canonical URN must include organization, environment, kind, namespace, name, and the effective version/element path when required by that kind. | P0 |
| C01-FR-003 | C01 must preserve a logical unversioned identity and separately represent artifact/schema/effective versions so current traversal and historical evidence are both addressable. | P0 |
| C01-FR-004 | Resolution must be deterministic against an explicit registry version and emit the registry/policy version used. | P0 |
| C01-FR-005 | C01 must implement Resolution Precedence: governed catalog ID, authoritative schema ID, explicit registered alias, deployment binding, source-native stable ID, then heuristic candidates requiring review. | P0 |
| C01-FR-006 | Zero candidates must return `UNKNOWN_IDENTITY`; multiple top-precedence candidates must return `AMBIGUOUS_IDENTITY` with all candidate URNs and evidence. | P0 |
| C01-FR-007 | C01 must reject an alias that creates an active collision, an environment leak, an alias cycle, or a redirect cycle. | P0 |
| C01-FR-008 | Alias/redirect/merge/split decisions must be immutable, effective-dated, reviewer-attributed, and superseded only by a new registry version. | P0 |
| C01-FR-009 | Field element paths must use a canonical escaped path representation and preserve nested-array/map semantics without case folding the authoritative field name. | P0 |
| C01-FR-010 | The contract registry must publish machine-readable schema ID, semantic version, owner, Producer, Consumers, compatibility mode, valid/boundary/invalid examples, and release checksum. | P0 |
| C01-FR-011 | C01 must block contract release when a registered producer or consumer compatibility suite fails. | P0 |
| C01-FR-012 | Canonical serialization must sort object keys and unordered identity inputs, normalize Unicode and timestamps, and produce a stable SHA-256 checksum. | P0 |
| C01-FR-013 | Batch resolution must preserve input order, return an outcome for every item, and isolate deterministic invalid items without failing valid neighbors. | P0 |
| C01-FR-014 | Registry reads must support an explicit version and an effective-at timestamp; a run must not observe mixed registry versions. | P0 |
| C01-FR-015 | Deprecated URNs must remain resolvable for historical evidence and return a redirect/deprecation record; they must never be silently rewritten in immutable artifacts. | P0 |
| C01-FR-016 | A new entity kind or alias-source type must be registered as a typed versioned variant before use; arbitrary extension maps are prohibited. | P1 |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C01-NFR-001 | Single cached resolution must complete within 20 ms p95 and a 1,000-item batch within 500 ms p95 in the production-like performance environment. | P0 |
| C01-NFR-002 | C01 must sustain 5,000 resolution operations per second per Region with horizontal scaling and no cross-tenant cache leakage. | P0 |
| C01-NFR-003 | Registry reads must remain available at 99.95% monthly; callers must be able to use a previously pinned local immutable registry snapshot during a transient control-plane outage. | P0 |
| C01-NFR-004 | Resolution results for identical inputs, registry version, and policy version must be byte-identical across supported language implementations. | P0 |

## 7. Data and Durable State

### Canonical URN Grammar

```text
urn:lineage:<organization>:<environment>:<kind>:<namespace>:<name>[@<effective-version>][#<element-path>]
```

Rules:

- The literal scheme is lower-case `urn:lineage`.
- Organization, environment, kind, and namespace are governed lower-case slugs
  matching `[a-z0-9][a-z0-9._-]{0,127}`.
- Reserved characters in name/path segments use uppercase percent encoding.
- Unicode is NFC-normalized before encoding.
- Kind-specific case rules are registry data. Comparison never uses the host
  locale.
- Effective artifact versions use `sha256-<hex>`; schema/job versions use a
  typed version prefix registered for that kind.
- Nested element paths use JSON Pointer escaping; a kind discriminator retains
  array element, map key, map value, and wildcard semantics.

### Durable records

`IdentityAliasRecord` contains alias source/system/account/native ID, canonical
URN, confidence authority (not edge confidence), evidence, registry version,
effective/expiry, status, reviewer, rationale, prior record, and checksum.

`IdentityResolutionResult` contains input checksum, normalized input, registry
and policy versions, status (`RESOLVED`, `UNKNOWN_IDENTITY`,
`AMBIGUOUS_IDENTITY`, `INVALID_IDENTITY`, `DEPRECATED_IDENTITY`), canonical URN
when singular, candidate list/evidence, redirects, and decision checksum.

S3 stores immutable registry releases and history. DynamoDB holds the effective
alias lookup index keyed by source/account/native identity plus registry
version. Local generated snapshots are checksummed read caches, not authority.

## 8. Interfaces and Contracts

### Resolve one identity

```http
POST /v1/identity:resolve
Idempotency-Key: <input-checksum+registry-version>
```

Request names schema ID/version, registry version (or `effectiveAt`), source
system/account, entity kind, namespace/name, environment, effective version,
element path, authoritative IDs, and evidence references. Response is an
`IdentityResolutionResult`. HTTP mapping:

- `200`: resolved, deprecated, unknown, or ambiguous business outcome.
- `400`: invalid contract/URN input.
- `409`: requested registry version/effective time conflict.
- `429/503`: transient capacity/dependency failure with retry hint.

Unknown/ambiguous are 200 because they are modeled outcomes C13/C15 must expose,
not malformed requests.

### Resolve batch

`POST /v1/identity:resolveBatch` accepts at most 1,000 items and 2 MiB. Each item
has its own input identity and result; all items use one registry/policy version.

### Register alias decision

`POST /v1/identity-alias-decisions` requires governance authorization,
idempotency key, evidence, rationale, effective time, expiry if temporary, and
expected current alias version. It produces a new registry candidate release;
it does not mutate the active registry until review/release succeeds.

### Contract registry

- `GET /v1/contracts/{contractId}/versions/{version}` returns schema, metadata,
  examples, checksum, and compatibility declaration.
- `POST /v1/contracts:checkCompatibility` returns producer and consumer suite
  results against the proposed version.
- Release emits `contract.version.released` through C03 after immutable storage.

All schemas and shared types conform to the [contract catalog](shared/contract-catalog.md).

## 9. Processing and State Model

### Resolution Precedence

For a pinned registry version:

1. Validate and normalize contract input.
2. If an exact governed catalog/schema ID maps to one active canonical URN,
   return it.
3. Otherwise resolve an explicit source-native alias.
4. Otherwise resolve an immutable deployment/artifact binding.
5. Otherwise compare a source-native stable identity under registered kind
   rules.
6. Return heuristic candidates only as `AMBIGUOUS_IDENTITY` or
   `UNKNOWN_IDENTITY`; never promote them automatically.
7. Apply effective-dated redirects to the result metadata, without rewriting
   the queried/evidence identity.
8. Canonically serialize and checksum the complete result.

The resolver evaluates all candidates within a precedence tier before
selection. Multiple active matches at the highest non-empty tier are a
conflict, even when one string is more similar.

### Registry lifecycle

```text
DRAFT -> COMPATIBILITY_CHECKED -> APPROVED -> ACTIVE -> SUPERSEDED
                      \-> REJECTED
```

Activation is atomic by registry version. A run pins one `ACTIVE` version at
start and records it in all outputs. Rollback activates a prior immutable
release as a new active-pointer event; it does not delete the failed release.

## 10. Failure Semantics

| Code | Class | Behavior |
|---|---|---|
| `INVALID_URN` | `DETERMINISTIC_INVALID` | Reject item with failing grammar segment; do not retry |
| `UNKNOWN_IDENTITY` | `INCOMPLETE` business outcome | Preserve input/evidence; surface coverage gap |
| `AMBIGUOUS_IDENTITY` | `CONFLICT` | Return every top candidate; route to C15 when material |
| `ALIAS_COLLISION` | `CONFLICT` | Reject registry proposal; identify both active records |
| `ALIAS_CYCLE` | `DETERMINISTIC_INVALID` | Reject registry proposal with cycle path |
| `REGISTRY_VERSION_NOT_FOUND` | `DETERMINISTIC_INVALID` | Quarantine requesting run/config |
| `REGISTRY_TEMPORARILY_UNAVAILABLE` | `TRANSIENT` | Use pinned verified local snapshot or bounded retry |
| `CONTRACT_INCOMPATIBLE` | `DETERMINISTIC_INVALID` | Block release and retain suite results |
| `DUPLICATE_CONFLICTING_CONTENT` | `CONFLICT` | Preserve checksums; no last-write-wins |

The common [state and error model](shared/state-and-error-model.md) governs
retry, quarantine, DLQ, redrive, replay, and audit.

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C01-SEC-001 | Registry release and alias decisions must require enterprise identity, least-privilege governance role, rationale, evidence, and CloudTrail audit. | P0 |
| C01-SEC-002 | Read APIs must enforce organization/domain isolation and must not expose aliases/evidence from an unauthorized tenant or sensitive metadata class. | P0 |
| C01-SEC-003 | Registry artifacts and indexes must use TLS, KMS encryption, private endpoints, versioning, PITR where applicable, and separate read/write roles. | P0 |
| C01-SEC-004 | Identity input and logs must not contain payload values, credentials, authentication tokens, or arbitrary source attributes; logs use allowlisted fields and hashes. | P0 |
| C01-SEC-005 | Generated client packages must be signed and consumers must verify package integrity and schema checksum in CI. | P1 |

Threat cases include alias poisoning, Unicode/confusable collisions, cross-
environment aliasing, tenant key omission, redirect cycles, registry rollback,
and oversized/pathological parse input. Tests must cover each.

## 12. Scale, Performance, and Availability

- Size for at least 10,000 repositories, 400+ pilot datasets growing to millions
  of fields, all historical artifact versions, and 10,000 deployment decisions
  per day.
- Batch resolution limit is 1,000 items/2 MiB; larger jobs page with one pinned
  registry version.
- Cache keys include organization, environment, registry version, policy
  version, and normalized input checksum.
- Cache TTL may evict resolution results but never registry history.
- DynamoDB partitioning must avoid a single organization/environment hot key;
  load tests use the expected largest namespace and high-alias fields.
- Regional registry artifacts replicate under C18's 15-minute RPO. A verified
  local snapshot supports read continuity within the four-hour RTO objective.

## 13. Observability

| ID | Signal | Required dimensions/alert | Priority |
|---|---|---|---|
| C01-OBS-001 | Resolution count/latency/status | organization, source, kind, registry version; alert p95/SLO | P0 |
| C01-OBS-002 | Unknown/ambiguous/collision rate | application, source, kind, owner; alert on Tier-1 material spike | P0 |
| C01-OBS-003 | Contract compatibility result | contract/version, producer/consumer, failure code | P0 |
| C01-OBS-004 | Registry activation/rollback | actor, old/new version, checksum, rationale; immutable audit | P0 |
| C01-OBS-005 | Cache hit/miss and snapshot age | Region, registry version; alert if pinned snapshot exceeds policy | P1 |

Logs and traces carry the common correlation contract where a collection run
exists. Resolution decisions expose evidence references but not sensitive
metadata bodies. The C17 timeline links material identity conflicts to the
affected run and proposal.

## 14. Acceptance Criteria

| ID | Acceptance criterion |
|---|---|
| C01-AC-001 | Given canonical examples for every registered kind, when each is parsed, normalized, rendered, and parsed again, then the semantic identity and canonical bytes are equal. |
| C01-AC-002 | Given Spark, dbt, parser, and sidecar aliases for one field, when resolved against one registry version, then all return the same environment-scoped field URN and evidence records the chosen precedence. |
| C01-AC-003 | Given two equal-precedence authoritative candidates, when resolved, then C01 returns `AMBIGUOUS_IDENTITY` with both candidates and no selected URN. |
| C01-AC-004 | Given an alias proposal that crosses tenants/environments or creates a cycle/collision, when submitted, then release is blocked, sanitized audit is emitted, and active registry state is unchanged. |
| C01-AC-005 | Given a compatible minor contract, all registered suites pass before activation; given a removed/changed required field under the same major version, activation fails. |
| C01-AC-006 | Given identical inputs across TypeScript, Python, and Go contract libraries, canonical serialization and SHA-256 golden outputs match byte-for-byte. |
| C01-AC-007 | Given a registry dependency outage, a run pinned to a verified snapshot continues resolution without mixing versions; an unpinned new run fails visibly after bounded retry. |
| C01-AC-008 | Given the performance dataset, single/batch p95 and throughput meet C01-NFR-001/002 with zero cross-tenant result leakage. |

## 15. Component Test Matrix

| ID | Level | Fixture/precondition | Action | Expected result | Retained evidence |
|---|---|---|---|---|---|
| C01-CT-001 | Unit/property | Generated valid URNs for every kind, Unicode and reserved characters | Parse -> normalize -> render -> parse | Round-trip equality and stable bytes | Seed, cases, golden checksums |
| C01-CT-002 | Unit/negative | Empty organization, bad percent escape, unsupported kind, empty digest | Validate | Exact `INVALID_URN`; no registry call | Validation report |
| C01-CT-003 | Unit | Same alias inputs in randomized order | Resolve repeatedly | Byte-identical result/checksum | 100-run checksum report |
| C01-CT-004 | Unit/conflict | Two top-precedence catalog IDs map to different URNs | Resolve | `AMBIGUOUS_IDENTITY`; both evidence claims retained | Result fixture |
| C01-CT-005 | Unit/security | Unicode confusable, cross-tenant/environment alias, cycle and collision | Propose alias | Proposal rejected; active version unchanged; sanitized audit | Audit and registry before/after |
| C01-CT-006 | Contract | Current consumers plus additive optional minor field | Run compatibility suite | All consumers pass; release eligible | Compatibility matrix |
| C01-CT-007 | Contract/negative | Remove required field without major bump | Run compatibility suite | `CONTRACT_INCOMPATIBLE`; release blocked | Failure diff |
| C01-CT-008 | Cross-language golden | Shared input JSON for TypeScript/Python/Go | Canonicalize and checksum | Exact byte/checksum equality | Golden artifacts |
| C01-CT-009 | Failure/recovery | Registry API unavailable; valid pinned snapshot | Resolve batch | Uses exact pinned version; warning metric; no version mix | Trace and snapshot checksum |
| C01-CT-010 | Idempotency | Same alias decision/key/content delivered twice | Apply | One registry candidate and two delivery attempts | Conditional-write record |
| C01-CT-011 | Conflict | Same decision key with different checksum | Apply | `DUPLICATE_CONFLICTING_CONTENT`; neither silently overwrites | Conflict record |
| C01-CT-012 | Load | Production-shaped aliases, 1,000-item batches, tenant skew | Sustain target load | C01-NFR-001/002 pass; no hot partition/error loss | Load report/dashboard export |

## 16. Integration Obligations

- **INT-001 C01↔C02:** inventory aliases resolve under the snapshot's pinned
  registry version; invalid/ambiguous items remain explicit inventory gaps.
- **INT-002 C01↔C07/C08/C11:** one canonical multi-lane fixture proves Spark,
  dbt, deterministic parser, and runtime field identifiers converge.
- **INT-003 C01↔C13:** ambiguity prevents candidate deduplication/promotion and
  appears as a conflict with all evidence.
- **INT-004 C01↔C15/C17:** a reviewer can inspect and correct an identity alias;
  correction activates a new registry version and a new proposal version.
- **INT-005 C01↔C16:** published nodes/edges contain valid canonical URNs and a
  graph version cannot mix registry versions.
- **INT-006 C01↔C18:** registry outage, rollback, cross-account denial, audit,
  backup, and restore meet common operational gates.

The shared dependency matrix provides full steps, injected failures, pass
rules, and retained evidence for these IDs.

## 17. Definition of Done

C01 is implemented only when:

- Normative JSON Schemas/OpenAPI, valid/invalid examples, and typed libraries
  exist for all C01-owned contracts.
- Every P0 requirement and C01 component test passes in CI.
- INT-001 through INT-006 pass against production-shaped component versions.
- Cross-language canonicalization golden files match.
- Security tests prove tenant/environment isolation, collision/cycle denial,
  audit, and sensitive-log controls.
- Load/availability tests retain results meeting the stated SLOs.
- Registry release/rollback and ambiguity/collision runbooks are exercised.
- Dashboards and alarms link to owner/runbook and emit in the deployed
  nonproduction environment.
- The traceability matrix links actual run/report/artifact IDs, not a verbal
  assertion of success.

## 18. Implementation Notes

### Approved repository paths

```text
contracts/schemas/identity/
contracts/schemas/shared/
contracts/openapi/identity-api.yaml
contracts/examples/identity/
packages/typescript-contracts/
packages/python-contracts/
packages/go-contracts/
services/identity-resolver/
infra/lib/constructs/contract-registry.ts
tests/contract/identity/
tests/integration/identity/
```

Use TypeScript 5 for the API/control service and contract build, with generated
Python 3.12 and Go 1.24 models. Store immutable registry releases in C12 S3 and
the effective lookup/pointer in DynamoDB. Do not add Neptune as a C01 dependency.

Build order:

1. Grammar and canonical golden fixtures.
2. Schemas, compatibility harness, and generated libraries.
3. Immutable registry release/pointer.
4. Pure resolver and alias conflict detection.
5. APIs and event emission.
6. C02/C07/C08/C11/C13 integrations, then load/security/recovery.

Initial feature flags may gate a new resolver source or entity kind. A flag must
not change canonical grammar or silently fall back from ambiguity to a guess.
Rollback activates a prior immutable registry version and alerts affected runs.

## 19. Traceability

| Source decision | C01 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| Canonical URN layer is critical across lanes | C01-FR-001 through C01-FR-009 | C01-CT-001 through C01-CT-005 | INT-001 through INT-005; baseline steel thread |
| Contracts are versioned and governed | C01-FR-010 through C01-FR-016 | C01-CT-006 through C01-CT-011 | Contract compatibility gate |
| Scale to 10,000 repositories | C01-NFR-001 through C01-NFR-004 | C01-CT-012 | Enterprise load gate |
| Least privilege, immutable audit, no payload | C01-SEC-001 through C01-SEC-005 | C01-CT-005/009/011 | INT-006; security/privacy gates |
| No silent identity gaps/conflicts | C01-FR-005 through C01-FR-008; C01-OBS-002 | C01-CT-004/005 | INT-003/004; review steel thread |


---

# 02-source-adapters-and-inventory.md

# C02 Source Adapters and Repository Inventory PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C02 |
| Status | Approved for implementation |
| Launch phase | Foundation and baseline |
| Criticality | P0; classification and baseline completeness depend on a trustworthy estate snapshot |
| Primary owner | Lineage integrations team |
| Required approvers | Architecture, SCM/platform owners, Test Automation Service owner, security |
| Upstream dependencies | C01 contracts/identity; enterprise SCM, deployment, catalog/schema, native-lineage, CloudWatch, and test APIs |
| Downstream dependencies | C03-C06, C14, C17-C18 |
| Authoritative sources | AWS architecture §§7-8, 13-17; component design §§6 and 10 |

## 2. Purpose and Outcomes

C02 discovers the complete enterprise estate relevant to lineage and produces
immutable, reconciliable inventory snapshots. It separates discovery from
eligibility: every repository remains visible even if C04 later excludes it
from standalone analysis.

Measurable outcomes:

- 100% of repositories returned by configured enterprise SCM organizations are
  represented in a snapshot or in an explicit source failure record.
- Every business-application baseline pins one `RepositoryInventorySnapshot`
  with per-source completeness and source watermark.
- Scheduled source-to-snapshot reconciliation finds no unexplained missing,
  duplicate, or stale repository/deployment record.
- A 10,000 repositories inventory completes within 60 minutes under approved
  source quotas, excluding a declared upstream outage.

## 3. Scope and Non-Goals

### In scope

- Versioned adapters for Test Automation Service, SCM, deployment/artifact
  systems, service catalog, schema/contract/catalog systems, Spark/dbt/Airflow
  native-lineage catalogs, test/scenario systems, and selected CloudWatch
  deployment/interaction context.
- Paginated/rate-limited discovery, source checkpoints, watermarks, resumable
  collection, canonical ID resolution through C01, and immutable snapshots.
- Application/repository association evidence with ranked provenance.
- Completeness, freshness, source health, and reconciliation reports.
- Active, archived, transferred, forked, and renamed repository observations.

### Non-goals

- Classifying a repository or assigning Lane A/B/C (C04).
- Treating a CloudWatch interaction as a lineage edge.
- Cloning repositories or parsing their source (C08).
- Mutating SCM/catalog/deployment systems.
- Hiding an unavailable source by returning an apparently complete empty list.

## 4. Actors and Use Cases

| Actor | Use case |
|---|---|
| Application owner | Select an application and see which repositories/evidence formed its baseline |
| Platform operator | Configure a source, observe lag/errors, resume a checkpoint, and reconcile coverage |
| Adapter developer | Add a typed source/version without changing downstream snapshot semantics |
| C04 classifier | Receive every repository plus deterministic metadata/evidence |
| C05 context builder | Receive application, deployment, schema, native job, test, and interaction associations |
| Auditor | Reproduce what sources returned at a historical inventory watermark |

Representative scenarios:

1. Inventory all enterprise organizations, then select active repositories for
   one Test Automation Service business application.
2. Discover a documentation-named repository containing authoritative Avro and
   OpenAPI contracts without deciding its classification.
3. Resume after SCM throttling without duplicating pages or mixing watermarks.
4. Mark one schema catalog `PARTIAL` while retaining complete SCM/deployment
   content and preventing a false complete baseline.
5. Reconcile a deployment digest that is absent from the prior snapshot.

## 5. Component Boundary

### Owned behavior

- Source credentials/configuration references and adapter execution.
- Normalized observations and immutable `RepositoryInventorySnapshot`.
- Per-source checkpoints, health/freshness/completeness, and reconciliation.

### Inputs

- Baseline/scheduled inventory request with organization/application scope.
- Source registry and adapter versions.
- C01 registry version and canonical identity service.
- Read-only external APIs/log queries under governed limits.

### Outputs

- Snapshot S3 URI/checksum and `inventory.snapshot.created` event.
- Source status/checkpoint, reconciliation result, and explicit coverage gaps.

### Forbidden behavior

- Excluding a repository by name, inferred type, lack of deployment, or missing
  ownership.
- Advancing a source watermark before its page/results are durably included.
- Storing source credentials or raw application payload/log bodies.
- Combining pages captured under incompatible source snapshot tokens without a
  visible consistency qualification.
- Reporting `COMPLETE` when a required source/page failed or expired.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C02-FR-001 | C02 must inventory every configured SCM organization/repository, including active, archived, transferred, renamed, forked, and inaccessible-with-reason records. | P0 |
| C02-FR-002 | C02 must query the Test Automation Service for application, repository, scenario, owner, and domain associations and preserve source IDs/evidence. | P0 |
| C02-FR-003 | C02 must collect immutable commit SHAs, deployment IDs, artifact digests, environments, deploy times, and application bindings from governed deployment sources. | P0 |
| C02-FR-004 | C02 must inventory authoritative schemas/contracts/catalog objects and native Spark/dbt/Airflow jobs/runs without interpreting their lineage. | P0 |
| C02-FR-005 | C02 may collect allowlisted CloudWatch deployment and service-interaction context, but must label it `INTERACTION_CONTEXT` and never emit a lineage edge. | P0 |
| C02-FR-006 | Every adapter must expose source/version, requested scope, start/end watermark, pages/items, retry/throttle state, collection time, and one of `COMPLETE`, `PARTIAL`, `UNAVAILABLE`, or `STALE`. | P0 |
| C02-FR-007 | A `RepositoryInventorySnapshot` must be immutable, checksummed, source-by-source complete, and bound to a C01 registry version. | P0 |
| C02-FR-008 | C02 must normalize source IDs through C01 while preserving native IDs and unresolved/ambiguous identity outcomes. | P0 |
| C02-FR-009 | Adapter paging must be resumable from a durable checkpoint and must not advance the source watermark until the corresponding normalized observations are durably staged. | P0 |
| C02-FR-010 | Duplicate source observations with identical identity/content must collapse deterministically; conflicting content for the same source identity/watermark must enter `CONFLICT`. | P0 |
| C02-FR-011 | Required-source failure must propagate a snapshot coverage gap and prevent `COMPLETE`; optional-source failure must be visible with its policy designation. | P0 |
| C02-FR-012 | C02 must rank application/repository association evidence: governed catalog or Test Automation ownership, deployment binding, explicit contract/config reference, observed interaction, then inference requiring review. | P0 |
| C02-FR-013 | Scheduled reconciliation must compare source counts/IDs/watermarks with snapshots and emit missing, unexpected, duplicate, stale, and changed observations. | P0 |
| C02-FR-014 | Adapter contracts must be typed/versioned and must reject unknown major versions or arbitrary property maps. | P0 |
| C02-FR-015 | Source configuration changes must be versioned and effective-dated; a snapshot must pin one configuration version per source. | P0 |
| C02-FR-016 | C02 must support incremental inventory events while retaining scheduled full inventory as the completeness oracle. | P1 |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C02-NFR-001 | A 10,000-repository full inventory must complete within 60 minutes under approved source quotas and retain a source-segmented duration report. | P0 |
| C02-NFR-002 | Adapter concurrency must obey configured per-source/account rate limits and honor `Retry-After` without starving other sources. | P0 |
| C02-NFR-003 | Snapshot publication must be 99.9% available monthly, excluding a declared required-source outage that correctly produces `PARTIAL`/`UNAVAILABLE`. | P0 |
| C02-NFR-004 | No source page acknowledged as checkpointed may be lost after process/Region recovery within C18 RPO/RTO. | P0 |

## 7. Data and Durable State

`SourceRegistration`:

- source ID/type/account/organization, adapter/schema versions, owner.
- credential secret reference and cross-account role ARN, never secret value.
- required/optional policy by inventory purpose.
- scopes, allowlisted fields/log groups, rate/concurrency limits.
- watermark/checkpoint semantics, freshness threshold, retention class.
- effective/expiry and configuration checksum.

`SourceCollectionAttempt`:

- inventory run/source/config version, request scope, attempt and lease.
- start/end watermark or snapshot token, current page/checkpoint.
- page/item/dedup/conflict counts, rate/throttle metrics.
- status/error and staged evidence references.

`RepositoryInventorySnapshot` conforms to the contract catalog and includes:

- organization plus inventory watermark/version.
- repositories with native/canonical IDs, immutable HEAD, lifecycle state, URL
  metadata, ownership/application evidence, manifests/descriptors references.
- deployed artifacts/environments, schemas/contracts/catalog/native jobs,
  test/scenario mappings, and interaction-context references.
- source statuses/checksums/counts and global completeness summary.

S3 is authoritative for snapshots/staged pages; DynamoDB holds registration,
checkpoint, snapshot pointer, and reconciliation indexes.

## 8. Interfaces and Contracts

### Start inventory

`POST /v1/inventory-runs` accepts organization, optional application/domain,
purpose (`BASELINE`, `SCHEDULED_FULL`, `RECONCILIATION`, `INCREMENTAL_REFRESH`),
required watermark, source policy/config version, and idempotency key. It
returns run ID and status URI; C06 normally invokes it.

### Adapter interface

```text
describe() -> adapter capabilities/schema/watermark model
open(scope, configVersion, priorCheckpoint?) -> snapshot token/checkpoint
readPage(token, checkpoint, limit) -> observations, nextCheckpoint, source metadata
close(token) -> final watermark/count/checksum
health() -> authorization, quota, schema compatibility, freshness
```

Observations are typed (`RepositoryObserved`, `DeploymentObserved`,
`SchemaObserved`, `NativeJobObserved`, `TestScenarioObserved`,
`InteractionObserved`) and wrapped in an `EvidenceReference` after staging.

### Snapshot publication

Publication requires all configured adapters terminal, normalized/staged page
checksums verified, completeness calculated, and a conditional snapshot-pointer
write. C02 emits `inventory.snapshot.created` with immutable S3 reference,
checksum, status, organization/application, source watermarks, and correlation.

## 9. Processing and State Model

```text
REQUESTED -> SOURCE_PLANNED -> COLLECTING -> NORMALIZING
          -> RECONCILING -> SNAPSHOT_WRITING -> PUBLISHED
```

Alternative outcomes are `PARTIAL`, `UNAVAILABLE`, `STALE`, `FAILED`, and
`CANCELLED`; the snapshot itself uses source status rather than pretending a
partial run is absent.

Algorithm:

1. Validate request/config and pin C01/source config versions.
2. Plan adapters and required/optional designation.
3. Acquire per-source lease; open a source-consistent token where available.
4. Page under rate limits. Stage raw allowlisted metadata and normalized
   observations with checksums; then conditionally advance checkpoint.
5. Resolve canonical IDs in C01 batches. Preserve unknown/ambiguous results.
6. Deduplicate by source-native immutable identity and content checksum; record
   conflicting observations separately.
7. Close adapter, validate counts/watermark/checksum, and assign source status.
8. Reconcile cross-source associations under precedence without deciding
   repository class.
9. Write immutable snapshot, verify checksum/read-back, advance latest pointer,
   and emit event.

Resume starts from the last durably acknowledged page. If a source token
expires, the adapter restarts a new attempt and either proves snapshot
consistency or marks the result `PARTIAL`/`STALE`; it never splices silently.

## 10. Failure Semantics

| Code | Class | Required behavior |
|---|---|---|
| `SOURCE_THROTTLED` | `TRANSIENT` | Honor retry hint/jitter; retain checkpoint; isolate source |
| `SOURCE_AUTH_DENIED` | `DETERMINISTIC_INVALID` | Mark source unavailable, alert owner, no credential details in logs |
| `SOURCE_SCHEMA_INCOMPATIBLE` | `DETERMINISTIC_INVALID` | Quarantine adapter/source version; do not publish complete |
| `SOURCE_PAGE_MISSING` | `INCOMPLETE` | Mark partial and reconcile missing range |
| `SOURCE_TOKEN_EXPIRED` | `INCOMPLETE` | Restart consistent attempt or publish visible stale/partial status |
| `IDENTITY_AMBIGUOUS` | `CONFLICT` | Preserve observation and candidates for downstream review |
| `OBSERVATION_CONFLICT` | `CONFLICT` | Preserve both checksums/source metadata; no last-write-wins |
| `CHECKPOINT_WRITE_FAILED` | `TRANSIENT` | Retry before acknowledging page; duplicate reread is idempotent |
| `SNAPSHOT_CHECKSUM_FAILED` | `DETERMINISTIC_INVALID` | Do not advance pointer or emit success event |

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C02-SEC-001 | Adapters must use short-lived read-only credentials from governed cross-account roles or Secrets Manager references with source/scope least privilege. | P0 |
| C02-SEC-002 | SCM checkout credentials, payload/log bodies, source tokens, and secrets must not appear in snapshots, logs, metrics, events, or exception text. | P0 |
| C02-SEC-003 | CloudWatch queries must use explicit allowlisted accounts/log groups/fields and retain query/audit metadata; free-form production log export is prohibited. | P0 |
| C02-SEC-004 | Source registrations, role assumption, configuration changes, inventory requests, snapshot reads, and reconciliation actions must be audited. | P0 |
| C02-SEC-005 | Snapshot and staging prefixes must use KMS, TLS-only/private access, organization/domain authorization, retention, and access logging. | P0 |

## 12. Scale, Performance, and Availability

- Planning size: 10,000 repositories, 10,000+ daily deployment observations,
  six initial archetypes, and hundreds of schema/native/test sources.
- Source tasks run independently so one slow adapter does not serialize all
  inventory; concurrency remains below source and account quotas.
- Pages are bounded by count and byte size. Large source results are S3 staged,
  not returned in Step Functions state.
- Inventory fairness reserves capacity for Tier-1 deployment refresh while a
  scheduled full scan runs.
- A source registration has circuit-breaker thresholds to avoid repeated
  authorization/schema failures; opening the breaker emits a P0 coverage alert.
- Multi-AZ control state, S3 cross-Region replication, checkpoint recovery, and
  snapshot restore follow C18's 15-minute RPO/four-hour RTO.

## 13. Observability

| ID | Signal | Dimensions/alert | Priority |
|---|---|---|---|
| C02-OBS-001 | Inventory run duration/status/counts | source, organization, application, purpose; alert required-source failure | P0 |
| C02-OBS-002 | Source freshness/watermark lag | source/account/config; alert past governed threshold | P0 |
| C02-OBS-003 | Page throughput/throttle/retry | source/account/adapter version | P0 |
| C02-OBS-004 | Snapshot coverage | repositories, deployments, schemas, native jobs, tests; complete/partial/unavailable/stale | P0 |
| C02-OBS-005 | Reconciliation differences | missing/unexpected/duplicate/conflict/stale by source and owner | P0 |
| C02-OBS-006 | Cost | API calls, log bytes scanned, compute/storage by source/domain | P1 |

C17 exposes snapshot version, source status, missing evidence, and run timeline.
C18 dashboards link alarms to source-specific runbooks and last good watermark.

## 14. Acceptance Criteria

| ID | Acceptance criterion |
|---|---|
| C02-AC-001 | Given a 10,000-repository SCM fixture with pagination, renames, transfers, archives, and forks, a full run publishes exactly one observation per source-native identity and matches source counts/checksum. |
| C02-AC-002 | Given one required schema source fails after page N, the snapshot is `PARTIAL`, completed source content remains available, the missing range is explicit, and baseline completion is not falsely reported. |
| C02-AC-003 | Given throttling and process restart, C02 resumes from the last durable checkpoint, rereads at most the unacknowledged page, and produces the same snapshot checksum as uninterrupted collection. |
| C02-AC-004 | Given an observed interaction between services, the snapshot labels it context; no candidate lineage edge is emitted. |
| C02-AC-005 | Given ambiguous C01 aliases, both candidates/evidence remain in the snapshot and C04 receives an explicit identity gap. |
| C02-AC-006 | Given a deployment absent from the previous snapshot, scheduled reconciliation emits the exact missing artifact/environment decision and starts governed refresh through C03. |
| C02-AC-007 | Given invalid source authorization/schema, C02 does not retry wastefully or leak credentials; it records deterministic status, owner action, metric, and audit. |
| C02-AC-008 | The production-like load test satisfies C02-NFR-001/002 with no dropped page, lost checkpoint, or unexplained reconciliation difference. |

## 15. Component Test Matrix

| ID | Level | Fixture/precondition | Action | Expected result | Retained evidence |
|---|---|---|---|---|---|
| C02-CT-001 | Adapter contract | Valid/invalid responses for every adapter version | Describe/open/read/close | Typed normalized observations; invalid major rejected | Contract report/examples |
| C02-CT-002 | Unit/paging | 3 pages plus duplicate item | Collect | All pages once logically; duplicate collapsed by checksum | Page/checkpoint trace |
| C02-CT-003 | Failure/restart | Crash after stage before checkpoint | Resume | Page may reread; snapshot content remains single/idempotent | Attempt and checksum history |
| C02-CT-004 | Rate limit | Source emits 429/Retry-After | Collect concurrently | Hint honored; other sources continue; no busy retry | Timeline/metrics |
| C02-CT-005 | Partial | Required source fails page N | Finalize | Source/snapshot `PARTIAL`; missing range and owner action visible | Snapshot/alert |
| C02-CT-006 | Security | Invalid role and secret-bearing exception | Collect | Deterministic unavailable; secret redacted; audit emitted | Sanitized logs/audit |
| C02-CT-007 | Identity | One resolved, one unknown, one ambiguous alias | Normalize | Each business outcome preserved without loss | Snapshot fragment |
| C02-CT-008 | Conflict | Same source identity/watermark, different content | Deduplicate | `OBSERVATION_CONFLICT`; both checksums retained | Conflict record |
| C02-CT-009 | Context boundary | Production log containing payload plus allowlisted interaction fields | Query/normalize | Only allowlisted context retained; no edge or payload | Privacy scan/result |
| C02-CT-010 | Reconciliation | Source current set differs from snapshot | Reconcile | Exact missing/unexpected/stale/changed rows and refresh triggers | Reconciliation report |
| C02-CT-011 | Consistency | Source token expires midrun | Resume/restart | Proven consistent snapshot or visible partial/stale; no silent splice | Token/attempt evidence |
| C02-CT-012 | Load/recovery | 10,000 repositories, source skew, worker restart | Run full inventory | Time/SLO met; counts/checksums exact; checkpoint recoverable | Load report/dashboard |

## 16. Integration Obligations

- **INT-007 C01↔C02:** all observations resolve under one pinned registry
  version; unknown/ambiguous results remain explicit.
- **INT-008 C02↔C03:** snapshot-created and reconciliation triggers validate,
  deduplicate, archive, and route with immutable reference/checksum.
- **INT-009 C02↔C04:** every discovered repository/path reaches eligibility;
  no adapter applies class exclusions.
- **INT-010 C02↔C05:** application/deployment/schema/native/test/context evidence
  builds a version-pinned context snapshot under documented precedence.
- **INT-011 C02↔C17:** inventory/source completeness and reconciliation gaps are
  queryable and correlated to the user run timeline.
- **INT-012 C02↔C18:** throttling, source outage, secret redaction, audit,
  checkpoint restore, and cross-Region snapshot recovery meet operations gates.

## 17. Definition of Done

- Typed registrations and adapter conformance kits exist for every required
  launch source, with valid/invalid/golden fixtures.
- All C02 P0 requirements and C02-CT-001 through C02-CT-012 pass.
- INT-007 through INT-012 pass against deployed nonproduction integrations.
- A 10,000-repository snapshot/load report proves counts, duration, fairness,
  idempotent resume, and reconciliation.
- Security evidence proves least privilege, credential/payload redaction,
  allowlisted CloudWatch context, encryption, and audit.
- Source failure, expired token, partial snapshot, reconciliation, and restore
  runbooks have exercise IDs and owner acknowledgements.
- Dashboards/alarms and the C17 source-status view use real deployed telemetry.

## 18. Implementation Notes

```text
contracts/schemas/inventory/
services/source-adapters/common/
services/source-adapters/test-automation/
services/source-adapters/scm/
services/source-adapters/deployment/
services/source-adapters/catalog-schema/
services/source-adapters/native-lineage/
services/source-adapters/cloudwatch-context/
services/inventory-builder/
infra/lib/constructs/inventory-state.ts
tests/contract/adapters/
tests/integration/inventory/
tests/load/inventory/
```

Use TypeScript 5 for adapter/control services. Use Lambda only for bounded API
pages/normalization; use Batch for unusually large reconciliation/normalization.
S3 holds staged pages/snapshots and DynamoDB holds checkpoints/pointers.

Build source adapters behind a common conformance suite. Start with Test
Automation, SCM, deployment, and catalog/schema; add native/test/context sources
without changing the snapshot envelope. Feature flags may enable a source or
mark it optional for a pilot, but required-source policy is versioned/audited.

## 19. Traceability

| Source decision | C02 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| Inventory every repository; never silently exclude | C02-FR-001/006/007/011/013 | C02-CT-001/005/010/012 | INT-009; baseline steel thread |
| Test Automation application baseline context | C02-FR-002/012 | C02-CT-001/007 | INT-010 |
| Deployment/digest and schema/native/test context | C02-FR-003/004/005 | C02-CT-009/010 | INT-008/010; hotfix steel thread |
| Resumable, idempotent, source-consistent collection | C02-FR-009/010/015; C02-NFR-004 | C02-CT-002/003/004/008/011 | INT-012; recovery gate |
| 10,000-repository capacity | C02-NFR-001/002 | C02-CT-012 | Enterprise baseline gate |
| Privacy and least privilege | C02-SEC-001 through C02-SEC-005 | C02-CT-006/009 | INT-012; security/privacy gate |


---

# 03-event-intake-and-queues.md

# C03 Event Intake, Normalization, and Priority Queues PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C03 |
| Status | Approved for implementation |
| Launch phase | Foundation |
| Criticality | P0; every asynchronous trigger and replay enters through C03 |
| Primary owner | Lineage control-plane team |
| Required approvers | Architecture, security, operations, C06 workflow owner |
| Upstream dependencies | C01 contracts, C02 source events, SCM/deployment/test/review/publication sources |
| Downstream dependencies | C04, C06, C14, C18 |
| Authoritative sources | AWS architecture §§5-6, 9.1, 14-17; component design §§6, 10-12 |

## 2. Purpose and Outcomes

C03 is the durable front door for lineage work. It authenticates producers,
validates and normalizes events, computes immutable event-type-specific
idempotency identities, records every routing decision, and uses EventBridge
plus priority SQS queues to absorb spikes without losing work or allowing
baseline/backfill to starve deployed-artifact decisions.

Measurable outcomes:

- Accept a 10,000-event burst without loss and sustain 100 normalized events per
  second under production-like tests.
- Every accepted source delivery maps to exactly one visible outcome:
  normalized/routed, duplicate, recorded coalesced, quarantined, or DLQ.
- Duplicate delivery creates one business trigger while preserving attempt
  count and source delivery audit.
- Tier-1 queue-age and routing SLOs remain within policy during concurrent
  baseline/backfill load.

## 3. Scope and Non-Goals

### In scope

- HTTP/EventBridge/API destinations for governed SCM, deployment, inventory,
  baseline, runtime, review, publication, reconciliation, and operator replay.
- Producer authentication/authorization, source delivery verification,
  schema/size validation, normalization, correlation enrichment, and archive.
- Idempotency, duplicate/conflicting duplicate handling, and narrowly governed
  coalescing.
- Content-based EventBridge routing and priority SQS queues/DLQs.
- Queue admission, per-domain partition attributes, replay/redrive controls,
  and end-to-end intake audit/telemetry.

### Non-goals

- Orchestrating long-running work or choosing analyzer steps (C06).
- Reclassifying repositories or deciding no impact (C04/C05).
- Exactly-once transport; delivery is assumed at least once.
- Dropping older events merely because a newer event exists.
- Embedding repository content, evidence packages, or large manifests in event
  or workflow payloads.

## 4. Actors and Use Cases

| Actor/system | Use case |
|---|---|
| SCM/deployment system | Submit immutable commit/artifact triggers |
| C02 | Emit inventory snapshot/reconciliation triggers |
| Application owner/C17 | Request a baseline or record a proposal decision |
| C11 | Emit runtime session lifecycle/evidence-ready events |
| C16 | Submit/emit publication lifecycle events |
| Operator | Inspect quarantine/DLQ, replay archive range, or govern redrive |
| C06 | Consume prioritized work with normalized contracts and idempotency state |

Key scenarios include duplicate webhook delivery, out-of-order commits,
deployment without digest, a never-deployed PR commit superseded by a newer PR
commit, emergency hotfix deployment, poison message, queue spike, and governed
archive replay after a repaired consumer defect.

## 5. Component Boundary

### Owned behavior

- Ingress endpoint/rule and producer verification.
- `EventEnvelope` normalization and correlation initialization.
- Idempotency record and normalized-event immutable reference.
- EventBridge bus/archive/rules, SQS priority queues, DLQs, queue policies, and
  routing decision records.

### Inputs

- Typed producer event or S3 reference/checksum for an oversized body.
- Producer registration, contract version, routing/admission policy.
- Optional trusted correlation parent.

### Outputs

- Normalized `EventEnvelope` reference and route/priority/admission attributes.
- Duplicate/coalesced/quarantine/DLQ/replay records and metrics.

### Forbidden behavior

- Forming an idempotency key with an empty commit SHA, artifact digest,
  environment, organization, repository, or event type.
- Treating coalescing as deduplication or coalescing a deployed artifact.
- Routing an event before source authentication and contract validation.
- Using EventBridge as worker backpressure or SQS as content authority.
- Redriving around current validation, authorization, idempotency, or routing.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C03-FR-001 | C03 must authenticate/authorize the producer, verify source delivery integrity where supported, and map it to a registered organization/account before normalization. | P0 |
| C03-FR-002 | Every accepted event must use the versioned `EventEnvelope` and typed data contract, with event ID/type/time, organization, source delivery, correlation, schema, and immutable content reference/checksum. | P0 |
| C03-FR-003 | SCM idempotency must include organization, repository, commit SHA, event type, analyzer version, and policy version; a missing commit SHA must be quarantined. | P0 |
| C03-FR-004 | Deployment idempotency must include organization, repository, artifact digest, environment, event type, analyzer version, and policy version; a missing digest/environment must be quarantined. | P0 |
| C03-FR-005 | Identical duplicate business identity/content must return the prior normalized outcome and increment delivery attempts without emitting a second business trigger. | P0 |
| C03-FR-006 | The same business identity with a different content checksum must enter `DUPLICATE_CONFLICTING_CONTENT`; C03 must preserve both source deliveries and must not last-write-win. | P0 |
| C03-FR-007 | Coalescing may supersede only an older, never-deployed PR commit under versioned policy after both identities and a `COALESCED_BY` relation are recorded; every deployed artifact and hotfix must remain actionable. | P0 |
| C03-FR-008 | C03 must route normalized events through content-based EventBridge rules and retain them in an EventBridge archive for governed replay. | P0 |
| C03-FR-009 | C03 must provide separate SQS queues/DLQs for Tier-1 incremental, standard incremental, baseline, backfill/reconciliation, LLM-limited residual, and runtime-correlation work. | P0 |
| C03-FR-010 | Routing must assign queue, priority, domain/admission key, enqueue time, schema/policy versions, and immutable normalized-event reference; no large body may be copied into SQS. | P0 |
| C03-FR-011 | Queue admission must reserve Tier-1 capacity, rate-limit per domain, and expose rejection/defer decisions without deleting the accepted event. | P0 |
| C03-FR-012 | Every queue consumer contract must assume duplicates/out-of-order delivery and include business idempotency identity and expected state/version. | P0 |
| C03-FR-013 | Schema/auth/privacy/missing-identity failures must be deterministic quarantine; transient service failures use bounded retry; repeated consumer failures enter the queue-specific DLQ. | P0 |
| C03-FR-014 | Archive replay and DLQ redrive must be scoped, authorized, rate-limited, audited, and pass through current validation, routing, idempotency, and admission policy. | P0 |
| C03-FR-015 | C03 must record an outcome for every ingress delivery, including rejected authentication attempts using only sanitized source metadata. | P0 |
| C03-FR-016 | Event contract/routing policy changes must be versioned, canaried, and reversible without reinterpreting archived event bytes. | P1 |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C03-NFR-001 | C03 must accept a burst of 10,000 valid normalized triggers without loss and sustain 100 triggers/second for 30 minutes in the production-like load environment. | P0 |
| C03-NFR-002 | Valid ingress-to-queue latency must be below 2 seconds p95 and 5 seconds p99 under normal load. | P0 |
| C03-NFR-003 | Intake and queue infrastructure must be Multi-AZ and achieve 99.95% monthly availability for accepted-event durability. | P0 |
| C03-NFR-004 | Event archive/normalized content and idempotency state must recover within C18's 15-minute RPO and four-hour RTO with no duplicate business effects. | P0 |

## 7. Data and Durable State

`ProducerRegistration` contains producer ID/type/account/organization, auth
method/key/certificate reference, allowed event types/schemas, network/source
conditions, max size/rate, owner, effective/expiry, and policy version.

`IdempotencyRecord` contains business key hash, event type, immutable identity
parts (redacted as policy requires), normalized content checksum/reference,
first/current source delivery IDs, attempt count, status, route, run ID if
created, lease/TTL for processing only, and immutable audit references.

`RoutingDecision` contains event ID/business identity, routing policy version,
matched rule, queue/DLQ ARN alias, priority, domain/admission key, decision
reason, enqueue timestamp, deferral, and checksum.

`QuarantineRecord` and `RedriveRequest` follow the shared state/error model.
EventBridge archive preserves original normalized events under retention policy;
C12 S3 stores oversized source/normalized content and audit-grade copies.

## 8. Interfaces and Contracts

### Ingress

- `POST /v1/events/{producerId}` for registered webhook/API producers.
- EventBridge PutEvents for governed AWS producers with source/detail-type
  resource policies.
- Internal commands such as `POST /v1/baseline-runs` produce the same normalized
  event path rather than directly invoking C06.

Responses:

- `202 ACCEPTED`: normalized and durably recorded for routing.
- `200 DUPLICATE`: prior result/run reference returned.
- `202 QUARANTINED`: authenticated producer but deterministic content failure;
  only when producer policy allows asynchronous correction.
- `400/401/403/413`: malformed, unauthenticated/unauthorized, or oversized
  request, with sanitized audit.
- `409 DUPLICATE_CONFLICTING_CONTENT`.
- `429/503`: request not durably accepted; producer may retry same delivery ID.

### Queue message

```json
{
  "eventRef": "s3://...#sha256=...",
  "eventId": "...",
  "eventType": "artifact.deployed",
  "businessKeyHash": "...",
  "priority": "TIER1",
  "domainAdmissionKey": "payments",
  "routingPolicyVersion": "routing-v1",
  "enqueuedAt": "2026-08-02T14:31:24Z",
  "correlation": {"collectionRunId": "...", "traceId": "..."}
}
```

The message is below 64 KiB by policy. Consumers fetch/verify referenced content
and conditionally transition the idempotency/work record before acting.

### Replay/redrive

Requests require source (archive or DLQ), event time/IDs, reason, target policy
version, maximum count/rate, dry-run summary, authorization, and expiry. C03
emits start/progress/complete/cancel audit and links new attempts to originals.

## 9. Processing and State Model

```text
RECEIVED -> AUTHENTICATED -> VALIDATED -> NORMALIZED
         -> IDEMPOTENCY_DECIDED -> ARCHIVED -> ROUTED -> ENQUEUED
```

Alternative outcomes: `REJECTED_AUTH`, `QUARANTINED`, `DUPLICATE`,
`DUPLICATE_CONFLICT`, `COALESCED`, `DEFERRED`, and `DLQ`.

Processing order:

1. Enforce network/request size/rate and verify producer signature/role.
2. Parse only the registered schema/version and reject unsafe/unknown major
   versions or generic payload maps.
3. Resolve organization/repository/source identity and normalize timestamps,
   correlation, and S3 references/checksums.
4. Validate event-type immutable fields before hashing the business key.
5. Conditional idempotency write determines new, same duplicate, conflicting
   duplicate, or in-progress outcome.
6. Evaluate a possible coalescing policy separately and persist relation.
7. Put normalized envelope on EventBridge and verify success; archive/rule
   policies route to SQS and operational consumers.
8. Persist routing/admission outcome and expose it to C17/C18.

Out-of-order events are retained with occurrence/receipt times. Ordering is
resolved by C06/C14 against immutable artifact/effective versions, not by
discarding at intake.

## 10. Failure Semantics

| Code | Class | Behavior |
|---|---|---|
| `PRODUCER_AUTH_FAILED` | `DETERMINISTIC_INVALID` | Reject; sanitized security audit/metric; no event body logging |
| `EVENT_SCHEMA_INVALID` | `DETERMINISTIC_INVALID` | Quarantine/reject by producer contract; no queue |
| `IMMUTABLE_IDENTITY_MISSING` | `DETERMINISTIC_INVALID` | Quarantine; never compute an empty/shared key |
| `DUPLICATE_CONFLICTING_CONTENT` | `CONFLICT` | Preserve both; alert owner; no second trigger |
| `EVENTBRIDGE_THROTTLED` | `TRANSIENT` | Bounded retry before accepted outcome; source may safely redeliver |
| `QUEUE_SEND_FAILED` | `TRANSIENT` | Event remains archived/visible; route retry/reconciliation |
| `ADMISSION_DEFERRED` | `INCOMPLETE` operational | Keep durable event and retry admission; expose age |
| `CONSUMER_REPEATED_FAILURE` | `POISON_REPEATED` | DLQ, alarm/runbook, governed redrive |
| `REPLAY_POLICY_REJECTED` | `DETERMINISTIC_INVALID` | No replay; retain request/audit reason |

No 2xx accepted response is returned until the event/idempotency outcome is
durable enough to recover and route/reconcile it.

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C03-SEC-001 | Every producer must use an approved signature, IAM/resource policy, mTLS, or OIDC mechanism bound to allowed organization/account/event types. | P0 |
| C03-SEC-002 | Ingress, EventBridge, SQS, archive, S3 references, idempotency, and DLQs must use TLS, KMS, least-privilege resource policies, private endpoints where applicable, and separate producer/consumer roles. | P0 |
| C03-SEC-003 | Event schemas must prohibit raw payload values, credentials, tokens, request/response bodies, generic headers, and arbitrary attribute maps. | P0 |
| C03-SEC-004 | Logs/DLQs/quarantine must store only allowlisted metadata and checksums; a security-invalid body must not be copied to broad operational stores. | P0 |
| C03-SEC-005 | Replay/redrive/coalescing/routing policy changes must require scoped operator authorization, reason, expiry where applicable, and immutable audit. | P0 |

## 12. Scale, Performance, and Availability

Queues:

1. Tier-1 incremental: reserved consumer capacity; oldest age P0 alert.
2. Standard incremental: may borrow unused baseline capacity through C06.
3. Baseline: cannot consume Tier-1 reservations.
4. Backfill/reconciliation: lowest priority, explicit admission.
5. LLM residual: separately rate/cost limited.
6. Runtime correlation: isolated from repository-control spikes.

Use EventBridge for routing, not backlog. SQS Standard provides scale; every
consumer is idempotent. Message retention must exceed maximum outage/recovery
and approval-independent processing window. DLQ retention must allow governed
investigation. Queue policies require exact sources/accounts and encryption.

Load tests combine 10,000 immediate events, 30-minute sustained input, 10%
duplicates, 1% invalid, domain skew, baseline backlog, and consumer slowdown.
Pass requires no accepted-event loss, exact outcome counts, and Tier-1 SLOs.

## 13. Observability

| ID | Signal | Dimensions/alert | Priority |
|---|---|---|---|
| C03-OBS-001 | Ingress count/latency/outcome | producer, event type, organization, schema/policy | P0 |
| C03-OBS-002 | Duplicate/conflict/coalesced/quarantine | event type, reason, owner; conflict/security alerts | P0 |
| C03-OBS-003 | Queue depth/oldest age/throughput | priority, domain, queue/DLQ; Tier-1 SLO alert | P0 |
| C03-OBS-004 | Routing/admission decisions | rule/policy version, matched route, deferred reason | P0 |
| C03-OBS-005 | Archive replay/DLQ redrive | actor, scope, rate, success/failure, duplicate effect | P0 |
| C03-OBS-006 | EventBridge/SQS quota/cost | account, bus/queue, API, payload bytes | P1 |

Metrics reconcile `received = rejected + quarantined + duplicate + conflict +
coalesced + accepted`; accepted reconciles to route/deferred/DLQ and eventual
C06 run/no-impact outcome.

## 14. Acceptance Criteria

| ID | Acceptance criterion |
|---|---|
| C03-AC-001 | Given two identical SCM deliveries, C03 records two attempts and one normalized business trigger/run identity. |
| C03-AC-002 | Given a deployment event without artifact digest or environment, C03 quarantines it with `IMMUTABLE_IDENTITY_MISSING` and creates no shared/empty idempotency key. |
| C03-AC-003 | Given the same business key with different content, C03 records conflict and neither overwrites nor emits a second business trigger. |
| C03-AC-004 | Given an older undeployed PR and a newer PR under an enabled policy, coalescing records both/relation; given any deployed/hotfix artifact, no coalescing removes its lineage decision. |
| C03-AC-005 | Given concurrent baseline/backfill and a 10,000-event spike, all accepted events reconcile and Tier-1 latency/age remain within C03 and platform SLOs. |
| C03-AC-006 | Given a poison consumer event, it reaches the correct DLQ after bounded attempts; governed redrive revalidates/idempotently completes after repair. |
| C03-AC-007 | Given archive replay of already completed events, attempt/audit counts increase but business runs/proposals/publications are not duplicated. |
| C03-AC-008 | Given unauthenticated or payload-bearing input, C03 rejects it, emits sanitized security telemetry, and no prohibited body appears in logs/archive/queue/DLQ. |

## 15. Component Test Matrix

| ID | Level | Fixture/precondition | Action | Expected result | Retained evidence |
|---|---|---|---|---|---|
| C03-CT-001 | Contract | Valid typed event for every source/type | Validate/normalize | Canonical `EventEnvelope` and checksum | Golden envelopes |
| C03-CT-002 | Contract/negative | Unknown major, missing required, arbitrary map, oversized inline body | Submit | Exact rejection/quarantine; no route | Validation/audit |
| C03-CT-003 | Security | Bad signature/role/source account | Submit | Reject before body normalization; sanitized alert | Security audit |
| C03-CT-004 | Idempotency | Same SCM/deployment delivery twice | Submit concurrently | One business trigger, two attempts, prior result returned | DynamoDB/event counts |
| C03-CT-005 | Conflict | Same business key, different checksum | Submit | Conflict record; zero second route | Conflict evidence |
| C03-CT-006 | Boundary | Missing commit; missing digest/environment | Submit | `IMMUTABLE_IDENTITY_MISSING`; no empty key | Quarantine/key scan |
| C03-CT-007 | Coalescing | Older/newer undeployed PR then deployed hotfix | Apply policy | Only PR may coalesce; hotfix always queued | Relation/routing records |
| C03-CT-008 | Routing | One event per type/priority/domain | Route | Exactly expected queue/rule attributes | Rule assertion/report |
| C03-CT-009 | Failure/DLQ | Consumer fails beyond receive policy | Consume | Correct DLQ/alert/runbook; original event preserved | Attempt/DLQ history |
| C03-CT-010 | Replay/redrive | Completed, quarantined, and repaired poison events | Replay/redrive scoped set | Current validation/policy; idempotent results; full audit | Replay report |
| C03-CT-011 | Privacy | Forbidden fields/secret-bearing errors | Submit and inspect stores | Rejected/redacted; prohibited terms/content absent | Store/log privacy scan |
| C03-CT-012 | Load/fairness | 10,000 burst plus sustained/domain-skew/baseline backlog | Run load | No loss; exact outcome counts; Tier-1 and throughput SLOs | Load report/dashboard |

## 16. Integration Obligations

- **INT-013 C02↔C03:** snapshot/reconciliation events are checksummed,
  idempotent, archived, and routed.
- **INT-014 External producers↔C03:** SCM/deployment/test events pass source
  authentication, versioned contract, duplicate, conflict, and missing-identity
  cases.
- **INT-015 C03↔C04:** repository triggers reach classification with the exact
  normalized identity/policy and preserve UNKNOWN/quarantine outcomes.
- **INT-016 C03↔C06:** every accepted route becomes one workflow/no-impact
  decision despite duplicate and out-of-order delivery.
- **INT-017 C03↔C14:** every deployed artifact, including hotfix, reconciles to a
  lineage binding/alert; coalescing cannot hide it.
- **INT-018 C03↔C18:** queue/DLQ/archive metrics reconcile; replay/redrive,
  outage, and cross-Region recovery preserve business idempotency.
- **INT-019 C03↔C17:** users/operators can see intake, duplicate, quarantine,
  deferred, queue, DLQ, and replay status without direct AWS console access.

## 17. Definition of Done

- All producer/event schemas, source policies, normalization examples, routes,
  queues, DLQs, archive, idempotency, and replay APIs are implemented as IaC.
- C03 P0 requirements and C03-CT-001 through C03-CT-012 pass.
- INT-013 through INT-019 pass with deployed production-shaped components.
- The load/fairness report proves exact event reconciliation, 10,000 burst,
  sustained throughput, and Tier-1 protection.
- Security/privacy evidence proves producer isolation, forbidden-field denial,
  encrypted least privilege, sanitized failures, and replay audit.
- DLQ/redrive, EventBridge replay, admission, source auth, and Region recovery
  runbooks are exercised and linked to alarms.

## 18. Implementation Notes

```text
contracts/schemas/events/
contracts/examples/events/
services/event-normalizer/
services/event-normalizer/src/idempotency/
infra/lib/constructs/event-bus.ts
infra/lib/constructs/priority-queues.ts
infra/lib/constructs/event-archive.ts
tests/contract/events/
tests/integration/event-intake/
tests/load/event-intake/
tests/chaos/event-intake/
```

Implement control services in TypeScript 5 on Lambda. Use EventBridge custom
bus/archive and SQS Standard queues. DynamoDB conditional writes hold
idempotency/routing state. Put normalized/oversized immutable envelopes in C12
S3. Do not use FIFO assumptions or introduce Kafka/MSK for initial scope.

Build order: schemas/source verification; normalization/idempotency; bus/archive;
queues/DLQs/rules; admission/coalescing; replay/redrive; load/security/recovery.
Canary routing policy versions by producer/event type and compare outcomes
before activation.

## 19. Traceability

| Source decision | C03 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| EventBridge routes; SQS buffers | C03-FR-008 through C03-FR-012 | C03-CT-008/009/012 | INT-016/018; foundation gate |
| At-least-once/idempotency and immutable identities | C03-FR-003 through C03-FR-007 | C03-CT-004 through C03-CT-007 | INT-014/016/017 |
| No silent event/drop; replay/redrive | C03-FR-013 through C03-FR-015 | C03-CT-009/010 | INT-018/019; chaos gate |
| 10,000 burst and priority isolation | C03-NFR-001/002; C03-FR-009/011 | C03-CT-012 | Enterprise load/fairness gate |
| Security/privacy | C03-SEC-001 through C03-SEC-005 | C03-CT-002/003/011 | INT-014/018; security gate |


---

# 04-eligibility-and-substrate-routing.md

# C04 Repository Eligibility and Substrate Routing PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C04 |
| Status | Approved for implementation |
| Launch phase | Foundation and baseline |
| Criticality | P0; prevents silent exclusion and routes analysis to the cheapest trustworthy lane |
| Primary owner | Lineage policy and onboarding team |
| Required approvers | Architecture, product, application governance, analyzer owners |
| Upstream dependencies | C01 identity, C02 inventory, C03 normalized triggers, governed service catalog/policy |
| Downstream dependencies | C05-C11, C14-C15, C17-C18 |
| Authoritative sources | AWS architecture §7 and §9.3; element-level v2 R1/R11/R12; component design §6 |

## 2. Purpose and Outcomes

C04 inventories the meaning of each repository or workload path before costly
analysis. It decides whether the unit produces standalone lineage, acts as a
dependency/trigger, represents contracts or tests, or requires classification
review. For eligible producers it assigns exactly one Lane A, Lane B, or Lane C
as governed data rather than hard-coded control flow.

Measurable outcomes:

- 100% of discovered repository/path units receive an effective classification
  decision or visible `UNKNOWN` review record; zero silent exclusions.
- 100% of eligible producers have exactly one effective lane assignment; a
  missing assignment is an explicit coverage gap.
- Reclassification and override expiry cause the specified downstream action
  without deleting accepted lineage automatically.
- Classification/routing replay with the same evidence/policy version is byte-
  identical.

## 3. Scope and Non-Goals

### In scope

- Repository/workload classification and standalone baseline eligibility.
- Path-level boundaries for `MIXED_MONOREPO`.
- Evidence precedence, rules, reason codes, policy version, expiry, manual
  override, review, and effective decision registry.
- Lane A/B/C substrate assignment per eligible producer/workload.
- Change-transition actions and trigger hints for downstream context/workflows.

### Non-goals

- Discovering inventory evidence (C02).
- Building dependency/consumer/determinant indexes (C05).
- Executing any collector/analyzer (C07-C11).
- Using an LLM to automatically exclude a repository.
- Deleting or deactivating accepted graph state solely because a new decision
  says excluded.
- Treating eligibility as a capacity/sizing shortcut; design capacity remains
  10,000 repositories.

## 4. Actors and Use Cases

| Actor | Use case |
|---|---|
| Application owner | Review unknown/conflicting classification and provide governed evidence |
| Governance administrator | Define policy/routing table and time-bounded override |
| C05 context builder | Know whether to analyze, index consumers/bindings/contracts/tests, or wait for review |
| C06 orchestrator | Route eligible units to Lane A/B/C and trigger transition actions |
| Analyzer owner | Add an archetype/lane only after capability and contract readiness |
| Auditor/operator | Reproduce a decision and understand excluded/unknown/stale counts |

Primary cases:

1. Spring Boot Kafka service -> `APPLICATION_RUNTIME`, Lane A.
2. Spark SQL or dbt project -> `DATA_PIPELINE`, Lane B.
3. Vendor binary without readable source/native plan -> eligible workload,
   Lane C advisory.
4. Shared library -> no standalone baseline, but index consumers and selectively
   reanalyze them on relevant change.
5. Documentation repository with Avro/OpenAPI ->
   `CONTRACT_SCHEMA_SOURCE`, not pure documentation.
6. Monorepo -> path-level application, infrastructure, library, and docs units.

## 5. Component Boundary

### Owned behavior

- `RepositoryEligibilityDecision` generation, review, registry, and transitions.
- Versioned classification policy, evidence precedence, and lane routing table.
- Explanation/reason/evidence and explicit coverage gaps.

### Inputs

- C02 repository/path/manifests/deployment/schema/test/context observations.
- C01 canonical identities and registry version.
- Governed catalog metadata and manual decision/override.
- Prior effective decision and current policy version.

### Outputs

- Immutable eligibility decision plus effective DynamoDB registry entry.
- Class/lane/transition action event for C05/C06/C14.
- UNKNOWN/conflict/expired-override review item.

### Forbidden behavior

- Defaulting `UNKNOWN` to documentation/excluded or inferring exclusion from no
  recent deployment.
- Assigning multiple effective lanes to one producer/workload.
- Hard-coding routing in analyzer/orchestrator deployment code.
- Letting heuristic/LLM evidence outrank governed metadata or auto-exclude.
- Deleting current lineage when included becomes excluded.
- Using interaction context alone to classify a field-level lineage producer.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C04-FR-001 | C04 must assign exactly one repository/path classification: `APPLICATION_RUNTIME`, `DATA_PIPELINE`, `CONTRACT_SCHEMA_SOURCE`, `SHARED_LIBRARY`, `INFRASTRUCTURE`, `DOCUMENTATION`, `TEST_AUTOMATION`, `MIXED_MONOREPO`, or `UNKNOWN`. | P0 |
| C04-FR-002 | Every C02 repository must receive an immutable decision/evidence/reason or explicit `UNKNOWN`; no repository may be silently omitted from the eligibility registry. | P0 |
| C04-FR-003 | Classification must apply evidence precedence: governed catalog/repository metadata, Test Automation association, CI/CD deployable artifact, deterministic manifests/structure, SBOM/dependency evidence, CloudWatch association, then heuristics requiring review. | P0 |
| C04-FR-004 | An LLM may propose a classification but must not automatically exclude, override higher-precedence evidence, or activate a decision. | P0 |
| C04-FR-005 | `APPLICATION_RUNTIME` and `DATA_PIPELINE` must be eligible for standalone baseline/incremental analysis; `CONTRACT_SCHEMA_SOURCE` must receive metadata-only treatment and trigger connected producers/consumers. | P0 |
| C04-FR-006 | `SHARED_LIBRARY`, `INFRASTRUCTURE`, `DOCUMENTATION`, and `TEST_AUTOMATION` must not run standalone lineage, but must emit the specified consumer/binding/no-impact/test-coverage action for C05/C06. | P0 |
| C04-FR-007 | A repository containing authoritative OpenAPI, AsyncAPI, Avro, Protobuf, JSON Schema, or equivalent governed contract must not be classified as pure `DOCUMENTATION` for those paths. | P0 |
| C04-FR-008 | A repository containing independently deployable and excluded units must be `MIXED_MONOREPO` with nonoverlapping governed path units and a catch-all/unknown rule. | P0 |
| C04-FR-009 | Every eligible producer/workload must have exactly one effective Lane A, Lane B, or Lane C assignment; no assignment must be surfaced as a blocking coverage gap. | P0 |
| C04-FR-010 | The baseline lane table must route Spark SQL, dbt, and Airflow-orchestrated SQL to Lane B; Spring Boot, FastAPI, and Dask custom code to Lane A; and workloads with neither readable source nor authoritative native plan to Lane C. | P0 |
| C04-FR-011 | Lane assignment and classification policy must be versioned data; reassigning an archetype/producer must not require a platform deployment. | P0 |
| C04-FR-012 | Manual overrides must name decision, scope, evidence, reviewer, rationale, effective/expiry, and prior policy; expiry must automatically re-evaluate rather than silently extend. | P0 |
| C04-FR-013 | An excluded-to-included transition must request baseline; included-to-excluded must require review/undeployment confirmation and keep current graph marked stale until governed change. | P0 |
| C04-FR-014 | Documentation-to-contract, library-to-deployable, and known-to-unknown/conflicting transitions must emit the specified re-evaluation/ownership/stale actions and preserve history. | P0 |
| C04-FR-015 | Decisions must be deterministic for identical inventory/evidence, policy, C01 registry, and prior-decision versions and must expose all rules/evidence used. | P0 |
| C04-FR-016 | C04 must support preview mode showing decision/transition deltas before policy activation across a representative estate snapshot. | P1 |

### Classification behavior

| Classification | Standalone baseline | Change behavior |
|---|---:|---|
| `APPLICATION_RUNTIME` | Yes | Incremental lineage |
| `DATA_PIPELINE` | Yes | Incremental plus native lineage |
| `CONTRACT_SCHEMA_SOURCE` | Metadata only | Re-evaluate connected producers/consumers |
| `SHARED_LIBRARY` | No | Resolve consumers and selectively reanalyze |
| `INFRASTRUCTURE` | No | Evaluate lineage-relevant bindings/routes/config |
| `DOCUMENTATION` | No | Record `NO_LINEAGE_IMPACT` unless machine contract path |
| `TEST_AUTOMATION` | No | Update coverage/test mapping and runtime freshness |
| `MIXED_MONOREPO` | Per path | Route each path unit |
| `UNKNOWN` | Never silently excluded | Quarantine/review, then replay |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C04-NFR-001 | Classifying a standard repository decision must complete within 500 ms p95 excluding human review; 10,000 decisions must complete within 15 minutes at planned concurrency. | P0 |
| C04-NFR-002 | Policy evaluation must be deterministic and byte-identical across repeated runs; rules may not depend on wall-clock time except explicit effective/expiry input. | P0 |
| C04-NFR-003 | The effective registry must be 99.95% available monthly with immutable history and PITR; C06 may use a pinned last-good decision only when marked stale and policy permits. | P0 |
| C04-NFR-004 | Policy preview must enumerate 100% of decision/lane/transition changes for the evaluated snapshot and produce no active side effect. | P1 |

## 7. Data and Durable State

`RepositoryEligibilityDecision` fields:

- decision ID/version, organization, repository canonical/native ID.
- workload/path unit ID, root/include/exclude patterns, build/deploy descriptor.
- classification and standalone behavior.
- eligible producer/archetype and lane (`A`, `B`, `C`, or absent coverage gap).
- reason codes and ranked evidence references.
- application/domain/owner and dependency action hints.
- policy/C01/inventory/prior decision versions.
- effective/expiry, manual override/reviewer/rationale.
- status: `PROPOSED`, `REVIEW_REQUIRED`, `ACTIVE`, `STALE`, `SUPERSEDED`, or
  `EXPIRED`.
- deterministic input/output checksums and reconciliation time.

`EligibilityPolicy` contains typed rules, source/evidence precedence, class and
lane tables, path matching rules, ambiguity thresholds, required review cases,
transition actions, owner, semantic version, effective time, and checksum.

S3 keeps immutable decisions/policies/previews. DynamoDB provides the effective
repository/path registry and application/class/lane/review indexes.

## 8. Interfaces and Contracts

### Evaluate one repository

`POST /v1/eligibility:evaluate` accepts inventory snapshot reference/checksum,
repository ID, optional prior decision, policy/C01 versions, and dry-run. It
returns a decision proposal plus transition actions. It never activates a
review-required decision.

### Batch evaluation/preview

`POST /v1/eligibility:evaluateBatch` accepts an S3 manifest of repositories and
returns an S3 result manifest/counts/deltas. Step Functions Distributed Map
controls concurrency; no 10,000-item body enters API/workflow state.

### Review/activate

- `POST /v1/eligibility-decisions/{id}/review` records approve/correct/reject
  under expected decision version.
- `POST /v1/eligibility-policies/{version}:activate` requires preview summary,
  compatibility/contract tests, approval, and expected active policy.
- Events: `eligibility.decision.activated`, `eligibility.review.requested`,
  `eligibility.override.expiring`, `eligibility.transition.required`.

## 9. Processing and State Model

```text
EVIDENCE_READY -> EVALUATING -> PROPOSED
                              -> REVIEW_REQUIRED
PROPOSED/REVIEW_REQUIRED -> ACTIVE -> STALE -> SUPERSEDED
                                  \-> EXPIRED -> EVALUATING
```

Algorithm:

1. Pin inventory/C01/policy/prior versions and validate source completeness.
2. Identify deterministic workload boundaries from build manifests, deployment
   descriptors, container definitions, project boundaries, and path policy.
3. Evaluate all evidence by precedence. A lower tier cannot overturn a decided
   higher tier; contradictory highest-tier evidence requires review.
4. Select class and reason. For mixed repository, validate nonoverlap and
   catch-all behavior, then evaluate path units.
5. For eligible producers, apply lane routing data. Multiple matching lanes or
   no match yields review/coverage gap, not arbitrary selection.
6. Compare prior effective decision and produce transition actions.
7. Canonically serialize/checksum; auto-activate only deterministic policies
   explicitly allowed by governance. Preserve every proposal/history.

## 10. Failure Semantics

| Code | Class | Required behavior |
|---|---|---|
| `INSUFFICIENT_EVIDENCE` | `INCOMPLETE` | Return `UNKNOWN`; request owner/review; never exclude |
| `CLASSIFICATION_CONFLICT` | `CONFLICT` | Preserve top evidence claims; review required |
| `LANE_UNASSIGNED` | `INCOMPLETE` | Explicit coverage gap; block eligible workload completion |
| `LANE_MULTIPLE_MATCH` | `CONFLICT` | No route; policy review with matching rules |
| `MONOREPO_PATH_OVERLAP` | `DETERMINISTIC_INVALID` | Reject decision/policy; identify overlapping units |
| `POLICY_VERSION_INVALID` | `DETERMINISTIC_INVALID` | Quarantine request; do not use implicit latest |
| `OVERRIDE_EXPIRED` | `INCOMPLETE` transition | Mark stale, re-evaluate, notify owner |
| `REGISTRY_WRITE_CONFLICT` | `TRANSIENT` or `CONFLICT` | Retry same expected version or recompute against new prior |
| `POLICY_ENGINE_UNAVAILABLE` | `TRANSIENT` | Bounded retry; optional pinned last-good stale behavior by policy |

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C04-SEC-001 | Policy activation, manual override, included-to-excluded approval, and decision correction must require enterprise identity, scoped governance role, rationale, evidence, and audit. | P0 |
| C04-SEC-002 | Decision/evidence reads must enforce organization/domain RBAC and sensitive metadata ABAC; heuristic/LLM evidence must not contain repository secrets or payloads. | P0 |
| C04-SEC-003 | Policy/decision artifacts and effective registry must use KMS, TLS/private access, immutable history/PITR, and separate evaluator/reviewer/activator permissions. | P0 |
| C04-SEC-004 | Policy evaluation must use signed/versioned bundles and reject unregistered code/plugins or arbitrary executable rules. | P0 |
| C04-SEC-005 | Audit must record source evidence IDs/checksums and decisions without copying sensitive evidence bodies. | P0 |

## 12. Scale, Performance, and Availability

- Evaluate up to 10,000 repositories and path-level monorepo units; sizing does
  not assume exclusions.
- Policy evaluation is a pure bounded function over normalized metadata; source
  checkout/SCA is forbidden.
- Batch manifests shard by organization/domain/repository hash and reserve
  capacity for event-driven reclassification.
- Cache key includes inventory content signature, repository/path ID, C01,
  policy, and prior-decision versions. Cache results are invalidated by any
  determinant change.
- Registry history is durable; effective reads are Multi-AZ and restored within
  C18 RPO/RTO.

## 13. Observability

| ID | Signal | Dimensions/alert | Priority |
|---|---|---|---|
| C04-OBS-001 | Decision counts | class, lane, application/domain, policy version | P0 |
| C04-OBS-002 | Unknown/conflict/lane-gap counts and age | owner, reason, criticality; alert critical active gap | P0 |
| C04-OBS-003 | Override count/expiry | class/lane/owner/reviewer; notify before expiry | P0 |
| C04-OBS-004 | Transition actions | old/new class/lane, action status, affected applications | P0 |
| C04-OBS-005 | Policy preview/activation deltas | changed class/lane/unknown/exclusion counts; audit | P0 |
| C04-OBS-006 | Evaluation latency/cache/error | policy version, archetype, batch/online | P1 |

C17 shows reason/evidence/override/expiry and distinguishes excluded from unknown.
Counts reconcile to the C02 inventory; any missing decision is a P0 alert.

## 14. Acceptance Criteria

| ID | Acceptance criterion |
|---|---|
| C04-AC-001 | Given one fixture for every class, C04 emits the exact class, standalone behavior, reason/evidence, and transition hint under the baseline policy. |
| C04-AC-002 | Given Spring/FastAPI/Dask, Spark/dbt/Airflow SQL, and opaque vendor workloads, exactly one Lane A, Lane B, and Lane C route respectively is selected as policy data. |
| C04-AC-003 | Given insufficient or conflicting top evidence, C04 returns `UNKNOWN`/review and does not exclude or schedule arbitrary analysis. |
| C04-AC-004 | Given a documentation repository with an authoritative schema path, that path is `CONTRACT_SCHEMA_SOURCE` and connected producer/consumer re-evaluation is requested. |
| C04-AC-005 | Given a mixed monorepo, every changed path maps to exactly one governed workload unit or catch-all unknown; overlaps fail activation. |
| C04-AC-006 | Given an override expiry, C04 marks the decision stale, re-evaluates, notifies/reviews, and never silently extends or deletes active graph state. |
| C04-AC-007 | Given included-to-excluded and library-to-deployable transitions, the required review/undeployment confirmation and ownership/baseline actions are emitted and history is preserved. |
| C04-AC-008 | Given the 10,000-repository fixture, evaluation meets C04-NFR-001 with exact inventory-to-decision reconciliation and deterministic checksums. |

## 15. Component Test Matrix

| ID | Level | Fixture/precondition | Action | Expected result | Retained evidence |
|---|---|---|---|---|---|
| C04-CT-001 | Table/unit | One clear fixture per classification | Evaluate | Exact class/behavior/reason | Golden decisions |
| C04-CT-002 | Precedence | Conflicting evidence at different tiers | Evaluate | Highest tier wins; all evidence retained | Rule trace |
| C04-CT-003 | Conflict | Conflicting governed evidence same tier | Evaluate | `CLASSIFICATION_CONFLICT`/review; no active exclusion | Conflict record |
| C04-CT-004 | Lane table | Six baseline archetypes plus opaque source | Route | Exactly expected Lane A/B/C assignment | Routing golden |
| C04-CT-005 | Lane gaps | No lane and multiple matching rules | Route | Explicit gap/conflict; no arbitrary schedule | Gap records |
| C04-CT-006 | Monorepo | Deployable/library/infra/docs paths plus unowned path | Classify paths | Nonoverlapping units; catch-all unknown | Path manifest |
| C04-CT-007 | Contract boundary | Documentation repo with OpenAPI/Avro | Classify | Contract source action, not pure docs | Decision/action |
| C04-CT-008 | Override | Active override reaches expiry | Reconcile | Stale/re-evaluate/notify; no extension/delete | State/audit timeline |
| C04-CT-009 | Transition | All material old->new class transitions | Activate | Exact downstream action table | Transition event set |
| C04-CT-010 | Security | LLM proposes exclude; unauthorized override/policy | Evaluate/apply | Proposal cannot activate; access denied/audited | Policy/audit evidence |
| C04-CT-011 | Determinism/preview | Same snapshot/policy repeated; candidate new policy | Evaluate/preview | Same bytes; exact delta; no active effect | Checksums/registry before-after |
| C04-CT-012 | Load/recovery | 10,000 repositories, monorepo skew, worker restart | Batch evaluate | SLO/reconciliation met; no missing/duplicate decision | Load report/manifests |

## 16. Integration Obligations

- **INT-020 C02↔C04:** all inventory repositories/path evidence produce a
  decision/UNKNOWN and counts reconcile exactly.
- **INT-021 C03↔C04:** duplicate/out-of-order triggers reuse/recompute the
  correct versioned decision without duplicate transition effects.
- **INT-022 C04↔C05:** each class produces the correct application context,
  consumer/binding/contract/test/no-impact indexing instruction.
- **INT-023 C04↔C06/C07-C11:** eligible producers route to exactly one lane;
  excluded/unknown units never execute an incorrect standalone analyzer.
- **INT-024 C04↔C14:** class/lane/policy changes invalidate the correct artifact
  lineage decisions and stale bindings.
- **INT-025 C04↔C15/C17:** unknown/conflict/override/transition review and user
  explanation preserve immutable versions and do not auto-delete lineage.
- **INT-026 C04↔C18:** policy activation/rollback, expiry, reconciliation,
  security audit, load, and Region restore pass operations gates.

## 17. Definition of Done

- Typed eligibility/policy/transition contracts, baseline rule tables, reason
  codes, examples, and effective registry are implemented.
- C04 P0 requirements and C04-CT-001 through C04-CT-012 pass.
- INT-020 through INT-026 pass with production-shaped upstream/downstreams.
- Inventory-to-decision reconciliation proves zero silent exclusions and every
  eligible producer has exactly one lane or visible blocking gap.
- Policy preview/activation/rollback, override expiry, unknown/conflict review,
  and included-to-excluded runbooks are exercised.
- Security tests prove no LLM auto-exclusion, role separation, signed policies,
  evidence isolation, and complete audit.
- The 10,000-repository load report and dashboards/alarms meet SLO/gates.

## 18. Implementation Notes

```text
contracts/schemas/eligibility/
contracts/examples/eligibility/
services/eligibility/
services/eligibility/src/policy/
services/eligibility/src/monorepo/
services/eligibility/src/transitions/
infra/lib/constructs/eligibility-registry.ts
tests/contract/eligibility/
tests/integration/eligibility/
tests/load/eligibility/
```

Use TypeScript 5 for a pure policy evaluator on Lambda and DynamoDB for effective
lookup; S3 stores immutable policies/decisions/previews. Policy is declarative,
typed, signed, and side-effect-free during evaluation. Activation emits actions
through C03; it never invokes analyzers directly.

Implement the baseline class/lane table first, then monorepo paths, overrides/
transitions, preview/activation, and UI/reconciliation. New archetypes enter as
policy plus verified analyzer capability, not a catch-all heuristic.

## 19. Traceability

| Source decision | C04 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| Inventory all; no silent exclusion | C04-FR-001 through C04-FR-004 | C04-CT-001/002/003/010 | INT-020/025; baseline gate |
| Class-specific behavior and monorepos | C04-FR-005 through C04-FR-008 | C04-CT-006/007/009 | INT-022/023 |
| Substrate-routed Lane A/B/C as data | C04-FR-009 through C04-FR-011 | C04-CT-004/005/011 | INT-023; analyzer gate |
| Overrides/transitions preserve approved graph | C04-FR-012 through C04-FR-015 | C04-CT-008/009 | INT-024/025/026 |
| Enterprise capacity/determinism | C04-NFR-001 through C04-NFR-004 | C04-CT-011/012 | Enterprise load gate |
| Governance/security | C04-SEC-001 through C04-SEC-005 | C04-CT-010 | INT-025/026; security gate |


---

# 05-context-dependency-and-determinants.md

# C05 Application Context, Dependency, and Determinant Indexes PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C05 |
| Status | Approved for implementation |
| Launch phase | Baseline and incremental foundation |
| Criticality | P0; incremental soundness and excluded-repository triggers depend on these indexes |
| Primary owner | Lineage context and dependency team |
| Required approvers | Architecture, analyzer, deployment/platform, schema/catalog, Test Automation owners |
| Upstream dependencies | C01 identity, C02 inventory, C04 eligibility |
| Downstream dependencies | C06-C14, C17-C18 |
| Authoritative sources | AWS architecture §§8.1, 8.3, 9.2-9.3, 13, 17; element-level v2 R9 |

## 2. Purpose and Outcomes

C05 produces a version-pinned `ApplicationContextSnapshot` and the reverse
indexes needed to answer two questions safely: which repositories and evidence
form this business application, and which accepted/proposed edges must be
reconsidered when a file, symbol, schema, configuration key, dependency,
contract, test, or infrastructure binding changes.

Measurable outcomes:

- Every baseline pins one context/dependency-index version with explained
  application associations and coverage gaps.
- Every accepted candidate edge and open hole has a nonempty `DeterminantSet`
  or a visible `DETERMINANTS_INCOMPLETE` defect.
- Relevant shared library, infrastructure, contract, and test changes resolve
  affected applications; irrelevant capacity/documentation changes record
  explicit no-impact decisions.
- Scheduled full scans show zero full-scan divergence from determinant-based
  incremental results; any non-zero divergence is a defect.

## 3. Scope and Non-Goals

### In scope

- Application/repository association resolution with ranked evidence.
- Immutable context snapshots containing repository/path decisions, deployments,
  schemas/contracts/native jobs/tests, and selected interaction context.
- DependencyRecord indexes for shared library consumers, infrastructure
  bindings, contract producers/consumers, and test-scenario coverage.
- DeterminantSet schema and reverse indexes across files, symbols, schemas,
  configuration keys, build inputs, dependency versions, policy/analyzer
  versions, and generated inputs.
- Incremental invalidation planning, no-impact reasoning, freshness, and
  full-scan divergence reports.

### Non-goals

- Classifying repositories or lanes (C04).
- Parsing code to discover analyzer-owned symbol/dataflow determinants (C08).
- Scheduling/performing analysis (C06-C11).
- Assuming changed-file proximity or forward reachability alone is sound.
- Directly asserting field derivation from infrastructure or interaction data.

## 4. Actors and Use Cases

| Actor/component | Use case |
|---|---|
| Application owner | Inspect repositories, deployments, contracts, tests, and association evidence |
| C06 | Plan baseline and targeted incremental work from immutable context/indexes |
| C08 | Read context and add precise analyzer determinants |
| C13/C14 | Attach determinants to edges/holes and decide invalidation/freshness |
| Platform operator | Reconcile indexes, diagnose fan-out, and run full-scan divergence |

Representative scenarios:

1. `application.yaml` changes a Spring qualifier; C05 invalidates every edge/hole
   determined by that configuration key even when no Java file changed.
2. A shared library serializer signature changes; C05 finds pinned consumers and
   schedules only affected deployed/application artifacts.
3. Infrastructure CPU/memory tags change; C05 records no lineage impact. A
   topic route/env endpoint changes; affected applications are re-evaluated.
4. An Avro schema field changes; connected producers/consumers and their
   determinants are returned.
5. A test scenario changes; mapped runtime evidence becomes stale and targeted
   recollection is proposed.

## 5. Component Boundary

### Owned behavior

- Context association precedence and snapshot assembly.
- Dependency/index schemas, writes, reverse lookups, versioning, reconciliation.
- Determinant invalidation planning and change-impact reason records.

### Inputs

- C02 inventory snapshot and source completeness.
- C04 effective classification/path/lane decisions.
- C01 registry version/canonical URNs.
- C08/C13 determinant additions and accepted graph/proposal references.
- Repository/deployment/schema/infrastructure/test changes from C03.

### Outputs

- `ApplicationContextSnapshot`, `DependencyRecord`, `DeterminantSet`,
  `InvalidationPlan`, and `IndexReconciliationReport` references/checksums.

### Forbidden behavior

- Guessing owner/application when evidence remains tied.
- Treating a shared library commit as active canonical lineage before an
  affected consuming artifact is analyzed/deployed.
- Treating infrastructure binding/interaction evidence as field derivation.
- Dropping a determinant because the referenced file/symbol was deleted.
- Declaring no impact from changed-file/path comparison alone.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C05-FR-001 | C05 must create an immutable `ApplicationContextSnapshot` pinned to inventory, C01 registry, C04 policy/decision, source watermark, and context-builder versions. | P0 |
| C05-FR-002 | Application/repository association must use precedence: governed catalog/Test Automation ownership, deployment/artifact metadata, explicit config/contract reference, observed interaction, then inference requiring review. | P0 |
| C05-FR-003 | Tied or missing material association evidence must remain an explicit context conflict/gap; C05 must not choose by repository name similarity. | P0 |
| C05-FR-004 | Context must include all classified repository/path units, commit/digest/environment, owners/domains, deployments, schemas/contracts, native jobs, test scenarios, and selected interaction evidence with source completeness. | P0 |
| C05-FR-005 | C05 must index a shared library/package and pinned/ranged version to every consuming repository/workload/artifact with evidence and validity interval. | P0 |
| C05-FR-006 | C05 must index infrastructure routes, topics, queues, endpoints, schemas, environment variables, task wiring, and service-discovery bindings to affected applications, while distinguishing capacity-only attributes. | P0 |
| C05-FR-007 | C05 must index every contract/schema to producing and consuming workloads/fields where known and preserve unresolved producer ambiguity. | P0 |
| C05-FR-008 | C05 must index test scenarios to application/workload, expected sidecars, schema/field coverage, artifact digest, and runtime-evidence freshness. | P0 |
| C05-FR-009 | Every edge/hole analysis package must supply or inherit a `DeterminantSet` covering files, symbols, schemas, configuration keys, build/generated inputs, dependency versions, and analyzer/policy/contract versions that can change it. | P0 |
| C05-FR-010 | Reverse indexes must answer determinant-to-edge/hole/workload/application and dependency/binding/contract/test-to-application with the exact index version used. | P0 |
| C05-FR-011 | Invalidation must follow changed determinants and dependency/binding semantics, not merely the changed-file set or forward call-graph reachability. | P0 |
| C05-FR-012 | Deleted/renamed determinants must invalidate prior dependents and preserve tombstone/alias evidence until the resulting proposal is reviewed. | P0 |
| C05-FR-013 | Capacity-only infrastructure and pure documentation changes may produce `NO_LINEAGE_IMPACT` only from versioned typed rules and must retain evaluated attributes/reason. | P0 |
| C05-FR-014 | Test changes affecting lineage-relevant scenarios must mark mapped runtime evidence stale and request targeted recollection; unrelated test metadata changes must record no impact. | P0 |
| C05-FR-015 | Scheduled full scan must compare its complete edge/hole result with the accumulated incremental result and publish full-scan divergence; non-zero unexplained divergence is a defect. | P0 |
| C05-FR-016 | Index/context version activation must be conditional/atomic and retain immutable prior versions so in-flight runs never mix index versions. | P0 |
| C05-FR-017 | C05 should provide preview/fan-out estimates and owner/cost before activating a large invalidation plan. | P1 |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C05-NFR-001 | One repository change invalidation query must return within 2 seconds p95 for 99% of estate changes; larger fan-out returns a manifest within 30 seconds p95. | P0 |
| C05-NFR-002 | A context/dependency build for 10,000 repositories must complete within 90 minutes and produce exact inventory/index reconciliation counts. | P0 |
| C05-NFR-003 | Index reads/effective pointers must be 99.95% available monthly; immutable versions must restore within C18 RPO/RTO. | P0 |
| C05-NFR-004 | Repeating context/index/invalidation construction with the same inputs/versions must produce byte-identical manifests/checksums. | P0 |

## 7. Data and Durable State

### `ApplicationContextSnapshot`

- application/domain/owner canonical identities and association evidence.
- inventory/C01/C04/source/context-builder versions and completeness.
- repository/path units with class/lane, commit, deployed digests/environments.
- schema/contract/native job/test/interaction references.
- dependency/index version, conflict/gap list, counts/checksum.

### `DependencyRecord`

Typed variants:

- `LIBRARY_CONSUMER`: package/library/version/exported interface -> consumer
  repository/workload/artifact and lockfile/SBOM/build evidence.
- `INFRASTRUCTURE_BINDING`: route/topic/queue/endpoint/schema/environment
  variable/task/service discovery -> application/workload/environment.
- `CONTRACT_RELATION`: schema/contract/version -> producer/consumer/workload.
- `TEST_MAPPING`: scenario/version -> workload, expected sidecar, covered
  schemas/fields, artifact/test run.

All records include canonical IDs, validity interval, evidence, source/index
version, status/tombstone, and checksum.

### `DeterminantSet`

Typed determinants: `FILE`, `SYMBOL`, `SCHEMA`, `CONFIG_KEY`, `BUILD_INPUT`,
`GENERATED_INPUT`, `DEPENDENCY_VERSION`, `CONTRACT_VERSION`, `POLICY_VERSION`,
`ANALYZER_VERSION`, and `RUNTIME_SCENARIO`. Each includes content/version hash,
location/selector, role, evidence, and validity. The set is canonically sorted
and content-addressed.

### `InvalidationPlan`

Contains change event, prior/current context/index versions, changed/tombstoned
determinants, affected edges/holes/workloads/applications, reason path,
class-specific action, priority, fan-out/cost estimate, no-impact decisions,
gaps/conflicts, and manifest checksum.

S3 is authoritative for snapshots/manifests/reports. DynamoDB stores effective
pointers and reverse indexes with application/domain/repository sharding.

## 8. Interfaces and Contracts

- `POST /v1/application-contexts:build` accepts application, inventory/C01/C04
  versions, prior context, and idempotency; returns run/reference.
- `GET /v1/application-contexts/{applicationId}/versions/{version}` returns an
  immutable reference/checksum and completeness, not an oversized embedded body.
- `POST /v1/dependencies:upsertManifest` accepts C02/C08 produced typed records
  by S3 reference, expected index version, and checksum.
- `POST /v1/invalidation-plans` accepts normalized change event reference,
  expected active context/index/graph versions, dry-run, and policy.
- `POST /v1/full-scan-divergence` compares checksummed full/incremental manifests.
- Events: `application.context.activated`, `dependency.index.activated`,
  `invalidation.plan.created`, `lineage.no-impact.recorded`,
  `incremental.divergence.detected`.

All list/query APIs paginate and return the index/version watermark. Empty result
is distinguishable from incomplete/unavailable index.

## 9. Processing and State Model

### Context/index lifecycle

```text
REQUESTED -> ASSEMBLING -> RESOLVING -> VALIDATING -> STAGED
          -> RECONCILED -> ACTIVE -> SUPERSEDED
```

`INCOMPLETE`, `CONFLICT`, and `FAILED` remain queryable. Activation requires
expected prior pointer and immutable read-back/checksum.

### Invalidation algorithm

1. Pin change event, active context/dependency/determinant indexes, accepted
   graph, and policy versions.
2. Normalize changed/deleted files, symbols, schemas, configuration key values,
   build/generated inputs, dependency/contract versions, infrastructure
   attributes, and test scenarios.
3. Traverse reverse determinants to candidate edges/holes/workloads.
4. Apply class-specific dependency semantics:
   - application/pipeline: affected determinants.
   - shared library: changed exported serializer/mapper/schema/config interface
     -> compatible/pinned consumers; canonical state changes after consumer
     artifact analysis/deployment.
   - infrastructure: lineage-relevant bindings only; capacity attributes no
     impact.
   - contract: connected producers/consumers.
   - test: coverage/freshness and targeted recollection.
   - documentation/mixed/unknown: C04 path action/review.
5. Compute reason paths and union affected work. Never subtract solely because
   forward reachability did not find a path.
6. Validate completeness/conflicts, estimate fan-out, write immutable plan, and
   emit through C03 to C06.

## 10. Failure Semantics

| Code | Class | Required behavior |
|---|---|---|
| `CONTEXT_SOURCE_INCOMPLETE` | `INCOMPLETE` | Preserve partial context; block/qualify baseline per criticality |
| `APPLICATION_ASSOCIATION_CONFLICT` | `CONFLICT` | Preserve candidates/evidence; review required |
| `DETERMINANTS_INCOMPLETE` | `INCOMPLETE` | Do not claim bounded incremental soundness; schedule full/expanded analysis |
| `INDEX_VERSION_CONFLICT` | `CONFLICT` | Recompute against new active version; do not mix |
| `INDEX_WRITE_THROTTLED` | `TRANSIENT` | Bounded retry/checkpoint/idempotency |
| `DEPENDENCY_AMBIGUOUS` | `CONFLICT` | Include conservative affected candidates and visible review item |
| `NO_IMPACT_RULE_INVALID` | `DETERMINISTIC_INVALID` | Do not issue no-impact; quarantine policy/input |
| `FULL_SCAN_DIVERGENCE` | `DETERMINISTIC_INVALID` defect | Alert, retain diff, block stricter incremental enforcement until corrected |

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C05-SEC-001 | Context/index reads and writes must enforce organization/domain RBAC and sensitive metadata ABAC; consumers receive only required namespaces. | P0 |
| C05-SEC-002 | Snapshots/indexes must store metadata/evidence references, not repository credentials, raw payloads, configuration secret values, or payload-bearing logs. | P0 |
| C05-SEC-003 | S3/DynamoDB must use KMS, TLS/private access, PITR/version history, and separate builders/readers/activators with no wildcard cross-domain data permissions. | P0 |
| C05-SEC-004 | No-impact rules, context association overrides, index activation, and divergence waivers must be versioned, approved, and audited. | P0 |
| C05-SEC-005 | Configuration determinants must record key/path and irreversible content/version hash where needed, never secret plaintext. | P0 |

## 12. Scale, Performance, and Availability

- Index 10,000 repositories plus all applications, path units, artifacts,
  dependencies, schemas, configuration keys, tests, edges, and holes.
- Partition reverse indexes by organization/type/hash prefix; fan-out results
  over API limits use S3 manifests and Step Functions Distributed Map.
- Cache immutable context/index versions locally by checksum. A run records one
  version and cannot observe pointer changes midrun.
- Per-domain fan-out admission prevents a central library change from starving
  Tier-1 deployment changes; C06 applies final scheduling fairness.
- Full index rebuild and restore are tested from S3 under the four-hour RTO;
  latest data/index events meet 15-minute RPO.

## 13. Observability

| ID | Signal | Dimensions/alert | Priority |
|---|---|---|---|
| C05-OBS-001 | Context coverage/conflicts | application/domain/source/class/lane; critical gap alert | P0 |
| C05-OBS-002 | Dependency/index counts/freshness | type, source, index version, owner | P0 |
| C05-OBS-003 | Determinant completeness | archetype/analyzer/provenance; missing set alert | P0 |
| C05-OBS-004 | Invalidation fan-out/latency/reasons | change type/class/domain/priority | P0 |
| C05-OBS-005 | No-impact decisions | rule/policy/change type/owner; reconciliation audit | P0 |
| C05-OBS-006 | Full-scan divergence | missing/extra/modified edges/holes by archetype; non-zero alert | P0 |
| C05-OBS-007 | Index query/throttle/cost | table/index/partition/domain | P1 |

C17 exposes context/index versions, reason paths, coverage, no-impact, and
divergence without granting direct DynamoDB access.

## 14. Acceptance Criteria

| ID | Acceptance criterion |
|---|---|
| C05-AC-001 | Given a mixed application inventory, C05 publishes one immutable context containing every classified path, artifact, schema, native job, test mapping, association evidence, and source gap. |
| C05-AC-002 | Given an `application.yaml` qualifier-only change, affected injected implementation edges/holes are selected even though no source file changed. |
| C05-AC-003 | Given a shared serializer interface change, only evidenced consuming workloads/artifacts are planned; accepted lineage does not change until consumer analysis/deployment. |
| C05-AC-004 | Given CPU/tag versus topic/endpoint environment changes, the former records no impact and the latter returns exactly bound applications with reason paths. |
| C05-AC-005 | Given a contract field or lineage-relevant test change, connected workloads or stale runtime scenarios are targeted; unrelated test metadata records no impact. |
| C05-AC-006 | Given an edge determinant was deleted, prior dependents are invalidated and tombstone evidence remains until review. |
| C05-AC-007 | Given a scheduled full scan differs from incremental state, a full-scan divergence defect/alert blocks enforcement advancement and preserves the exact diff. |
| C05-AC-008 | The production-shaped load/rebuild tests meet C05 NFRs with exact inventory/context/index and determinant/result reconciliation. |

## 15. Component Test Matrix

| ID | Level | Fixture/precondition | Action | Expected result | Retained evidence |
|---|---|---|---|---|---|
| C05-CT-001 | Unit/golden | Pilot mixed application inventory | Build context | Canonical expected snapshot/checksum | Golden snapshot |
| C05-CT-002 | Precedence/conflict | Multiple association evidence tiers/tie | Resolve | Higher tier selected; tie remains conflict | Rule trace/conflict |
| C05-CT-003 | Index | Library/infra/contract/test typed records | Build/query both directions | Exact forward/reverse results/version | Index golden |
| C05-CT-004 | Determinants | File/symbol/schema/config/build/dependency inputs | Canonicalize/index | Complete stable set and reverse links | Determinant golden |
| C05-CT-005 | Config boundary | Only configuration key changes injection | Plan | All and only determined edges/holes targeted | Plan/reason paths |
| C05-CT-006 | Shared library | Exported serializer change and unrelated internal change | Plan | Consumers targeted only for relevant interface/determinants | Fan-out manifest |
| C05-CT-007 | Infrastructure | CPU/tag and topic/route/env endpoint changes | Plan | No-impact versus exact binding targets | Decisions/audit |
| C05-CT-008 | Contract/test | Schema field and scenario coverage changes | Plan | Producer/consumer targets; evidence freshness updates | Plan/freshness |
| C05-CT-009 | Delete/rename | Determinant deleted/renamed | Plan | Prior dependents targeted; tombstone/alias retained | Plan/index history |
| C05-CT-010 | Idempotency/conflict | Duplicate index manifest then competing expected version | Activate | One version; conflict forces recompute, no mix | Pointer/history |
| C05-CT-011 | Divergence | Full scan has missing/extra/modified edges | Compare | Exact non-zero defect/alert; no suppression | Diff/report |
| C05-CT-012 | Load/recovery | 10,000 repositories, central library fan-out, restart/restore | Build/query/plan/rebuild | NFRs and exact reconciliation; no Tier-1 loss | Load/recovery report |

## 16. Integration Obligations

- **INT-027 C01/C02/C04↔C05:** one pinned context resolves canonical identities,
  inventory, classifications, lanes, evidence precedence, and gaps.
- **INT-028 C05↔C06:** invalidation manifests schedule exactly planned work,
  preserve priority/fan-out, and use one index version.
- **INT-029 C05↔C08/C13:** analyzer/verified edge and hole determinants round-trip
  into reverse indexes; missing determinants prevent bounded claims.
- **INT-030 C05↔C14:** config/library/infra/contract/test changes produce correct
  CI/deployment freshness and no-impact decisions.
- **INT-031 C05↔C11:** test mapping controls expected sidecars/scenarios and
  lineage-relevant test changes mark runtime evidence stale.
- **INT-032 C05↔C17:** application context, association/conflict, reason path,
  no-impact, and divergence are visible with authorization.
- **INT-033 C05↔C18:** index reconciliation, large fan-out fairness, outage,
  restore/rebuild, audit, and divergence alert/runbooks pass.

## 17. Definition of Done

- Contracts, context builder, typed indexes, determinant schema, invalidation
  planner, full-scan comparator, and immutable/effective storage are implemented.
- C05 P0 requirements and C05-CT-001 through C05-CT-012 pass.
- INT-027 through INT-033 pass with production-shaped components.
- Config-only, shared-library, infrastructure, contract, test, monorepo, delete/
  rename, and no-impact steel-thread cases retain exact plan/result evidence.
- The enterprise build/query/load/rebuild report meets NFRs and exact
  reconciliation.
- Full-scan divergence is zero in the acceptance corpus or fails the gate with
  an owned defect; it is never accepted as a tuning tolerance.
- Security, index activation/rollback, fan-out, divergence, and restore runbooks
  are exercised; dashboards/alarms link real run IDs.

## 18. Implementation Notes

```text
contracts/schemas/context/
contracts/schemas/dependencies/
contracts/schemas/determinants/
services/context-builder/
services/dependency-index/
services/invalidation-planner/
workers/reconciliation/full-scan-divergence/
infra/lib/constructs/context-indexes.ts
tests/contract/context/
tests/integration/context-invalidation/
tests/load/context-indexes/
```

Use TypeScript 5 for context/index/control APIs and Python 3.12 for large
reconciliation/diff workers. S3 holds immutable manifests; DynamoDB holds
effective pointers/reverse indexes. Large fan-out is an S3 manifest, never a
Step Functions payload. Do not use Neptune as the determinant authority.

Build order: context schema/builder; typed dependency indexes; determinant
ingestion/reverse indexes; invalidation rules; full-scan comparison; UI/ops;
load/rebuild. Feature flags may preview new invalidation rules but no-impact
decisions require active versioned policy.

## 19. Traceability

| Source decision | C05 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| Application context separately versioned | C05-FR-001 through C05-FR-004/016 | C05-CT-001/002/010 | INT-027/032 |
| Excluded repos trigger affected apps | C05-FR-005 through C05-FR-008/013/014 | C05-CT-003/006/007/008 | INT-028/030/031 |
| Determinant-based incremental soundness | C05-FR-009 through C05-FR-012/015 | C05-CT-004/005/009/011 | INT-029/030; incremental steel thread |
| Scale, fairness, rebuild | C05-NFR-001 through C05-NFR-004 | C05-CT-012 | INT-033; enterprise/DR gates |
| Security/privacy/governance | C05-SEC-001 through C05-SEC-005 | C05-CT-007/010 | INT-032/033 |


---

# 06-orchestration-and-scheduling.md

# C06 Workflow Orchestration and Workload Scheduling PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C06 |
| Status | Approved for implementation |
| Launch phase | Foundation through enterprise |
| Criticality | P0; coordinates every long-running collection, verification, publication, and recovery flow |
| Primary owner | Lineage workflow platform team |
| Required approvers | Architecture, operations, analysis, review/publication, security |
| Upstream dependencies | C03 normalized queues, C04 decisions, C05 context/invalidation, C12 state/evidence foundations |
| Downstream dependencies | C07-C18 |
| Authoritative sources | AWS architecture §§5-6, 8-10, 14-17; shared state/error model |

## 2. Purpose and Outcomes

C06 turns durable triggers and immutable manifests into visible, resumable
workflows. Step Functions Standard coordinates; SQS buffers; Batch executes
heavy analysis; Lambda performs short control actions. C06 enforces dependency
order, idempotent stage transitions, priority fairness, quotas, timeout/cancel,
finally cleanup, and run-timeline events without becoming the content authority.

Measurable outcomes:

- Every C03 accepted work item produces one run/no-impact/deferred decision.
- Baseline, incremental, runtime, verification/review handoff, publication,
  reconciliation, and projection rebuild can resume/redrive without repeating
  valid completed work or duplicating business effects.
- Tier-1 incremental start latency remains within five minutes p95 during
  baseline/backfill and domain-skew load.
- Users can see current/completed stages, elapsed/retry/redrive/missing evidence,
  review/publication/projection status without AWS console access.

## 3. Scope and Non-Goals

### In scope

- Step Functions Standard definitions and stage contracts for all long-running
  workflows; Distributed Map for S3 manifests.
- Idempotent run creation, dependency/stage readiness, checkpoints, retry/catch,
  compensation/finally, cancellation, expiry, redrive, and child run linkage.
- Priority-aware Batch queues/job definitions/capacity reservations, per-domain
  admission, Bedrock/runtime quota coordination, and fairness.
- Stage/run status, progress, timeline events, and operational reconciliation.

### Non-goals

- Routing ingress events (C03), computing eligibility/invalidation (C04/C05),
  analyzing/reconciling content (C07-C13), or approving/publishing graph state
  (C15/C16).
- Embedding large evidence/proposals in Step Functions state.
- Using Lambda as a long-running orchestrator or repository analyzer.
- Assuming retries are safe without the called component's idempotency contract.

## 4. Actors and Use Cases

| Actor/component | Use case |
|---|---|
| C03 | Hand off priority-normalized work and receive durable consume outcome |
| Application owner | Start baseline/cancel permitted run and inspect timeline |
| C07-C13 workers | Receive pinned inputs, budget, callback/result contract |
| C15/C16 | Receive review/publication handoff and conditionally advance state |
| Operator | Redrive failed stage, pause admission, drain queue, reconcile stuck run |
| Capacity owner | Configure reserved/borrowed capacity and quotas by priority/domain |

## 5. Component Boundary

### Owned behavior

- `CollectionRun`, `StageAttempt`, workflow definitions, execution/job/session
  linkage, admission/scheduling, and timeline emission.
- Dependency/timeout/retry/redrive/finally rules and stage output validation.

### Inputs

- C03 queue message plus normalized event reference/checksum/idempotency.
- C04 eligibility/lane and C05 context/invalidation manifests.
- Workflow policy, quotas, priority/domain, and expected state versions.

### Outputs

- Child Batch/Lambda/Step Functions/C11 work, immutable stage-result references,
  run state/timeline, proposal/publication/reconciliation triggers.

### Forbidden behavior

- Starting work from an unverified/mismatched S3 checksum or mixed input version.
- Passing repository archive, evidence package, or graph manifest inline.
- Retrying deterministic invalid/verification/privacy failure as transient.
- Allowing baseline/backfill to consume Tier-1 reserved capacity.
- Marking a run complete before required evidence/review/publication semantics.
- Failing to disable runtime collection in a terminal-path finally action.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C06-FR-001 | C06 must use Step Functions Standard for baseline, incremental, runtime, verification/proposal, approval-publication, reconciliation, and projection-rebuild workflows. | P0 |
| C06-FR-002 | Run creation must conditionally bind the C03 business identity to one `CollectionRun`; duplicate deliveries must return/reuse the same run or terminal decision. | P0 |
| C06-FR-003 | Every run/stage must pin contract, policy, analyzer, inventory/context/index, commit/artifact/environment, and accepted graph versions applicable to the run. | P0 |
| C06-FR-004 | Large inputs/outputs must pass as immutable S3 URI/version/checksum; C06 must verify checksum/schema before stage start and result acceptance. | P0 |
| C06-FR-005 | The baseline workflow must execute inventory, eligibility, context/index, lane analysis/runtime as required, verification, proposal/review handoff, and approved publication; critical UNKNOWN/incomplete states must prevent false completion. | P0 |
| C06-FR-006 | The incremental workflow must load class/invalidation plan, execute only planned analysis, compare accepted baseline, create a before/after proposal, bind artifact, and publish only after approval. | P0 |
| C06-FR-007 | The runtime workflow must request a signed C11 session, wait for all expected sidecars `READY`, start named tests, drain/persist/verify, disable in a finally path, and pass only terminal completeness to C13. | P0 |
| C06-FR-008 | Verification/proposal workflow must preserve every collector result, hole/conflict/coverage outcome, and route human review without holding workflow compute open indefinitely. | P0 |
| C06-FR-009 | Publication workflow must call C16 with approved immutable manifest, expected prior graph version, and idempotency; retries/redrive must reuse reservation/result rules. | P0 |
| C06-FR-010 | Reconciliation workflows must cover inventory-to-decision/run, deployment-to-lineage, run/stage timeout, event-to-run, full-scan divergence, and projection watermark/rebuild. | P0 |
| C06-FR-011 | Lambda tasks must be bounded control actions; source checkout, full SCA, large reconciliation, verification, and projection preparation must run in AWS Batch. | P0 |
| C06-FR-012 | C06 must apply error-class-specific bounded retry/backoff/jitter, catch/quarantine, DLQ/redrive, and cleanup; deterministic invalid input must not consume repeated capacity. | P0 |
| C06-FR-013 | Stage redrive must reuse verified completed outputs when inputs/versions remain identical and re-execute only invalid/missing/failed dependent stages. | P0 |
| C06-FR-014 | Cancellation/expiry must be authorized/idempotent, stop or detach child work, clean ephemeral resources, run mandatory finally actions, and preserve completed evidence/audit. | P0 |
| C06-FR-015 | Separate scheduling pools must provide Tier-1 incremental reservation, standard incremental borrowing, baseline/backfill exclusion from Tier-1, independent LLM rate/cost limit, isolated runtime stream capacity, and per-domain admission. | P0 |
| C06-FR-016 | Step Functions Distributed Map concurrency must be explicitly below the minimum downstream Batch, Bedrock, SCM, schema, and datastore quota; configured maximum is not assumed safe. | P0 |
| C06-FR-017 | Every run/stage/attempt transition must emit the common correlation contract and a user timeline event with current state, elapsed, retry/redrive, missing evidence, and result reference. | P0 |
| C06-FR-018 | A reconciliation process must detect accepted queue work with no run, nonterminal runs without live execution/lease, orphan child jobs/sessions, and terminal workflows missing durable result. | P0 |
| C06-FR-019 | Capacity/policy/config changes must be versioned/canaried and must not mutate pinned in-flight run semantics. | P1 |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C06-NFR-001 | Tier-1 incremental work must start within five minutes p95 during representative baseline/backfill and domain-skew load. | P0 |
| C06-NFR-002 | Normal incremental analysis orchestration must finish within 30 minutes p95 excluding human review and deferred post-analysis runtime evidence. | P0 |
| C06-NFR-003 | C06 must coordinate a 10,000-repository baseline within the 12-hour platform window at validated quotas and at least 10,000 deployed-artifact decisions/day. | P0 |
| C06-NFR-004 | Run-control state must be 99.95% available monthly, Multi-AZ, and recover/redrive within C18 RPO/RTO without duplicate business effects. | P0 |

## 7. Data and Durable State

`CollectionRun` includes run ID/type/priority/domain, trigger/business identity,
application/repository/commit/artifact/environment, all pinned versions, current
state/stage, progress, required/optional stage graph, input/result references,
child execution IDs, review/proposal/graph linkage, error/owner action, and
created/updated/terminal timestamps.

`StageAttempt` includes stage/attempt identity, expected prior state, component,
input schema/reference/checksum, budget/quota, lease/heartbeat, child job/token,
start/end, error class/code, retry/redrive relation, output reference/checksum,
metrics, and cleanup status.

`SchedulingDecision` includes priority/pool/domain, requested resource shape,
quota snapshot/policy version, admission/defer reason, queue/start/end time, and
cost tags.

DynamoDB holds run/stage/idempotency/lease state with conditional transitions and
PITR. Step Functions execution history is operational evidence, not sole
authority. C12 S3 holds immutable manifests/results; EventBridge emits timeline
events; CloudWatch/ADOT/CloudTrail cover telemetry/audit.

## 8. Interfaces and Contracts

### Consume work

C06 consumers receive the C03 queue envelope, fetch/validate `EventEnvelope`,
conditionally create/reuse run, then delete SQS only after durable ownership or
terminal prior outcome. Visibility heartbeat extends only while the consumer
owns the run lease.

### Worker invocation

Every task input is:

```text
run/stage/attempt IDs
component operation and contract version
immutable input references/checksums
pinned identity/policy/analyzer/context/graph versions
resource/time/cost budget
callback/result location and correlation
```

Workers conditionally register start/heartbeat/result and write immutable
result before completion callback. A late/stale attempt cannot replace a newer
accepted stage result.

### Commands/status

- `POST /v1/runs/{id}:cancel`, `:redrive`, or `:reconcile` require expected
  version, scoped role, reason, and idempotency.
- `GET /v1/runs/{id}` and `/timeline` return read-model pages/references.
- Events: `collection.run/stage.started|progressed|completed|failed|redriven`,
  `collection.run.awaiting-review`, and terminal outcomes.

## 9. Processing and State Model

### Baseline workflow

```text
REQUESTED -> INVENTORY -> ELIGIBILITY -> CONTEXT -> ANALYSIS_FANOUT
          -> RUNTIME_OPTIONAL -> VERIFY -> PROPOSAL -> AWAITING_REVIEW
          -> PUBLISH -> PROJECTION_READY -> COMPLETE
```

Eligibility fanout produces analysis work only for eligible path units; library,
infrastructure, contract, documentation, and test units feed context/reconcile
actions. Critical unknown remains visible and blocks complete.

### Incremental workflow

```text
RECEIVED -> LOAD_CONTEXT -> INVALIDATION_PLAN -> TARGETED_ANALYSIS
         -> RUNTIME_OPTIONAL -> VERIFY_DIFF -> PROPOSAL
         -> AWAITING_REVIEW -> BIND -> PUBLISH -> COMPLETE
```

`NO_LINEAGE_IMPACT` is terminal only with C04/C05 typed decision/evidence.

### Runtime workflow

```text
REQUEST_SESSION -> ENABLING -> WAIT_READY -> START_TESTS -> COLLECT
                -> DRAIN -> DISABLE -> ACCEPT_RESULT
```

Every state enters a finally chain that requests disable/expiry confirmation.
`INCOMPLETE`/`TRUNCATED` results reach C13 but cannot promote confidence.

### Retry/redrive rule

Before reuse, C06 verifies stage input refs/checksums/versions equal the accepted
attempt and all dependent policies still permit reuse. Otherwise it creates a
new attempt and invalidates dependent results. Human review is externalized:
the run transitions to awaiting review and resumes from a decision event rather
than keeping an execution open without bound.

## 10. Failure Semantics

| Code | Class | Required behavior |
|---|---|---|
| `RUN_IDEMPOTENCY_CONFLICT` | `CONFLICT` | Preserve both checksums; no second run |
| `INPUT_REFERENCE_INVALID` | `DETERMINISTIC_INVALID` | Quarantine stage; do not invoke worker |
| `DOWNSTREAM_THROTTLED` | `TRANSIENT` | Bounded backoff/admission defer; retain priority/age |
| `WORKER_HEARTBEAT_LOST` | `TRANSIENT`/`POISON_REPEATED` | Verify child/lease, cancel/orphan-reconcile, retry policy |
| `REQUIRED_STAGE_INCOMPLETE` | `INCOMPLETE` | Surface gap; block false complete/promotion |
| `STALE_STAGE_RESULT` | `CONFLICT` | Reject late callback; retain attempt evidence |
| `RUNTIME_DISABLE_UNCONFIRMED` | `INCOMPLETE` security-critical | Retry/expire/alert; no complete result |
| `REVIEW_VERSION_CONFLICT` | `CONFLICT` | Wait for current proposal/decision; no blind resume |
| `PUBLICATION_VERSION_CONFLICT` | `CONFLICT` | Rebase/supersede through C15/C16; active pointer unchanged |
| `ORPHAN_WORK_DETECTED` | `INCOMPLETE` operational | Reconcile/cancel/adopt under runbook and audit |

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C06-SEC-001 | Each workflow/task must use a component/operation-specific role limited to exact queue, state, S3 prefixes, KMS keys, job definitions, and callback actions; no wildcard data-plane role. | P0 |
| C06-SEC-002 | Workflow state/logs/events must contain metadata and immutable references only; repository contents, runtime payloads, credentials, and Bedrock prompts/results remain in restricted stores. | P0 |
| C06-SEC-003 | Cancel/redrive/replay/admission override/config activation must require scoped authorization, reason, expected version, and CloudTrail/audit. | P0 |
| C06-SEC-004 | Batch workspaces must be ephemeral/encrypted, use short-lived source credentials/controlled egress, and prove cleanup at terminal/cancel. | P0 |
| C06-SEC-005 | Runtime production hard-deny and finally disable/expiry must be encoded as independent policy/control tasks that analysis/test success cannot bypass. | P0 |

## 12. Scale, Performance, and Availability

Capacity formula:

```text
requiredConcurrency = repositoryCount * meanJobMinutes
                      / (targetWindowMinutes * utilization)
```

For 10,000 repositories, 15-minute mean, 12 hours, 70% utilization, plan about
298 slots and initially quota/load-test 500. Incremental demand reserves
separate priority capacity. Resource shapes/timeout vary by measured archetype
and repository size; one domain cannot consume all slots.

Distributed Map input/output is an S3 manifest. MaxConcurrency is calculated
from validated downstream quotas and safety margin. Admission controllers expose
queue age and borrow/reserve decisions. Workflows use Standard durability/redrive
and Multi-AZ managed services; warm-Region IaC/state/evidence supports RPO/RTO.

## 13. Observability

| ID | Signal | Dimensions/alert | Priority |
|---|---|---|---|
| C06-OBS-001 | Run/stage count/latency/status | type/stage/priority/domain/archetype/version | P0 |
| C06-OBS-002 | Queue-to-start and admission defer | pool/priority/domain; Tier-1 SLO alert | P0 |
| C06-OBS-003 | Retry/redrive/orphan/heartbeat | component/error/attempt/runbook | P0 |
| C06-OBS-004 | Concurrency/quota/utilization | Batch shape, Map, Bedrock, source/datastore | P0 |
| C06-OBS-005 | Incomplete/missing evidence/UNKNOWN | application/repository/stage/owner | P0 |
| C06-OBS-006 | Runtime cleanup | session state, disable/expiry confirmation; security alert | P0 |
| C06-OBS-007 | Cost | run/stage/application/domain/lane/cache hit | P1 |

Every transition includes the common correlation contract. Metrics reconcile C03
accepted work to run/no-impact/deferred/quarantine and run stages to immutable
results. C17 timeline uses a purpose-built read model rather than Step Functions
console access.

## 14. Acceptance Criteria

| ID | Acceptance criterion |
|---|---|
| C06-AC-001 | Given a mixed business application, the baseline workflow routes every class/path correctly and reaches review/publish only after required context/evidence/verification. |
| C06-AC-002 | Given a determinant-bounded change, the incremental workflow invokes only planned workloads and produces a complete before/after proposal relative to the pinned baseline. |
| C06-AC-003 | Given duplicate/out-of-order queue delivery, one run/business effect occurs and all delivery/attempt history remains visible. |
| C06-AC-004 | Given failure after completed expensive stages, redrive reuses matching checksummed outputs and reruns only failed/invalid dependents. |
| C06-AC-005 | Given runtime test failure, sidecar crash, timeout, or cancel, the finally path disables/expires collection and passes exact completeness without promotion. |
| C06-AC-006 | Given baseline/backfill plus 10,000 deployment work, Tier-1 starts within five minutes p95 and lower priority cannot consume reservation. |
| C06-AC-007 | Given stale callback/lease or expected graph conflict, C06 rejects the stale side effect and routes governed recompute/rebase without changing active state. |
| C06-AC-008 | Given Region/process failure, reconciliation finds orphan/missing state and recovery/redrive meets RPO/RTO without duplicate proposal/publication. |

## 15. Component Test Matrix

| ID | Level | Fixture/precondition | Action | Expected result | Retained evidence |
|---|---|---|---|---|---|
| C06-CT-001 | State-machine assertion | Baseline/incremental/runtime/publish definitions | Synthesize/inspect | Required states/catches/finally/refs and no unsafe Lambda analysis | CDK/ASL assertion |
| C06-CT-002 | Baseline integration harness | Mixed app manifest incl UNKNOWN | Execute | Correct fanout; UNKNOWN prevents false complete; outputs pinned | Execution/result manifest |
| C06-CT-003 | Incremental | Config/library/infra/docs/contract/test plans | Execute | Exactly planned jobs/no-impact/review paths | Job/run comparison |
| C06-CT-004 | Idempotency/order | Duplicate/out-of-order SQS events | Consume concurrently | One run/effect; attempts/events preserved | State/event counts |
| C06-CT-005 | Retry classification | Transient versus deterministic worker failures | Execute | Only transient bounded retry; invalid quarantined | History/metrics |
| C06-CT-006 | Redrive | Fail after two expensive completed stages | Redrive | Reuse exact outputs; rerun failed/dependents only | Attempt/output refs |
| C06-CT-007 | Runtime cleanup | Test failure, sidecar crash, cancel, expiry | Execute | Finally disable/expiry confirmed; incomplete no-promotion | Session/workflow/audit |
| C06-CT-008 | Stale result | Worker loses lease then returns | Callback | Result rejected; newer attempt remains authoritative | Conditional state/audit |
| C06-CT-009 | Security | Oversized inline/sensitive state and unauthorized redrive | Invoke | Reject/deny; no sensitive history; audit | ASL/log scan/audit |
| C06-CT-010 | Fairness/load | 10,000 baseline/deploy events, domain skew, constrained slots | Schedule | Reservation/borrowing/per-domain and SLOs pass | Load/scheduling report |
| C06-CT-011 | Reconciliation | Missing run, stuck state, orphan Batch/session, missing result | Reconcile | Exact findings and safe cancel/adopt/redrive action | Reconciliation report |
| C06-CT-012 | DR | Region interruption with in-flight stages | Recover warm Region/redrive | RPO/RTO and no duplicate effects; pinned refs intact | Recovery exercise |

## 16. Integration Obligations

- **INT-034 C03↔C06:** every accepted route maps to one run/no-impact/deferred
  outcome under duplicate/out-of-order/load/replay.
- **INT-035 C04/C05↔C06:** classes, lanes, context, and invalidation manifests
  produce exact scheduled work with pinned versions.
- **INT-036 C06↔C07-C10:** Batch/native/agent/opaque analysis inputs, budgets,
  callbacks, checksum validation, retry, and cache reuse interoperate.
- **INT-037 C06↔C11:** session readiness/test/drain/disable finally/completeness
  flows pass every terminal/failure case.
- **INT-038 C06↔C12/C13:** immutable stage artifacts feed verification once;
  incomplete/conflict/stale attempts cannot promote or overwrite.
- **INT-039 C06↔C15/C16:** review externalization/resume and fenced publication
  handle correction, rejection, stale decision, redrive, and version conflict.
- **INT-040 C06↔C17:** user timeline is complete/correlated and supports bounded
  cancel/redrive authorization without console access.
- **INT-041 C06↔C18:** quotas/fairness, alarms/runbooks, orphan reconciliation,
  chaos, cost, and cross-Region recovery pass.

## 17. Definition of Done

- IaC and versioned ASL/task contracts implement every required workflow, queue/
  compute pool, run/stage state, admission rule, and reconciliation process.
- C06 P0 requirements and C06-CT-001 through C06-CT-012 pass.
- INT-034 through INT-041 pass in a production-like nonproduction environment.
- Baseline/incremental/runtime/review/publication/reconciliation steel threads
  retain execution/result IDs and prove required negative/finally paths.
- Enterprise load proves 12-hour baseline capacity, daily decisions, Tier-1
  latency/fairness, exact event/run/result reconciliation, and quota headroom.
- Security/privacy, cancellation, redrive, orphan, quota, and DR runbooks are
  exercised; dashboards/alarms link real evidence.

## 18. Implementation Notes

```text
contracts/schemas/runs/
infra/lib/stacks/workflow-stack.ts
infra/lib/constructs/lineage-workflows.ts
infra/lib/constructs/batch-capacity.ts
services/run-controller/
services/run-timeline/
tests/contract/workflows/
tests/integration/workflows/
tests/load/scheduling/
tests/chaos/workflows/
```

Use TypeScript 5/CDK v2 for control services/IaC. Step Functions Standard owns
coordination, Distributed Map reads S3 manifests, Lambda performs bounded
control tasks, Batch performs heavy jobs. Use callback tokens only with strict
attempt/lease/state validation and timeout. Do not implement a custom scheduler
inside Lambda.

Build order: run/stage contracts/idempotency; compute/priority pools; baseline;
incremental; runtime finally; verify/review/publish; reconciliation/timeline;
load/chaos/DR. Canary new workflow versions for new runs; in-flight runs remain
pinned to their definition/policy.

## 19. Traceability

| Source decision | C06 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| Step Functions coordinates, Batch analyzes, Lambda controls | C06-FR-001/004/011/016 | C06-CT-001/009 | INT-036/038 |
| Baseline/incremental/runtime/review/publish flows | C06-FR-005 through C06-FR-010 | C06-CT-002/003/007 | INT-035/037/039 |
| Idempotency/retry/redrive/reconcile | C06-FR-002/003/012-014/018 | C06-CT-004/005/006/008/011 | INT-034/038/041 |
| Priority fairness/enterprise scale | C06-FR-015/016; C06-NFR-001-003 | C06-CT-010 | Enterprise load/fairness gate |
| Security/finally/DR/visibility | C06-SEC-001 through C06-SEC-005; C06-FR-017 | C06-CT-007/009/012 | INT-037/040/041 |


---

# 07-lane-b-native-collectors.md

# C07 Lane B Native Lineage Collectors PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C07 |
| Status | Approved for implementation |
| Launch phase | First collection lane; pilot weeks 0-6 |
| Criticality | P0; provides exact executed column lineage and the derivational oracle used to calibrate other lanes |
| Primary owner | Native lineage integrations team |
| Required approvers | Spark platform, dbt/warehouse, Airflow, contracts/identity, trust engine |
| Upstream dependencies | C01 identity/contracts, C02 native inventory, C04 Lane B routing, C05 context, C06 scheduling, engine/catalog APIs |
| Downstream dependencies | C12-C15, C17-C18 |
| Authoritative sources | Element-level v2 R2/R5/R6; AWS architecture §§8, 11, 13-14 |

## 2. Purpose and Outcomes

C07 captures column lineage from engines that already compute it to execute or
compile a plan. It configures Spark OpenLineage listeners, parses dbt manifest
and catalog artifacts, and attributes Airflow-orchestrated SQL/native runs. It
emits exact per-run, artifact-bound mappings where the engine is authoritative
and explicit unresolved records where it is not.

Measurable outcomes:

- 100% of governed pilot Spark/dbt/Airflow Lane B jobs emit a terminal
  `NativeLineageRun` or a visible missing/incomplete alert; no silent job gap.
- Resolved native columns are bound to canonical URNs, engine run, environment,
  and immutable artifact digest.
- `select *` expansion uses the exact catalog snapshot for the run/compile; zero
  guessed columns and zero raw-Jinja lineage parsing.
- Facet/resolution coverage is measured on the real estate before confidence or
  rollout gates assume oracle coverage; unresolved reason counts are published.

## 3. Scope and Non-Goals

### In scope

- Spark listener/transport setup and OpenLineage column-lineage facet ingestion.
- dbt `manifest.json`, `catalog.json`, compiled SQL/run-result association, and
  catalog-based wildcard expansion.
- Airflow DAG/task/run attribution to the native SQL/Spark/dbt execution and
  artifact/environment.
- Native event validation, canonical identity, deduplication, completeness,
  unresolved reason codes, and immutable `NativeLineageRun` packages.
- Version/facet compatibility and estate coverage telemetry.

### Non-goals

- Static/agentic inference for custom application code (C08/C09).
- Guessing lineage inside opaque UDFs, dynamic SQL, foreign sources, or missing
  facets.
- Applying the Lane A PR CI drift workflow; Lane B's authoritative moment is
  engine execution/compile-run association.
- Claiming native execution covers unexecuted paths or all possible future runs.
- Promoting other-lane derivation merely because the native consumer received a
  field; C13 applies the required structural/derivational asymmetry.

## 4. Actors and Use Cases

| Actor/component | Use case |
|---|---|
| Spark platform owner | Enable cluster-level OpenLineage listener without producer code change |
| dbt platform/team | Publish manifest/catalog/run results on compile/run |
| Airflow owner | Bind DAG/task/run to Spark/dbt/SQL engine execution |
| C13 trust engine | Treat exact native plan mapping as derivational oracle for that native edge |
| Application owner | See native mappings, run/digest, coverage, and unresolved reasons |
| Operator | Detect missing listener/facet/catalog/run association and replay ingestion |

## 5. Component Boundary

### Owned behavior

- Engine-native configuration adapters, event/artifact validation, and native
  mapping extraction.
- `NativeLineageRun` assembly/completeness and unresolved record emission.

### Inputs

- C04 Lane B assignment and C05 job/context/schema references.
- Spark OpenLineage events/facets and engine run metadata.
- dbt manifest/catalog/compiled artifacts/run results.
- Airflow DAG/task/run and downstream native job identifiers.
- C01 registry version and canonical schema/catalog identities.

### Outputs

- Immutable `NativeLineageRun`, native edge candidates, unresolved entries,
  coverage/completeness and evidence references.

### Forbidden behavior

- Parsing raw Jinja as executed dbt SQL.
- Expanding wildcard fields without a pinned matching catalog/schema snapshot.
- Omitting an unresolved column/site/job without a reason.
- Accepting a mutable tag/branch/job name as artifact digest.
- Marking a custom-code producing edge derivationally verified based only on the
  downstream native job seeing its output.
- Sampling away governed native run events without a visible incomplete state.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C07-FR-001 | C07 must enable the approved Spark OpenLineage listener/column-lineage facet at cluster policy/configuration level for governed jobs without producer code change. | P0 |
| C07-FR-002 | C07 must validate and ingest Spark job/run identity, parent/application context, inputs/outputs, column facet, engine/listener version, environment, and artifact digest. | P0 |
| C07-FR-003 | C07 must parse dbt manifest and catalog on every governed compile/run, associate compiled SQL/run results, and never derive mappings from raw Jinja templates. | P0 |
| C07-FR-004 | dbt `select *` and wildcard expansion must use the exact warehouse catalog/schema snapshot bound to the manifest/run; missing/mismatched catalog must produce unresolved output. | P0 |
| C07-FR-005 | Airflow-orchestrated SQL/Spark/dbt lineage must be attributed to DAG ID/version, task/run, downstream native execution, application, environment, and artifact digest without treating orchestration dependencies as column mappings. | P0 |
| C07-FR-006 | Every native run must emit exact resolved column mappings where the engine provides them and typed `unresolved: true` entries with affected inputs/outputs and reason where it does not. | P0 |
| C07-FR-007 | Required unresolved reasons must include opaque UDF, dynamic/uncompiled SQL, foreign/unsupported source, missing/malformed facet, missing/mismatched catalog, unresolved identity, unsupported facet/engine version, and incomplete run. | P0 |
| C07-FR-008 | Native outputs must be bound to immutable run and artifact digest; missing digest must quarantine or mark incomplete and must not enter accepted candidate state. | P0 |
| C07-FR-009 | C07 must resolve datasets/fields through C01 against one pinned registry version while preserving native names and unknown/ambiguous outcomes. | P0 |
| C07-FR-010 | `NativeLineageRun` must be immutable, content-checksummed, idempotent by engine/job/run/artifact/environment/collector version, and complete for every declared input/output facet. | P0 |
| C07-FR-011 | Duplicate events/artifacts with identical content must return the same package; conflicting content for one native run identity must enter conflict and never overwrite. | P0 |
| C07-FR-012 | Exact native plan mappings are eligible as the derivational oracle for those native edges; C07 must emit provenance/capability, not directly assign final confidence. | P0 |
| C07-FR-013 | Native evidence crossing from a Lane B consumer to a Lane A producer may corroborate field arrival/execution structurally but must not claim how the producer derived the field. | P0 |
| C07-FR-014 | C07 must report job/run/facet/column resolution and unresolved coverage by engine/version/archetype/application/domain before rollout or confidence calibration decisions. | P0 |
| C07-FR-015 | A scheduled reconciliation must compare C02 expected Lane B jobs/runs with received terminal packages and alert missing/stale listener/manifest/catalog evidence. | P0 |
| C07-FR-016 | Engine/facet/parser version support must be a typed compatibility matrix with reject/quarantine behavior for unknown breaking versions. | P0 |
| C07-FR-017 | Lane B output must bypass Lane A PR drift generation and update lineage per authoritative run/compile semantics. | P0 |
| C07-FR-018 | Additional native engines may be added only through the common conformance kit and an approved exactness/capability statement. | P1 |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C07-NFR-001 | 95% of valid native run events/artifact notifications must produce a persisted package within 60 seconds; 99% within five minutes under planned load. | P0 |
| C07-NFR-002 | C07 must process at least 1,000 native run events/second burst and 10 million column mappings/day per Region without silent sampling or loss. | P0 |
| C07-NFR-003 | Reprocessing identical native evidence with the same collector/parser/C01 versions must produce byte-identical packages/checksums. | P0 |
| C07-NFR-004 | Native intake/persistence must be 99.9% available monthly and recover/reconcile within C18 RPO/RTO. | P0 |

## 7. Data and Durable State

`NativeLineageRun` contains:

- package/job/run/parent IDs, engine (`SPARK`, `DBT`, `AIRFLOW_SQL`), engine and
  collector/parser/facet versions.
- application/repository/commit/artifact digest/environment and C01/context
  versions.
- start/end/status, source event/artifact/checksum references.
- canonical/native input/output datasets/fields.
- exact mapping/transform expression/type where authoritative.
- path/operation/task/plan node identifiers and schema/catalog snapshot.
- each unresolved scope/reason/evidence.
- declared versus received facet/object/column counts, package completeness,
  coverage dimensions, provenance capability (`EXACT_NATIVE_PLAN`,
  `NATIVE_EXECUTION_ONLY`, `UNRESOLVED`).
- canonical checksum and immutable C12 reference.

Operational DynamoDB indexes track expected run, ingestion idempotency,
completion, reconciliation, and package pointer. S3 holds OpenLineage/dbt/Airflow
evidence and immutable packages. Raw engine payload fields outside the contract
are rejected or stored only in restricted quarantine under security policy.

## 8. Interfaces and Contracts

### Spark

Spark OpenLineage event enters an authenticated EventBridge/API path and is
referenced from C03/C06. Required supported facets include job/run, inputs,
outputs, schema, column lineage, parent/run context, and governed artifact
digest extension. Listener configuration exposes endpoint, namespace mapping,
retry/spool limits, version, and fail-open job behavior.

### dbt

`POST /v1/native/dbt-runs` accepts checksummed S3 references to manifest,
catalog, compiled artifacts, and run results plus repository/commit/artifact,
environment, invocation ID, and adapter version. It rejects raw-template-only
input for mapping generation.

### Airflow

`airflow.task.native-run-linked` supplies DAG/version/task/run, application,
repository/digest/environment, operator type, and exact downstream Spark/dbt/SQL
run/artifact references. Task ordering alone is not a lineage candidate.

### Output

`native.lineage.package.created|incomplete|conflicted` carries package reference,
checksum, counts, context/artifact identity, and correlation for C12/C13/C18.

## 9. Processing and State Model

```text
EXPECTED/RECEIVED -> VALIDATING -> RESOLVING_IDENTITY -> EXTRACTING
                  -> COMPLETENESS_CHECK -> PACKAGE_WRITING -> COMPLETE
```

Alternative: `INCOMPLETE`, `UNRESOLVED`, `CONFLICT`, `QUARANTINED`, `FAILED`.

Processing:

1. Pin collector/parser/C01/context compatibility and verify input checksum,
   source, engine run, environment, and artifact digest.
2. Deduplicate by native run identity plus content checksum.
3. Extract native plan mappings only from approved facets/compiled artifacts.
4. Resolve exact catalog snapshot and expand wildcards; if unavailable, emit
   unresolved for the affected scope.
5. Canonicalize dataset/field URNs; preserve identity gaps.
6. Validate input/output/mapping counts, unresolved coverage, run terminality,
   and checksums.
7. Write/read-back immutable package, conditionally set completion pointer, emit
   status event, and reconcile expected job/run.

## 10. Failure Semantics

| Code | Class | Required behavior |
|---|---|---|
| `NATIVE_EVENT_SCHEMA_INVALID` | `DETERMINISTIC_INVALID` | Quarantine source/version; no package success |
| `ARTIFACT_DIGEST_MISSING_OR_MISMATCHED` | `INCOMPLETE`/`CONFLICT` | No accepted candidate; resolve binding/recollect |
| `COLUMN_FACET_MISSING` | `INCOMPLETE` | Explicit unresolved/coverage; alert governed job |
| `OPAQUE_UDF` | `INCOMPLETE` semantic | Preserve surrounding exact mappings and named unresolved scope |
| `CATALOG_MISSING_OR_MISMATCHED` | `INCOMPLETE`/`CONFLICT` | Do not expand/guess wildcard; request matching catalog |
| `IDENTITY_AMBIGUOUS` | `CONFLICT` | Preserve native ID/candidates; no forced canonical edge |
| `NATIVE_RUN_CONTENT_CONFLICT` | `CONFLICT` | Preserve both checksums/evidence; review/reconcile |
| `UNSUPPORTED_ENGINE_FACET_VERSION` | `DETERMINISTIC_INVALID` | Quarantine and compatibility alert; no permissive parse |
| `STORE_OR_DEPENDENCY_THROTTLED` | `TRANSIENT` | Bounded retry/idempotent resume |

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C07-SEC-001 | Engine/listener/dbt/Airflow producers must authenticate to exact application/account/environment namespaces and use least-privilege write-only evidence paths. | P0 |
| C07-SEC-002 | Native contracts must allow metadata, schema, field, plan, and transform expressions but must reject raw row values, SQL parameters, credentials, query result payloads, and arbitrary attributes. | P0 |
| C07-SEC-003 | S3/indexes must use TLS, KMS/private access, immutable versioning/retention, domain ABAC, and audited reads/writes. | P0 |
| C07-SEC-004 | Listener/cluster policy and parser compatibility changes must be signed/versioned, canaried, approved, and audited. | P0 |
| C07-SEC-005 | Error/log content must be allowlisted and redact SQL literals/parameters and payload-bearing engine exceptions. | P0 |

## 12. Scale, Performance, and Availability

- Size by native runs and field mappings, not repository count alone. Initial
  load gate covers 1,000 events/second burst and 10 million mappings/day.
- Use Kinesis/EventBridge/SQS as appropriate for intake rate, S3 for native
  artifacts, and horizontally scalable Batch/Lambda parsers; per-run ordering is
  reconstructed by immutable run ID/sequence, not global FIFO.
- Native event transport must not fail the application/job. Local bounded spool
  and asynchronous retry are allowed; overflow creates visible incomplete/loss
  telemetry, never silent sampling.
- Parser/cache keys include source checksums, engine/facet/parser/C01/context
  versions. Same artifacts reuse packages across application context only when
  environment/identity semantics match.
- Reconciliation/restore rebuild operational indexes from C12 packages under
  C18 RPO/RTO.

## 13. Observability

| ID | Signal | Dimensions/alert | Priority |
|---|---|---|---|
| C07-OBS-001 | Expected versus received terminal runs | engine/application/domain/cluster/job; missing/stale alert | P0 |
| C07-OBS-002 | Facet and column resolution coverage | engine/facet/parser/version/archetype/reason | P0 |
| C07-OBS-003 | Ingest/package latency/throughput | engine/Region/status | P0 |
| C07-OBS-004 | Unresolved/conflict/digest/catalog/identity gaps | reason/application/owner | P0 |
| C07-OBS-005 | Listener/spool/drop/retry health | cluster/version/account; any governed loss alert | P0 |
| C07-OBS-006 | Oracle overlap/correction | native provenance versus reviewed accepted result | P0 |
| C07-OBS-007 | Cost/cache | mappings/jobs/bytes/parser/cache by engine/domain | P1 |

Coverage is reported as measured distribution. The platform does not assume the
Spark column facet resolves 60% or any threshold until actual pilot results
exist; rollout gates use the measured report.

## 14. Acceptance Criteria

| ID | Acceptance criterion |
|---|---|
| C07-AC-001 | Given a Spark SQL run with exact column facet/digest, C07 emits canonical exact mappings, run/evidence/coverage, and an oracle-capable provenance package without producer code change. |
| C07-AC-002 | Given a Spark opaque UDF or missing facet, resolved surrounding mappings remain and affected scope is explicit unresolved with reason/count; nothing is guessed/omitted. |
| C07-AC-003 | Given dbt manifest/catalog/compiled SQL with `select *`, C07 expands fields from the matching catalog; missing/mismatched catalog yields unresolved and no raw-Jinja parse. |
| C07-AC-004 | Given an Airflow task linked to a native run, C07 attributes run context but creates column mappings only from the linked engine plan, not DAG ordering. |
| C07-AC-005 | Given duplicate and conflicting native events, one identical package is reused or conflict preserves both; no overwrite/duplicate candidate occurs. |
| C07-AC-006 | Given a native consumer receives a Lane A-produced field, C07 emits its exact native consumer mapping; C13 integration promotes structural corroboration only for the producer boundary. |
| C07-AC-007 | Given expected job with missing/stale listener/catalog package, reconciliation creates an owned gap/alert and baseline/run cannot claim complete native coverage. |
| C07-AC-008 | Load and recovery meet C07 NFRs with exact expected/received/package/mapping counts and no silent sample/drop. |

## 15. Component Test Matrix

| ID | Level | Fixture/precondition | Action | Expected result | Retained evidence |
|---|---|---|---|---|---|
| C07-CT-001 | Spark golden | Exact projection/join/alias/aggregate column facets | Ingest | Expected canonical mappings/transforms/checksum | OpenLineage/package goldens |
| C07-CT-002 | Spark unresolved | Opaque UDF, foreign source, missing/malformed facet | Ingest | Typed unresolved/counts; surrounding exact facts retained | Package/coverage |
| C07-CT-003 | dbt golden | Manifest/catalog/compiled/run with models/tests/sources | Parse | Expected exact mappings and run binding | Artifact/package goldens |
| C07-CT-004 | dbt wildcard | `select *` with matching, missing, mismatched catalog | Parse | Exact expansion or unresolved; no guessed/Jinja result | Mapping/unresolved diff |
| C07-CT-005 | Airflow boundary | DAG tasks linked/unlinked to native executions | Attribute | Only linked native plan yields column mapping | Task/run package |
| C07-CT-006 | Digest/environment | Correct, missing, mismatched digest and two environments | Ingest | Correct isolation; invalid/incomplete/conflict outcomes | Identity/package evidence |
| C07-CT-007 | Identity | Cross-lane aliases resolved/unknown/ambiguous | Resolve/package | Canonical mapping or explicit gap; no forced ID | C01/result package |
| C07-CT-008 | Idempotency/conflict | Duplicate identical then conflicting run payload | Ingest concurrently | One package or conflict, no overwrite | Index/evidence history |
| C07-CT-009 | Compatibility/security | Unknown facet version plus values/parameters/arbitrary attrs | Validate | Quarantine/reject/redact; no package leak | Validation/privacy scan |
| C07-CT-010 | Reconciliation | Expected jobs/runs with missing/stale/complete evidence | Reconcile | Exact gap/status/owner alerts | Reconciliation report |
| C07-CT-011 | Oracle semantics | Native edge and upstream Lane A producer overlap | Send to trust fixture | Native edge oracle; upstream structural-only corroboration | C13 result golden |
| C07-CT-012 | Load/recovery | 1,000 events/sec, 10M mappings/day, duplicates, worker/Region restart | Execute/rebuild | NFRs, exact counts, no silent loss, index rebuild | Load/recovery report |

## 16. Integration Obligations

- **INT-042 C01/C04/C05↔C07:** Lane B job/context/aliases resolve to one pinned
  environment/artifact identity and wrong lane is rejected.
- **INT-043 C06↔C07:** native expected/ingestion/parse/retry/reconcile workflow
  handles S3 references/checksums and terminal completeness.
- **INT-044 Spark/dbt/Airflow↔C07:** configuration, facets/artifacts, exactness,
  unresolved, compatibility, failure, and no-producer-code behavior pass.
- **INT-045 C07↔C12:** immutable packages, duplicate/conflict/cache and recovery
  preserve checksums/authority.
- **INT-046 C07↔C13:** exact native mappings are derivational oracle; execution
  overlap to other lanes obeys structural-only asymmetry and incomplete no-
  promotion.
- **INT-047 C07↔C15/C17:** users see run/digest, exact/unresolved mappings,
  evidence, coverage, conflicts, and corrections; labels feed measured accuracy.
- **INT-048 C07↔C18:** missing listener/facet, privacy denial, load, reconciliation,
  replay/rebuild, audit, and Region recovery gates pass.

## 17. Definition of Done

- Spark cluster listener policy, dbt artifact integration, Airflow attribution,
  schemas/parsers/compatibility matrix, package/completeness/reconciliation, and
  immutable storage are implemented for the pilot.
- C07 P0 requirements and C07-CT-001 through C07-CT-012 pass.
- INT-042 through INT-048 pass with production-shaped engine/platform versions.
- Pilot coverage report measures facet/column resolution/unresolved by actual
  engine/version/archetype and is reviewed before oracle-dependent rollout.
- Load/recovery proves C07 NFRs, exact expected/received/package counts, no
  silent sampling, and rebuild.
- Security/privacy proves metadata-only contracts, namespace auth, encrypted
  immutable storage, signed config, redacted SQL/errors, and audit.
- Missing-native-evidence, listener rollback, parser compatibility, replay,
  reconciliation, and restore runbooks are exercised with real IDs.

## 18. Implementation Notes

```text
contracts/schemas/native-lineage/
services/native-ingest/
workers/native/spark-openlineage/
workers/native/dbt/
workers/native/airflow-attribution/
infra/lib/constructs/native-lineage-intake.ts
docs/runbooks/native-lineage/
tests/fixtures/native/{spark,dbt,airflow}/
tests/contract/native-lineage/
tests/integration/native-lineage/
tests/load/native-lineage/
```

Use Python 3.12 parsers/workers, TypeScript 5 control/IaC, and the official
OpenLineage model/schema where applicable with governed typed facets. Do not
fork a divergent lineage event format. Spark setup is cluster-level listener
configuration; dbt works from immutable generated artifacts; Airflow links to
engine-native execution.

Build order: contracts/golden fixtures; Spark listener/ingest; dbt parser and
catalog wildcard; Airflow attribution; completeness/reconciliation; C13
semantics; load/security/recovery. Roll out per engine version/cluster/domain
with measured coverage and rollback to prior listener/parser.

## 19. Traceability

| Source decision | C07 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| Lane B first and engine-native exact | C07-FR-001 through C07-FR-006 | C07-CT-001 through C07-CT-005 | INT-043/044; Lane B pilot gate |
| Artifact-bound and no silent unresolved | C07-FR-007 through C07-FR-011/014/015 | C07-CT-002/004/006/008/010 | INT-045/047/048 |
| Native derivational oracle/asymmetry | C07-FR-012/013/017 | C07-CT-011 | INT-046; confidence gate |
| Compatibility/scale/recovery | C07-FR-016; C07-NFR-001 through C07-NFR-004 | C07-CT-009/012 | INT-044/048; enterprise gate |
| Security/privacy | C07-SEC-001 through C07-SEC-005 | C07-CT-009/012 | INT-044/048 |


---

# 08-lane-a-deterministic-analyzers.md

# C08 Lane A Deterministic Analyzers PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C08 |
| Status | Approved for implementation |
| Launch phase | Pilot weeks 4-14 after C07/corpus instrumentation begins |
| Criticality | P0; establishes the provable lineage floor and the complete set of named residual holes |
| Primary owner | Static analysis and analyzer framework team |
| Required approvers | Architecture, language/framework owners, security, trust-engine owner |
| Upstream dependencies | C01 identity/contracts, C04 Lane A route, C05 context/indexes, C06 Batch orchestration, C12 evidence |
| Downstream dependencies | C09, C13-C15, C17-C18 |
| Authoritative sources | Element-level v2 R3/R5/R9; AWS architecture §§8-9, 13-16 |

## 2. Purpose and Outcomes

C08 analyzes readable custom code without a model. It emits only provable edges,
records the exact `DeterminantSet` for every edge and residual, and converts
every unprovable lineage-relevant site into a typed `Hole`. The same immutable
input/version must produce a byte-identical package.

Measurable outcomes:

- 100% of lineage-relevant sink sites in supported fixtures are represented by
  provable edges or named holes; none is silently skipped.
- `holes_opened`, `holes_closed`, unsupported constructs, and coverage are
  attributable by archetype/analyzer/version and reconcile to package content.
- Repeating analysis of one commit/artifact/context/version yields a byte-
  identical `DeterministicAnalysisPackage` and checksum.
- Every edge/hole includes complete determinants sufficient for configuration,
  schema, dependency, build, and source changes to invalidate it.

## 3. Scope and Non-Goals

### In scope

- Analyzer framework and plugin capability/compatibility contract.
- Initial Spring Boot with Kafka serde and FastAPI with Pydantic analyzers;
  Dask follows measured archetype priority.
- Source/schema/build fact extraction, symbol/call/data-flow graph, boundary
  source/sink recognition, deterministic transformations, evidence spans,
  determinants, holes, coverage, and stable package serialization.
- Sandboxed immutable checkout/artifact preparation and content-addressed cache.

### Non-goals

- Resolving uncertain/dynamic sites probabilistically (C09).
- Treating heuristics as provable because they are usually correct.
- Proving executed/live paths (C07/C11/C13).
- Reading or storing production payload values.
- Supporting every language/framework at launch or hiding unsupported code.

## 4. Actors and Use Cases

| Actor/component | Use case |
|---|---|
| Analyzer developer | Implement one archetype plugin against conformance/golden tests |
| C06 | Run isolated Batch analysis with pinned resources/versions |
| C09 | Receive bounded holes and approved analysis tools/facts |
| C13 | Verify provable edges/evidence/reachability and merge resolutions |
| Application owner | Inspect deterministic evidence, holes, unsupported constructs, and coverage |
| Operator | Diagnose parser crash/resource limit/determinism regression and replay cached work |

## 5. Component Boundary

### Owned behavior

- Analyzer SPI, supported construct/capability declaration, parsing/semantic fact
  graph, provable-edge rule, hole inventory, determinants, stable package.

### Inputs

- Immutable repository source snapshot or built source artifact reference and
  checksum, repository/commit/artifact/environment.
- C05 context, schemas/contracts/dependencies/config manifests, C01 registry.
- Analyzer/policy/toolchain version and resource budget.

### Outputs

- `DeterministicAnalysisPackage`, `LineageEdgeCandidate` with deterministic
  provenance, `Hole`, `DeterminantSet`, analyzer facts/tool indexes, coverage.

### Forbidden behavior

- Emitting an edge without a mechanically traceable source-to-sink proof and
  evidence span/fact references.
- Dropping an unresolved site, unsupported construct, parse error, or resource-
  limited file from coverage.
- Calling a model/LLM or unapproved network service.
- Treating unresolved dependency/configuration as a default implementation.
- Producing timestamps/random IDs/noncanonical iteration in package content.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C08-FR-001 | C08 must analyze an immutable repository commit/source snapshot and bind every package to repository, commit, artifact digest/environment where available, context, C01, analyzer, policy, and toolchain versions. | P0 |
| C08-FR-002 | The analyzer framework must require each plugin to declare languages/frameworks/versions, supported sources/sinks/transforms/configuration, unsupported constructs, required build facts, and resource profile. | P0 |
| C08-FR-003 | Initial P0 plugins must cover Spring Boot with Kafka serializers/deserializers and FastAPI with Pydantic request/response/event models; unsupported versions/features must remain explicit. | P0 |
| C08-FR-004 | C08 must emit only provable edges backed by normalized source/sink symbols, a deterministic data-flow/reachability proof, and file:line evidence spans/fact IDs. | P0 |
| C08-FR-005 | Every lineage-relevant site that cannot be proved must emit a `Hole` with stable hole ID, source location, reason, affected sink, candidate scope/facts, determinants, and state; it must not be omitted. | P0 |
| C08-FR-006 | Required hole reasons must include dynamic dispatch, reflection, dependency injection ambiguity, opaque/external call, dynamic SQL/query, unsupported syntax/framework/version, missing schema/dependency/build/config, alias ambiguity, parse failure, and resource limit. | P0 |
| C08-FR-007 | C08 must publish `holes_opened`, deterministic edges, unsupported sites, analyzed/skipped-with-reason files/sinks/fields, and coverage denominators that reconcile to package records. | P0 |
| C08-FR-008 | The same normalized inputs/versions must produce byte-identical facts, edges, holes, determinants, ordering, serialization, and package checksum across repeated/parallel runs. | P0 |
| C08-FR-009 | Every edge and hole must carry a complete `DeterminantSet`, including files, symbols, schemas, configuration keys, build/generated inputs, dependency/contract versions, and analyzer/policy/toolchain versions that can change the result. | P0 |
| C08-FR-010 | C08 must model configuration/dependency injection/profile/feature-flag choices as facts and emit a hole when a unique target cannot be selected; changed configuration key must invalidate affected results through C05. | P0 |
| C08-FR-011 | Supported transforms must be typed (direct/rename/cast/constant/arithmetic/concatenate/conditional/aggregate/collection path) with cited proof; unsupported or partially known expression becomes a hole rather than free-text certainty. | P0 |
| C08-FR-012 | Analyzer output must be content-addressed by source/artifact/context/schema/dependency/config/analyzer/policy/toolchain checksums and reusable only when every key part matches. | P0 |
| C08-FR-013 | C08 must expose read-only bounded analysis facts used by C09: symbol resolution, source spans, call graph, data-flow facts, schema lookup keys, and hole-scoped candidate context. | P0 |
| C08-FR-014 | Repository preparation/build steps must be declared, sandboxed, network-denied by default, dependency-pinned, resource/time bounded, and recorded; inability to build/resolve must become explicit incomplete/holes. | P0 |
| C08-FR-015 | A parser crash/resource timeout must isolate the workload/file, preserve completed facts, emit explicit incomplete coverage, and never return a deceptively complete package. | P0 |
| C08-FR-016 | Analyzer investment and supported construct expansion must be prioritized from C15 correction rate/holes by archetype, not unmeasured assumptions. | P1 |
| C08-FR-017 | A Dask custom-code analyzer may activate only after the common conformance, golden, determinism, determinant, security, and correction-measurement gates pass. | P1 |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C08-NFR-001 | A representative medium repository must analyze within 15 minutes p95 and 95% of targeted incrementals within five minutes p95 at approved Batch resource classes. | P0 |
| C08-NFR-002 | C08 must support 500 concurrent repository jobs and complete the 10,000-repository baseline within C06's 12-hour platform window under validated cache/size distributions. | P0 |
| C08-NFR-003 | Analyzer determinism must be proven by 100 repeated runs and cross-worker/Region golden checks with zero checksum divergence. | P0 |
| C08-NFR-004 | One crash/resource-exhausted/malicious repository must not affect another tenant/workload or retain source in a reused workspace. | P0 |

## 7. Data and Durable State

`AnalyzerRequest` contains immutable source/context/schema/dependency/config
references/checksums, repository/commit/artifact/environment, workload/path,
archetype/lane, C01/analyzer/policy/toolchain versions, and resource budget.

`DeterministicAnalysisPackage` contains:

- request/input checksums and analyzer capability statement.
- normalized source file/symbol/schema/config/dependency facts.
- call/data-flow graphs as checksummed indexed artifacts.
- provable edge candidates with proof/evidence/determinants.
- `Hole` records and unsupported/parse/resource-limit records.
- file/sink/field/construct counts and coverage/status.
- stable package schema/serialization/checksum and immutable evidence refs.

Stable `holeId` is a hash of repository/workload, semantic sink identity,
normalized source location/symbol, reason class, affected sink, and analyzer
major version; line-only movement uses symbol/AST identity to avoid needless
label churn where possible.

Operational state tracks request/idempotency/cache/attempt/status and ephemeral
workspace cleanup. C12 S3 is package authority; C05 indexes determinants; C09
reads hole-scoped fact indexes through controlled tools.

## 8. Interfaces and Contracts

### Analyzer SPI

```text
capabilities() -> supported language/framework/version/source/sink/transform facts
prepare(request, workspace) -> pinned build/schema/config facts or explicit gaps
analyze(workload, facts) -> provable candidates, holes, determinants, coverage
canonicalize(output) -> DeterministicAnalysisPackage bytes/checksum
```

Plugins cannot write directly to graph/proposals or call C09/model services.

### Batch invocation/result

C06 submits `AnalyzerRequest` by S3 reference/checksum. The container writes
package/fact indexes to attempt-scoped C12 prefixes, reads them back/verifies,
then conditionally registers status. Result event carries only reference,
checksum, counts, coverage, cache identity, and correlation.

### Tool fact access

C09 calls C08-owned read-only operations with hole scope/authorization:
`read_span`, `resolve_symbol`, `call_graph`, and schema/fact references. Search
is constrained to the immutable source snapshot and returns paths/spans, not a
whole repository dump.

## 9. Processing and State Model

```text
REQUESTED -> CACHE_CHECK -> WORKSPACE_PREPARE -> FACT_EXTRACTION
          -> DATAFLOW_ANALYSIS -> HOLE_ACCOUNTING -> CANONICALIZE
          -> PACKAGE_VERIFY -> COMPLETE
```

Alternative: `COMPLETE_WITH_HOLES`, `INCOMPLETE`, `UNSUPPORTED`, `QUARANTINED`,
`FAILED_RESOURCE`, `FAILED`.

Algorithm:

1. Validate/pin inputs; check exact content-addressed package cache.
2. Create isolated encrypted workspace; materialize exact commit/source and
   verify checksum; load only pinned schemas/dependencies/config facts.
3. Parse and build normalized AST/symbol/call/data-flow/config graphs.
4. Enumerate lineage boundary sources/sinks and transformations.
5. Emit a candidate only when deterministic rules prove source-to-sink mapping,
   transformation, and reachable semantic path.
6. Emit a stable Hole for each remaining lineage-relevant site and record all
   unsupported/incomplete coverage.
7. Compute determinants and coverage reconciliation; canonical sort/serialize.
8. Write/read-back package/facts, register cache/status, emit result, and destroy
   workspace in finally.

## 10. Failure Semantics

| Code | Class | Required behavior |
|---|---|---|
| `SOURCE_CHECKSUM_MISMATCH` | `DETERMINISTIC_INVALID` | Quarantine; no analysis/cache |
| `UNSUPPORTED_LANGUAGE_FRAMEWORK` | `INCOMPLETE` | Explicit unsupported coverage/package; no guessed edges |
| `PARSE_FAILURE` | `INCOMPLETE`/defect | Isolate file/site, emit hole/coverage; alert analyzer defect if supported construct |
| `BUILD_FACTS_MISSING` | `INCOMPLETE` | Emit affected holes/coverage; no default dependency/config |
| `RESOURCE_LIMIT` | `INCOMPLETE` | Terminate bounded job, preserve valid completed facts, mark incomplete |
| `NONDETERMINISTIC_OUTPUT` | `DETERMINISTIC_INVALID` defect | Do not activate/cache; retain diff and block analyzer version |
| `CACHE_CONTENT_CONFLICT` | `CONFLICT` | Preserve checksums; quarantine cache key/version |
| `BATCH_CAPACITY_OR_STORE_FAILURE` | `TRANSIENT` | Bounded retry with same input/cache identity |
| `WORKSPACE_CLEANUP_FAILED` | `INCOMPLETE` security-critical | Isolate worker, alert/audit; do not reuse workspace |

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C08-SEC-001 | Batch jobs must use short-lived source credentials, tenant/run-specific roles, private subnets/endpoints, controlled or denied egress, and exact C12 prefixes/KMS keys. | P0 |
| C08-SEC-002 | Workspaces must be encrypted, unique, nonshared, destroyed in finally, and verified absent before worker reuse; source/artifacts must not enter logs. | P0 |
| C08-SEC-003 | Build scripts/plugins/dependencies run sandboxed with pinned digests, no privilege escalation/host mounts, resource limits, and untrusted-repository threat controls. | P0 |
| C08-SEC-004 | Analyzer packages/evidence may contain metadata, symbols, source file:line spans and minimal cited snippets under ABAC, but must not contain credentials, payload values, secret config values, or unbounded source dumps. | P0 |
| C08-SEC-005 | Analyzer/plugin/toolchain releases must be signed/versioned, pass SAST/dependency/container/conformance/determinism tests, and emit immutable activation audit. | P0 |

## 12. Scale, Performance, and Availability

- Analyzer resource classes are measured by archetype/repository size/fact graph,
  with CPU/memory/disk/time limits and an oversized-workload explicit path.
- Content cache avoids repeated full analysis for identical artifacts/contexts;
  cache hit bypasses Batch only after checksum/schema/authorization verification.
- C06 caps concurrency from validated Batch/source/schema/C12 quotas; Tier-1
  incremental capacity is reserved from baseline/backfill.
- Large facts/packages move through S3 references; Step Functions/Lambda payloads
  remain small.
- Containers/artifacts are reproducible and available in warm Region; immutable
  packages replicate and operational cache/index rebuilds within C18 RPO/RTO.

## 13. Observability

| ID | Signal | Dimensions/alert | Priority |
|---|---|---|---|
| C08-OBS-001 | Analysis duration/resource/status | archetype/analyzer/version/repo size/priority | P0 |
| C08-OBS-002 | Deterministic edges and `holes_opened` | reason/archetype/framework/version/application | P0 |
| C08-OBS-003 | Coverage/unsupported/parse/build/resource gaps | file/sink/field/construct and owner | P0 |
| C08-OBS-004 | Determinant completeness/invalidation | kind/analyzer/archetype; missing determinant alert | P0 |
| C08-OBS-005 | Determinism/cache | checksum divergence, cache hit/conflict by version | P0 |
| C08-OBS-006 | Workspace/security | cleanup, egress, sandbox, secret scan; immediate alert | P0 |
| C08-OBS-007 | Correction rate feedback | deterministic provenance/archetype/analyzer version | P1 |

Metrics reconcile every enumerated lineage-relevant sink to deterministic
candidate or hole/unsupported/incomplete record. A percentage without numerator,
denominator, and gap reasons is not accepted.

## 14. Acceptance Criteria

| ID | Acceptance criterion |
|---|---|
| C08-AC-001 | Given golden Spring Boot/Kafka and FastAPI/Pydantic fixtures, C08 emits exactly the provable mappings/transforms and one named hole for every uncertain sink/site. |
| C08-AC-002 | Given identical pinned inputs in 100 repeated/parallel/cross-worker runs, package bytes/checksum are identical. |
| C08-AC-003 | Given configuration-only dependency injection change, affected determinants select/recompute different implementation facts and no stale edge survives incremental analysis. |
| C08-AC-004 | Given dynamic dispatch/reflection/opaque call/unsupported syntax, C08 emits typed holes/coverage and never a heuristic edge. |
| C08-AC-005 | Given parser/resource failure, valid completed facts remain attributable but package is visibly incomplete and cannot masquerade as full coverage. |
| C08-AC-006 | Given identical cache key, package is reused after checksum/authorization; changing any source/schema/config/dependency/analyzer/policy/toolchain key prevents stale reuse. |
| C08-AC-007 | Given malicious repository/build input, sandbox/network/credential/workspace controls prevent escape/exfiltration and isolate other jobs. |
| C08-AC-008 | Enterprise load meets C08 NFRs with exact requested/completed/cached/incomplete reconciliation and Tier-1 incremental performance. |

## 15. Component Test Matrix

| ID | Level | Fixture/precondition | Action | Expected result | Retained evidence |
|---|---|---|---|---|---|
| C08-CT-001 | Golden/Spring | Kafka serde, mapper, branch, DI, config, schema fixture | Analyze | Exact provable edges/transforms/holes/determinants | Package golden |
| C08-CT-002 | Golden/FastAPI | Pydantic aliases/nesting/validation/response/events fixture | Analyze | Exact expected package/coverage | Package golden |
| C08-CT-003 | Hole coverage | Dynamic/reflection/opaque/unsupported/missing inputs | Analyze | One stable typed hole per site; no guessed edge | Hole manifest |
| C08-CT-004 | Determinism | Same fixture 100 times, randomized worker/hash order, two Regions | Analyze | Byte-identical package/checksum | Determinism report |
| C08-CT-005 | Determinants | Source/schema/config/build/dependency variants | Change one input/plan | Exact affected results, no changed-file-only gap | Invalidation matrix |
| C08-CT-006 | Config injection | Only profile/qualifier/configuration key changes | Analyze incrementally | Correct implementation edge/hole replacement | Before/after package |
| C08-CT-007 | Cache | Same and one-key-changed requests | Lookup/analyze | Exact hit or required miss; conflict quarantined | Cache records |
| C08-CT-008 | Failure isolation | Parse exception, timeout, memory/disk limit | Analyze | Explicit incomplete/coverage; neighbor jobs succeed | Batch/results |
| C08-CT-009 | Security | Malicious build/plugin, egress, secret file/log, workspace residue | Analyze/scan | Denied/redacted/isolated/cleaned; audit/alert | Security report |
| C08-CT-010 | Contract | Analyzer plugin versions/capabilities and invalid package | Run conformance | Supported plugins pass; invalid/unknown rejected | Conformance report |
| C08-CT-011 | Tool facts | Hole-scoped span/symbol/call/schema requests | Query | Exact bounded read-only facts; unauthorized scope denied | Tool response/audit |
| C08-CT-012 | Load/recovery | 10,000 distribution, 500 concurrency, cache mix, worker/Region restart | Execute/rebuild | Window/NFRs/exact reconciliation/cleanup | Load/recovery report |

## 16. Integration Obligations

- **INT-049 C01/C04/C05↔C08:** Lane A request pins identity/context/config/
  dependency/determinants and wrong lane/version/checksum fails closed.
- **INT-050 C06↔C08:** Batch submit/budget/heartbeat/result/retry/redrive/cache and
  workspace finally behavior pass.
- **INT-051 C08↔C09:** only named open holes expose bounded approved facts/tools;
  deterministic edges cannot be rederived/overwritten.
- **INT-052 C08↔C12:** immutable packages/facts/cache keys, duplicate/conflict,
  retention, access, replication, and rebuild preserve authority/checksum.
- **INT-053 C08↔C13:** provable edges and holes pass G1/G2/G4 semantics;
  verification drops return the stable hole and coverage counts reconcile.
- **INT-054 C08↔C14/C15/C17:** drift, before/after review, evidence/holes/
  determinants/coverage, and correction labels are visible and versioned.
- **INT-055 C08↔C18:** sandbox/privacy/determinism/load/failure/reconciliation/
  DR dashboards and runbooks pass.

## 17. Definition of Done

- Analyzer framework, Spring/FastAPI P0 plugins, contracts, golden fixtures,
  deterministic package/facts/hole/determinant generation, cache, and sandboxed
  Batch images are implemented.
- C08 P0 requirements and C08-CT-001 through C08-CT-012 pass.
- INT-049 through INT-055 pass against production-shaped components.
- The fixture corpus proves every expected sink is candidate or named gap and
  determinism has zero checksum divergence.
- Config-only/determinant/full-scan cases prove incremental soundness boundaries.
- Load/security/recovery reports meet NFRs and prove tenant/workspace isolation,
  controlled egress, secret/payload absence, exact reconciliation, and cleanup.
- Analyzer defect/resource/cache/determinism/security runbooks and dashboards
  are exercised with real evidence IDs.

## 18. Implementation Notes

```text
contracts/schemas/analysis/
workers/analyzer/framework/
workers/analyzer/plugins/spring-kafka/
workers/analyzer/plugins/fastapi-pydantic/
workers/analyzer/plugins/dask/
workers/analyzer/tools/
infra/lib/constructs/analyzer-batch.ts
tests/fixtures/analyzers/{spring,fastapi,dask}/
tests/contract/analyzers/
tests/integration/analyzers/
tests/load/analyzers/
tests/security/analyzers/
```

Use Python 3.12 for framework/plugins and language-appropriate deterministic
parsers (for example compiler AST/symbol APIs or pinned parser libraries), all
pinned in container digests. Canonical serialization must not depend on Python
set/dict/hash/random/wall-clock behavior. Source span evidence uses immutable
commit paths/lines and quote hashes under ABAC.

Build order: common facts/contracts/goldens; Spring; FastAPI; determinism/
determinants/cache; fact tools; C09/C13; load/security/DR. Dask activates only
after measured correction/coverage justifies priority and all gates pass.

## 19. Traceability

| Source decision | C08 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| Deterministic floor and named holes | C08-FR-001 through C08-FR-007/011 | C08-CT-001/002/003/010 | INT-049/053; Lane A parser gate |
| Byte-identical and content-addressed | C08-FR-008/012; C08-NFR-003 | C08-CT-004/007 | INT-050/052 |
| Determinant incremental soundness | C08-FR-009/010 | C08-CT-005/006 | INT-049/054; incremental gate |
| Bounded failure/security/scale | C08-FR-014/015; C08-NFR-001-004; C08-SEC-001-005 | C08-CT-008/009/012 | INT-050/055; enterprise/security gates |
| Agent receives holes/tools only | C08-FR-013 | C08-CT-011 | INT-051 |


---

# 09-lane-a-agentic-resolver.md

# C09 Lane A Agentic Residual Resolver PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C09 |
| Status | Approved for implementation after C07 oracle and C15 corpus instrumentation |
| Launch phase | Pilot weeks 10-20; observation before enforcement |
| Criticality | P0 for declared Lane A residual scope; probabilistic output is always bounded and verified downstream |
| Primary owner | Lineage inference and tools team |
| Required approvers | Architecture, AI governance, security/privacy, analyzer/trust-engine owners |
| Upstream dependencies | C01, C05, C06, C08 open holes/facts, C12 cache, approved enterprise model gateway |
| Downstream dependencies | C13-C15, C17-C18 |
| Authoritative sources | Element-level v2 R4-R7; AWS architecture §§6.6, 11, 14, 16 |

## 2. Purpose and Outcomes

C09 resolves only named residual holes that deterministic analysis could not
prove. It uses a fixed set of bounded, read-only analysis tools and one guarded
`emit_edge` operation. Every proposed edge cites immutable file:line spans and
remains probabilistic until C13 applies G1-G5. A shared content-addressed result
turns the first governed resolution into a reproducible estate-wide artifact.

Measurable outcomes:

- 100% of C09 executions reference an open C08/C13 hole; zero whole-repository
  or already-resolved-edge tasks.
- 100% of proposed edges include file:line evidence, quote hashes, tool/fact
  provenance, artifact/context identity, and budget/model/prompt versions.
- Budget exhaustion, tool failure, insufficient evidence, or ambiguity returns
  unresolved. Never a guess on timeout.
- Identical cache identity returns the same immutable accepted resolution across
  CI runners, applications, and retries.

## 3. Scope and Non-Goals

### In scope

- Hole eligibility/policy, bounded task construction, enterprise gateway call,
  tool authorization/execution, `emit_edge` prevalidation, budgets, result
  canonicalization, content-addressed cache, telemetry, and audit.
- Initial residual types for supported Spring/FastAPI analyzers, expanding only
  with measured correction/benefit.

### Non-goals

- Reading an entire repository into a model context.
- Re-deriving or modifying deterministic edges.
- Executing on developer machines or in production.
- Assigning final confidence or publishing graph state.
- Returning an edge merely to meet a coverage target.
- Using a model-family self-judge as correctness evidence.

## 4. Actors and Use Cases

| Actor/component | Use case |
|---|---|
| C08 | Submit stable open hole plus bounded facts/tools |
| C06 | Enforce CI-only job, quota, timeout, priority, and cost budget |
| Model agent | Investigate one hole through approved structured tools |
| C13 | Re-read citations, check reachability/type/oracle, drop/downgrade/accept candidate |
| Reviewer/C15 | Correct material proposals and generate provenance/archetype labels |
| AI/security operator | Approve model/prompt/tool policy and audit usage/failures |

## 5. Component Boundary

### Owned behavior

- Hole-only admission and task envelope.
- Tool gateway for `search`, `read_span`, `resolve_symbol`, `call_graph`,
  `schema_lookup`, and `emit_edge`.
- Budget/model/prompt policy, immutable `AgentResolution`, shared cache, and
  unresolved reasons.

### Inputs

- Open `Hole`, C08 package/fact index, C01/context/schema versions, artifact
  digest/environment, policy and resource budget.

### Outputs

- `AgentResolution`: verified-as-well-formed candidate proposals or unresolved,
  citations/tool transcript references, cache identity, budgets, versions.

### Forbidden behavior

- Accepting a free-form repository archive or arbitrary tool/plugin.
- Calling `emit_edge` without citations/evidence or outside the hole's affected
  sink/scope.
- Model/network access from developer or production environments.
- Retrying until a preferred answer changes under the same cache key.
- Letting repository text/instructions modify system/tool/security policy.
- Claiming top-band confidence or correctness before C13/human evidence.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C09-FR-001 | C09 must admit only a valid open `Hole` from an immutable C08/C13 package and reject a deterministic-resolved, closed, stale-version, or arbitrary task. | P0 |
| C09-FR-002 | The task must be hole-only: hole ID/reason/location/affected sink, bounded candidate facts, pinned artifact/context/schema/analyzer/policy versions, approved tools, and budgets; it must not include the repository as context. | P0 |
| C09-FR-003 | The only model-visible tools must be `search`, `read_span`, `resolve_symbol`, `call_graph`, `schema_lookup`, and `emit_edge`, each with strict typed input/output and per-hole authorization. | P0 |
| C09-FR-004 | `search` must return bounded paths/symbols/spans from the immutable snapshot; it must not return unbounded files, binary content, secrets, or ignored/unauthorized paths. | P0 |
| C09-FR-005 | `read_span` must require exact file/range limits and return normalized text plus commit/path/line and quote hash; `resolve_symbol`, `call_graph`, and `schema_lookup` must return C08/C01/C05 facts with versions. | P0 |
| C09-FR-006 | `emit_edge` must reject an edge outside the hole sink/scope or missing canonical endpoints, typed transformation/path, determinants, and at least one immutable file:line citation with quote hash. | P0 |
| C09-FR-007 | C09 must enforce per-hole limits for turns, tool calls, input/output tokens, cited bytes, wall time, and estimated cost; every call/result records remaining budget. | P0 |
| C09-FR-008 | Budget exhaustion, ambiguity, unsupported evidence, tool/gateway failure after bounded retry, or no defensible mapping must return unresolved with a typed reason and must never emit a guess. | P0 |
| C09-FR-009 | C09 must operate only through the approved enterprise gateway in registered CI analysis accounts; developer-machine and production execution must be technically denied and audited. | P0 |
| C09-FR-010 | Resolution/cache identity must be `codeSliceHash + schemaHash + modelVersion + promptVersion + toolPolicyVersion` plus semantic hole/analyzer major version where needed to prevent collisions. | P0 |
| C09-FR-011 | The first conditionally accepted complete result for a cache identity must be immutable/shared; repeated/racing execution returns it and conflicting content enters cache conflict rather than overwriting or rerunning for a different answer. | P0 |
| C09-FR-012 | Any source/schema/model/prompt/tool policy/hole semantic change must create a new cache identity; invalidation/deprecation must preserve prior result/audit and require governed policy. | P0 |
| C09-FR-013 | `AgentResolution` must record hole, candidates/unresolved, every cited evidence/tool fact reference, minimal transcript metadata, model/prompt/tool versions, budgets, gateway request ID, input/output checksum, and policy decision. | P0 |
| C09-FR-014 | C09 must treat repository/schema text as untrusted data, isolate it from system/tool instructions, and deny prompt-injected requests to exfiltrate, change policy, call unregistered tools, or broaden scope. | P0 |
| C09-FR-015 | C09 must not set final confidence; it must label all candidates sole-LLM provenance pending C13 verification/oracle/human outcomes. | P0 |
| C09-FR-016 | Metrics must reconcile holes submitted, cache hits, resolved, unresolved by reason, candidate emissions/rejections, verification outcomes, corrections, cost, and latency by archetype/model/prompt. | P0 |
| C09-FR-017 | Model/prompt/tool policy rollout must use a labelled offline eval, canary, correction-rate monitoring, version pinning, rollback, and no automatic enforcement expansion. | P0 |
| C09-FR-018 | Additional tools or autonomous multi-hole/repository tasks require a new major policy/security review and are outside initial scope. | P1 |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C09-NFR-001 | A cache hit must return within 500 ms p95; an uncached resolution must finish or return typed unresolved within the configured maximum 10 minutes. | P0 |
| C09-NFR-002 | C09 must enforce organization/domain/priority concurrency, daily token/cost budgets, and Bedrock quota without delaying Tier-1 deterministic work. | P0 |
| C09-NFR-003 | Cache/content/result availability must be 99.9% monthly; gateway unavailability degrades to unresolved/deferred, never blocks deterministic package completion or invents edges. | P0 |
| C09-NFR-004 | No sensitive/unauthorized source content may cross the gateway boundary or appear in telemetry/transcripts; test corpus exfiltration rate must be zero. | P0 |

## 7. Data and Durable State

`AgentTask` contains hole/package/fact refs and checksums, allowed repository
paths/symbols/schemas/sink, C01/context/artifact/environment/analyzer/policy,
model/prompt/tool versions, CI environment attestation, per-dimension budgets,
cache identity, and correlation.

`ToolCallRecord` contains task/hole/turn/tool, typed sanitized arguments/result
reference/checksum, authorization decision, start/end, bytes/tokens/cost, error,
and remaining budget. Source content remains in restricted evidence; broad
operational records store paths/hashes only.

`AgentResolution` contains:

- status `RESOLVED_CANDIDATE`, `UNRESOLVED`, `REJECTED`, or `CONFLICT`.
- candidate source/target/typed transform/path/determinants.
- file:line citations and quote hashes plus C08 fact/tool references.
- unresolved/rejected reasons.
- cache identity, immutable input/result checksums, model/prompt/tool/gateway
  versions/IDs, budgets used, provenance `LLM_RESIDUAL`, created time.

S3 stores immutable task/results/restricted evidence. DynamoDB conditionally
indexes cache identity/status and budgets/leases. Bedrock/gateway logs follow
enterprise no-training/retention settings and must not become product authority.

## 8. Interfaces and Contracts

### Submit/lookup

- `POST /v1/agent-resolutions` accepts `AgentTask` S3 reference/checksum and
  idempotency. It verifies CI/account/hole/cache/policy before queue/admission.
- `GET /v1/agent-resolutions/by-cache-key/{hash}` returns authorized immutable
  result reference/status, never another tenant's restricted evidence.

### Tool contracts

- `search(query, pathAllowlist, resultLimit<=50)` -> file/symbol/span metadata.
- `read_span(path, startLine, endLine<=start+200)` -> text/ref/quote hash.
- `resolve_symbol(symbolOrLocation, depth<=policy)` -> canonical fact/ambiguity.
- `call_graph(symbol, direction, depth<=policy, nodeLimit)` -> bounded fact graph.
- `schema_lookup(schemaOrField, version)` -> canonical schema facts/ambiguity.
- `emit_edge(holeId, source, target, transform, path, citations,
  determinants)` -> accepted-as-well-formed or exact rejection.

Tools require task token/hole scope and record every decision. `emit_edge`
writes only attempt-scoped candidate output, never C13/proposal/graph.

## 9. Processing and State Model

```text
SUBMITTED -> VALIDATING_HOLE -> CACHE_LOOKUP
          -> ADMITTED -> INVESTIGATING -> EMIT_OR_UNRESOLVED
          -> CANONICALIZE -> CONDITIONAL_CACHE_WRITE -> COMPLETE
```

Alternative: `CACHE_HIT`, `DEFERRED_QUOTA`, `REJECTED`, `UNRESOLVED`,
`CACHE_CONFLICT`, `FAILED_TRANSIENT`.

1. Verify task/source/checksum, open hole/current versions, CI attestation,
   policy, path/tool scope, and budgets.
2. Look up exact cache key. Return authorized immutable result when present.
3. Acquire per-key lease/admission and call enterprise gateway with fixed system
   policy and hole envelope; repository text is explicitly untrusted data.
4. Validate/authorize each typed tool call and decrement budgets before result.
5. `emit_edge` performs scope/contract/citation/determinant prechecks; agent may
   instead conclude unresolved.
6. At any exhausted/uncertain state, stop and create typed unresolved.
7. Canonicalize/checksum and conditionally create shared cache result. A racing
   prior result wins; conflicting bytes become conflict for investigation.

## 10. Failure Semantics

| Code | Class | Required behavior |
|---|---|---|
| `HOLE_NOT_OPEN_OR_STALE` | `DETERMINISTIC_INVALID` | Reject task; do not call model |
| `ENVIRONMENT_NOT_CI` | `DETERMINISTIC_INVALID` security | Deny/audit/alert; no gateway call |
| `TOOL_SCOPE_DENIED` | `DETERMINISTIC_INVALID` security | Reject call; count; terminate task by policy |
| `CITATION_REQUIRED_OR_STALE` | `DETERMINISTIC_INVALID` candidate | Reject emission; allow bounded correction or unresolved |
| `BUDGET_EXHAUSTED` | `INCOMPLETE` | `UNRESOLVED`; no guess/retry under same task |
| `INSUFFICIENT_OR_AMBIGUOUS_EVIDENCE` | `INCOMPLETE` | `UNRESOLVED` with evidence/reason |
| `GATEWAY_THROTTLED_UNAVAILABLE` | `TRANSIENT` | Bounded retry/defer, then unresolved; deterministic work unaffected |
| `CACHE_CONTENT_CONFLICT` | `CONFLICT` | Preserve results/checksums; quarantine model/prompt/key; no overwrite |
| `PROMPT_INJECTION_ATTEMPT` | `DETERMINISTIC_INVALID` security | Deny requested scope/tool, sanitize audit, task unresolved/rejected |

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C09-SEC-001 | IAM/SCP/network policy must allow gateway invocation only from approved CI analysis roles/accounts and explicitly deny production/developer identities. | P0 |
| C09-SEC-002 | The task builder must minimize context to hole facts/cited spans and scan/redact credentials, secrets, payload values, personal data beyond allowed metadata, and ignored/restricted paths before gateway exposure. | P0 |
| C09-SEC-003 | Tool service must enforce per-task capability tokens, path/symbol/schema allowlists, byte/depth/result limits, read-only operation except attempt-scoped `emit_edge`, and complete audit. | P0 |
| C09-SEC-004 | Repository content is untrusted; system/tool policy is out-of-band and immutable for a task; prompt-injected instructions cannot alter tool schema, permissions, budgets, model, or destination. | P0 |
| C09-SEC-005 | S3/cache/budget state must use KMS/private access, domain ABAC, immutable/versioned results, strict retention, and separate task-builder/tool/model/cache roles. | P0 |
| C09-SEC-006 | Enterprise gateway settings must prohibit model training on inputs, use approved Region/model, enforce retention policy, and expose auditable request IDs without broad prompt logging. | P0 |

## 12. Scale, Performance, and Availability

- C06 routes residuals through a separate SQS/admission pool; deterministic and
  Tier-1 workflows cannot be starved by model quota.
- Cache is estate-wide by content but authorization is checked on every lookup;
  source snippets are not exposed cross-tenant even when a semantic result is
  safely reusable under policy.
- Budgets are configured by hole reason/archetype/priority and capped globally/
  per organization/domain/model. Exhaustion is a valid unresolved outcome.
- Rate-limit/circuit-breaker prevents a gateway/model defect from generating
  cost/retry storms. Deterministic proposals may proceed with open holes.
- Immutable cache/results replicate under C18 RPO; operational leases/budgets
  restore/rebuild. A model service is not in the graph query/publication path.

## 13. Observability

| ID | Signal | Dimensions/alert | Priority |
|---|---|---|---|
| C09-OBS-001 | Hole submission/cache/result | archetype/reason/model/prompt/tool policy/status | P0 |
| C09-OBS-002 | Tool calls/rejections/budgets | tool/reason/turn/bytes/tokens/cost | P0 |
| C09-OBS-003 | Candidate/unresolved/rejection | reason/provenance/application/domain | P0 |
| C09-OBS-004 | Gateway latency/throttle/error | model/Region/account/request class | P0 |
| C09-OBS-005 | Verification/correction rate | G1-G5 outcome, archetype, model/prompt/tool version | P0 |
| C09-OBS-006 | Security/privacy | non-CI, prompt injection, scope deny, secret scan, egress | P0 |
| C09-OBS-007 | Cache conflict/hit/cost avoidance | key version/model/archetype | P1 |

No dashboard treats self-reported model confidence as accuracy. Advancement uses
C13 verification and C15 labelled correction rates by provenance/archetype.

## 14. Acceptance Criteria

| ID | Acceptance criterion |
|---|---|
| C09-AC-001 | Given a valid open hole, C09 exposes only approved bounded tools/facts and any emitted candidate cites exact immutable file:line spans/quote hashes within the hole scope. |
| C09-AC-002 | Given a resolved/closed/stale hole or request to rederive a deterministic edge, C09 rejects before model invocation. |
| C09-AC-003 | Given token/turn/tool/time/cost exhaustion or ambiguous evidence, C09 returns typed unresolved and emits no edge. |
| C09-AC-004 | Given identical cache identity on two racing CI runners, one immutable result is accepted and both return it; different content becomes conflict, not overwrite/rerun selection. |
| C09-AC-005 | Given any cache key input/version change, stale result is not reused; prior immutable resolution remains auditable. |
| C09-AC-006 | Given developer/production invocation, unregistered tool, path escape, or prompt injection, technical controls deny/audit and no unauthorized content/gateway call occurs. |
| C09-AC-007 | Given candidate citation changed or cannot be re-read, C13 integration drops it/returns hole open; C09 cannot self-promote confidence. |
| C09-AC-008 | Load/quota/gateway-outage tests keep deterministic work within SLO, budgets bounded, and every hole reconciled to cache/resolved/unresolved/deferred. |

## 15. Component Test Matrix

| ID | Level | Fixture/precondition | Action | Expected result | Retained evidence |
|---|---|---|---|---|---|
| C09-CT-001 | Admission | Open, closed, stale, and arbitrary tasks | Submit | Only current open hole invokes model | Decision/gateway counts |
| C09-CT-002 | Tool contract | Valid/invalid search/span/symbol/call/schema calls | Invoke | Typed bounded results or exact deny | Tool fixtures/audit |
| C09-CT-003 | Emit contract | Cited in-scope versus uncited/out-of-scope/stale evidence | `emit_edge` | Accept well-formed only; exact rejection reasons | Candidate/rejection set |
| C09-CT-004 | Budget | Exhaust each turn/tool/token/byte/time/cost dimension | Execute | `UNRESOLVED`; no post-limit call/edge | Budget ledger/transcript metadata |
| C09-CT-005 | Cache/idempotency | Same key sequential/concurrent/retry | Resolve | One immutable result/gateway invocation logically | Cache/attempt history |
| C09-CT-006 | Cache invalidation | Change each code/schema/model/prompt/tool/hole key part | Lookup | Required miss/new version; prior preserved | Key/result matrix |
| C09-CT-007 | Conflict | Racing same key returns differing bytes | Commit | `CACHE_CONTENT_CONFLICT`; neither overwrites active until governed resolution | Conflict artifacts |
| C09-CT-008 | Environment/security | Developer/prod identities and network paths | Submit/call gateway | Denied before exposure; audit/alert | IAM/SCP/network evidence |
| C09-CT-009 | Prompt injection/privacy | Repository asks for secrets/tool expansion/exfiltration; secret fixtures | Execute | Policy unchanged, deny/redact, unresolved/rejected | Security transcript scan |
| C09-CT-010 | Gateway failure | Throttle/timeout/model unavailable | Execute | Bounded retry/defer then unresolved; no cost storm | Attempt/metrics |
| C09-CT-011 | Verification feedback | Candidate passes/fails each G1-G5/correction | Process feedback | Metrics/labels keyed by exact model/prompt/tool/archetype | Feedback aggregates |
| C09-CT-012 | Load/quota/recovery | Residual spike, domains, cache mix, gateway outage/Region restart | Execute | Budgets/fairness/NFRs/exact reconciliation/cache recovery | Load/recovery report |

## 16. Integration Obligations

- **INT-056 C08↔C09:** open hole/fact/tool scope round-trips; deterministic/
  closed/stale work is rejected and no whole repository enters context.
- **INT-057 C06↔C09:** residual queue/admission/budget/retry/defer/result prevents
  starvation and preserves one run/stage outcome.
- **INT-058 C09↔Enterprise gateway:** CI-only identity, approved model/Region,
  retention/no-training, rate/quota, audit ID, and outage cases pass.
- **INT-059 C09↔C12:** task/result/cache immutable writes, first-writer,
  conflict, auth, replication, and restore preserve reproducibility.
- **INT-060 C09↔C13:** citations/evidence/determinants undergo G1-G5; dropped edge
  reopens same hole, failures/downgrades and confidence caps are exact.
- **INT-061 C09↔C15/C17:** provenance/evidence/unresolved/budget/verification/
  correction are visible without unsafe source exposure and feed corpus metrics.
- **INT-062 C09↔C18:** IAM/SCP/privacy/prompt-injection/cost/load/outage/audit/DR
  gates and runbooks pass.

## 17. Definition of Done

- Hole admission/task builder, typed tools, budget ledger, enterprise gateway,
  `emit_edge`, immutable result/cache, feedback telemetry, and policy rollout
  are implemented.
- C09 P0 requirements and C09-CT-001 through C09-CT-012 pass.
- INT-056 through INT-062 pass in production-shaped CI/nonproduction accounts.
- Security evidence proves developer/production hard-deny, minimal context,
  capability/path limits, prompt-injection resistance, no secret/payload leak,
  approved model/Region/no-training, and audit.
- Cache race/invalidation/conflict and gateway outage tests prove reproducible
  behavior and no retry-for-preferred-answer.
- Labelled offline/canary report publishes verification/correction/unresolved/
  cost metrics by provenance/archetype before enforcement use.
- Quota/gateway/cache/security/rollback/DR runbooks and alarms are exercised.

## 18. Implementation Notes

```text
contracts/schemas/agent-resolution/
services/agent-task-builder/
services/agent-tools/
workers/agent-resolver/
workers/agent-resolver/prompts/
infra/lib/constructs/agent-gateway.ts
infra/lib/constructs/agent-cache.ts
tests/fixtures/agent-holes/
tests/contract/agent-tools/
tests/integration/agent-resolver/
tests/security/agent-resolver/
tests/load/agent-resolver/
```

Use Python 3.12 for task/agent/tool orchestration and typed JSON schemas for all
tool calls. Bedrock is accessed only through the enterprise gateway. Use a
model API that supports tool calling and explicit version pinning; model choice
is policy/config, not hard-coded product behavior. Store prompts as reviewed
versioned artifacts and results in C12.

Build order: contracts/hole admission; read-only tools; budgets/security; fixed
prompt/gateway; emit/result/cache; C13 feedback; canary/load/DR. Default feature
flag is observation-only; rollback disables new tasks while preserving cached
results/audit and open holes.

## 19. Traceability

| Source decision | C09 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| Agent only on named holes/tools | C09-FR-001 through C09-FR-006 | C09-CT-001/002/003 | INT-056/060 |
| Bounded/no guess | C09-FR-007/008 | C09-CT-004/010 | INT-057/058 |
| Shared content-addressed reproducibility | C09-FR-010 through C09-FR-013 | C09-CT-005/006/007 | INT-059 |
| CI-only/security/privacy/prompt injection | C09-FR-009/014; C09-SEC-001-006 | C09-CT-008/009 | INT-058/062 |
| Verification/correction not self-confidence | C09-FR-015 through C09-FR-017 | C09-CT-011/012 | INT-060/061; calibration gate |


---

# 10-lane-c-opaque-collector.md

# C10 Lane C Opaque-Substrate Collector PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C10 |
| Status | Approved design; activation follows measured Lane A/B pilot |
| Launch phase | P1/Q3+ advisory only |
| Criticality | Nonblocking for initial launch; P0 controls apply whenever enabled |
| Primary owner | Opaque lineage and privacy engineering team |
| Required approvers | Architecture, privacy/security/legal, data owners, trust-engine owner |
| Upstream dependencies | C01, C04 Lane C route, C05 context/schema/bindings, C06 schedule, approved source-local observation mechanism |
| Downstream dependencies | C12-C13, C15, C17-C18 |
| Authoritative sources | Element-level v2 R5/R6/R11; AWS architecture principles 5-7 and security/privacy controls |

## 2. Purpose and Outcomes

C10 provides privacy-preserving, statistical lineage evidence for vendor,
legacy binary, and other opaque systems with neither readable source nor an
authoritative native plan. It compares source-local irreversible fingerprints
and timing/schema evidence under a governed observation window. Its output is
advisory, never sole proof, and always subject to a confidence cap and C13
verification/human review.

Measurable outcomes:

- Zero raw values, reversible tokens, credentials, or payload bodies leave the
  source-local trust boundary or enter platform storage/logs.
- 100% of emitted relationships include environment/artifact/system/schema/
  window, minimum observation and entropy evidence, ambiguity/collision
  analysis, precision-policy version, and advisory confidence cap.
- Insufficient, low-cardinality, sensitive, ambiguous, collision-prone, stale,
  or cross-environment evidence returns no candidate and an explicit gap.
- Precision/false-positive/false-negative and abstention are measured against a
  labelled sample before any production use or policy expansion.

## 3. Scope and Non-Goals

### In scope

- Lane C onboarding consent/policy, source-local observation job, allowlisted
  schema/field metadata, window-scoped keyed fingerprint aggregation,
  statistical match/ambiguity analysis, privacy checks, advisory candidate
  package, scheduled refresh/expiry, evaluation and audit.

### Non-goals

- Capturing/storing/transmitting raw values or reversible encodings.
- Setting `VERIFIED`, blocking CI/deployment, or auto-publishing an opaque edge.
- Inferring an exact transform expression from correlation.
- Using low-cardinality/sensitive identifiers even if technically hashable.
- Correlating across organizations/environments/windows without an explicitly
  approved scoped policy/key and documented purpose.
- Replacing source remediation/native instrumentation when feasible.

## 4. Actors and Use Cases

| Actor/component | Use case |
|---|---|
| Data/system owner | Enroll an opaque source/sink and approve fields/window/purpose |
| Privacy/security | Review field eligibility, fingerprint/key/retention policy, and evaluation |
| Source-local collector | Compute aggregates without exporting raw values |
| C13 | Use qualified Lane C agreement only as advisory G5 evidence/candidate |
| Reviewer | Inspect support/ambiguity/cap and accept/correct/reject |
| Operator | Detect stale/insufficient/collision/privacy/key failure and revoke collection |

## 5. Component Boundary

### Owned behavior

- Opaque enrollment/capability/consent, source-local compute package, key/window
  policy, match analysis, abstention, expiry, and `OpaqueEvidencePackage`.

### Inputs

- C04 Lane C decision and C05 bindings/schema/field candidates.
- System/environment/artifact/version and authorized observation endpoints.
- Approved field eligibility/classification, key/window/minimum observation,
  precision/ambiguity/retention policy.

### Outputs

- Aggregated nonreversible evidence, advisory candidate(s) or abstention/gap,
  evaluation metrics, immutable package/checksum.

### Forbidden behavior

- Exporting raw values or per-record fingerprints that enable linkage/recovery.
- Hashing without a secret scoped key, or retaining key after the window.
- Fingerprinting low-cardinality or prohibited sensitive fields.
- Selecting one producer/field when support is tied/ambiguous.
- Treating absence of match as proof no path exists.
- Raising either confidence axis to top band from Lane C alone.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C10-FR-001 | C10 must operate only for an effective C04 Lane C workload and an approved enrollment naming owner, purpose, systems/environments/artifacts, fields/schema versions, observation window, and privacy policy. | P0 |
| C10-FR-002 | Field eligibility must deny raw payload/body, credentials/tokens, direct identifiers, prohibited sensitive classifications, low-cardinality values, free text, and any field failing configured entropy/uniqueness/minimum-population thresholds. | P0 |
| C10-FR-003 | Eligible values must be transformed only inside the source-local trust boundary using a window/environment/purpose-scoped keyed HMAC or approved nonreversible primitive; raw values and unscoped hashes must never leave that boundary. | P0 |
| C10-FR-004 | The platform must receive only aggregate sketches/counts and metadata sufficient for governed comparison; per-record fingerprints and key material are prohibited in central evidence. | P0 |
| C10-FR-005 | Fingerprint keys must be issued through KMS/Secrets controls to authorized source-local jobs, never logged/exported, inaccessible after window close/expiry, and nonreusable across unapproved environments/purposes. | P0 |
| C10-FR-006 | Every comparison must require matching organization, approved environment/window/purpose/key-policy, canonical schema/field identity or candidates, artifact/system version, and sufficient overlapping observation interval. | P0 |
| C10-FR-007 | C10 must enforce minimum observation count, field presence, entropy/uniqueness, support, collision probability, temporal alignment, and ambiguity thresholds before emitting an advisory candidate. | P0 |
| C10-FR-008 | Multiple equal/near support candidates, multi-producer ambiguity, collision risk above policy, insufficient sample, stale window, or identity/schema conflict must yield explicit abstention/unresolved and no selected edge. | P0 |
| C10-FR-009 | `OpaqueEvidencePackage` must contain no raw values and must record aggregate support/count/range, ambiguity/collision statistics, field eligibility outcome, policy/key identifier (not key), system/environment/artifact/schema/window, provenance, expiry, and checksum. | P0 |
| C10-FR-010 | Every C10 relationship must be labelled `ADVISORY_OPAQUE`, carry a permanent policy confidence cap below `VERIFIED`, require C13 checks/human review, and be structurally excluded from automated enforcement/blocking inputs. | P0 |
| C10-FR-011 | Fingerprint agreement may contribute bounded derivational/structural evidence under calibrated C13 policy but must not assert an exact transformation or top-band confidence by itself. | P0 |
| C10-FR-012 | Absence/nonmatch must be reported as inconclusive with observation/coverage, never as proof an edge/path does not exist. | P0 |
| C10-FR-013 | C10 must run on a governed schedule/window, expire stale packages, and request recollection when schema, environment, artifact/system, field policy, or binding determinants change. | P0 |
| C10-FR-014 | Precision, false-positive, false-negative, abstention, ambiguous, collision, and privacy-denial rates must be measured on a labelled sample by archetype/system before activation and quarterly thereafter. | P0 |
| C10-FR-015 | A kill switch must revoke active jobs/keys, stop new collection, expire pending evidence, and retain sanitized immutable audit without requiring a platform deployment. | P0 |
| C10-FR-016 | New fingerprint/statistical methods or cross-environment correlation require a new versioned privacy threat model, labelled evaluation, and explicit approval. | P1 |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C10-NFR-001 | Source-local collection CPU/memory/network overhead must remain below approved per-system budgets and must fail open for the observed application/data job. | P0 |
| C10-NFR-002 | Central analysis must process one million aggregate field-pair candidates within two hours in the production-like batch environment while enforcing abstention/privacy rules. | P0 |
| C10-NFR-003 | Source-local/key/central failures must never expose raw values or interrupt the observed system; they produce incomplete/abstention with audit. | P0 |
| C10-NFR-004 | Immutable approved aggregate evidence must recover within C18 RPO/RTO; destroyed scoped keys must not be restored to make old fingerprints newly linkable. | P0 |

## 7. Data and Durable State

`OpaqueEnrollment` includes organization/domain/owner, source/sink systems,
environment/artifact/schema/fields, purpose/legal/privacy approval, field
classifications, observation/minimum observation/entropy/uniqueness/support/
ambiguity/collision thresholds, key/retention policy, schedule/expiry, collector
version, kill-switch state, and checksum.

`AggregateFingerprintSketch` includes window/system/field canonical/native ID,
schema/artifact/environment, observation/presence/distinct estimates, approved
nonreversible sketch, sketch algorithm/key-policy ID, privacy eligibility, and
checksum. It must be impossible to enumerate individual records from the
contracted representation within the approved threat model.

`OpaqueEvidencePackage` includes compared sketches, overlap/support statistics,
candidate/abstention reasons, ambiguity/collision estimates, coverage,
`ADVISORY_OPAQUE` provenance, confidence cap policy, expiry, evaluation version,
and immutable checksum/reference.

KMS/Secrets holds short-lived key material under source-local job roles. C12 S3
holds only approved aggregates/packages; DynamoDB holds enrollment/job/window/
idempotency/expiry/evaluation indexes.

## 8. Interfaces and Contracts

- `POST /v1/opaque-enrollments` creates reviewed versioned enrollment; activation
  requires privacy/security/data-owner approvals and expected policy version.
- C06 starts `OpaqueCollectionJob` by immutable enrollment/context references.
- Source-local collector returns signed `AggregateFingerprintSketch` by direct
  restricted C12 path or governed cross-account transfer; contract validator
  rejects per-record/generic/raw content.
- `POST /v1/opaque-analysis` accepts source/sink sketch manifests/checksums and
  produces package/abstention by S3 reference.
- `POST /v1/opaque-enrollments/{id}:kill` is idempotent, audited, disables jobs,
  revokes grants/keys, and emits expiry/reconciliation events.
- Events: `opaque.window.started|closed|incomplete`,
  `opaque.evidence.created|abstained|expired`, `opaque.kill-switch.activated`.

## 9. Processing and State Model

```text
DRAFT -> PRIVACY_REVIEW -> APPROVED -> SCHEDULED -> COLLECTING
      -> WINDOW_CLOSED -> ANALYZING -> ADVISORY_READY -> EXPIRED
```

Alternatives: `DENIED`, `INCOMPLETE`, `ABSTAINED`, `FAILED`, `KILLED`.

1. Validate effective Lane C/enrollment/context and source-local attestation.
2. Apply field classification/cardinality/entropy/minimum-population denial
   before fingerprinting; record aggregate denial reason only.
3. Issue window-scoped job grant/key; compute allowed aggregates locally.
4. Validate signed sketch contract/privacy/budgets and persist; close/revoke key
   in finally/expiry.
5. Compare only compatible scoped sketches; calculate support/ambiguity/collision
   and apply conservative thresholds.
6. Emit advisory candidate or explicit abstention, never forced coverage.
7. C13 verifies identity/type/reachability where available and applies cap;
   C15 review/label is required before accepted use.
8. Expire package/recollect on schedule or determinant change.

## 10. Failure Semantics

| Code | Class | Required behavior |
|---|---|---|
| `FIELD_PRIVACY_INELIGIBLE` | `DETERMINISTIC_INVALID` | Do not fingerprint; aggregate denial reason/audit only |
| `LOW_CARDINALITY_OR_ENTROPY` | `DETERMINISTIC_INVALID` privacy | Deny field; no sketch/raw log |
| `MINIMUM_OBSERVATION_NOT_MET` | `INCOMPLETE` | Abstain; report counts/window |
| `FINGERPRINT_SCOPE_MISMATCH` | `CONFLICT` | Do not compare; identify policy/environment/window mismatch |
| `AMBIGUOUS_OR_COLLISION_RISK` | `CONFLICT`/`INCOMPLETE` | Abstain; preserve aggregate statistics |
| `KEY_EXPIRED_OR_REVOKED` | `DETERMINISTIC_INVALID` | Stop/close incomplete; no reissue under same window identity |
| `SOURCE_LOCAL_COLLECTOR_FAILED` | `INCOMPLETE` | Fail open observed system; audit/alert/recollect if allowed |
| `RAW_OR_PER_RECORD_CONTENT_DETECTED` | `DETERMINISTIC_INVALID` security | Reject before central persistence; revoke/alert/investigate |
| `CENTRAL_STORE_OR_CAPACITY_FAILURE` | `TRANSIENT` | Bounded retry of aggregate package; never request raw fallback |

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C10-SEC-001 | Enrollment requires data-owner, privacy, and security approval with purpose limitation, fields/classification, environments, window, retention, threat model, and kill-switch owner. | P0 |
| C10-SEC-002 | Technical controls must prevent raw values, per-record fingerprints, unkeyed/reusable hashes, low-cardinality/sensitive fields, key material, and arbitrary attributes from entering central transport/storage/logs. | P0 |
| C10-SEC-003 | Key grants must be source-local/job/window/purpose/environment scoped, short-lived, nonexportable where supported, audited, and revoked/destroyed on close/expiry/kill. | P0 |
| C10-SEC-004 | Collector/transfer/storage/analysis roles must be separate, least privilege, private/TLS/KMS protected, domain ABAC, and denied access to unrelated enrollment/windows. | P0 |
| C10-SEC-005 | Privacy-contract scanning must inspect schema and aggregate statistical properties without logging prohibited content; violation triggers revoke/quarantine/incident runbook. | P0 |
| C10-SEC-006 | Retention/deletion/legal-hold policy applies to approved aggregates/audit; raw source values remain governed solely by the source system and are never copied for C10. | P0 |

## 12. Scale, Performance, and Availability

- Collection is scheduled/admission-controlled and lower priority than Tier-1
  incremental/native/deterministic work. Per-source budgets protect observed
  systems; backpressure skips/defer windows visibly rather than increasing load.
- Aggregate sketches are bounded by field/window, never record count. Central
  comparison shards by organization/environment/schema candidate partitions and
  uses Batch/S3 manifests.
- Candidate explosion uses conservative prefilters from C05 bindings/schemas;
  an unbounded all-to-all comparison is rejected.
- Kill/revocation path is independent of central analyzer health.
- Cross-Region restores exclude destroyed key material; restored aggregates
  retain original scope/expiry and cannot be linked outside it.

## 13. Observability

| ID | Signal | Dimensions/alert | Priority |
|---|---|---|---|
| C10-OBS-001 | Enrollment/window/job status | system/domain/environment/owner/policy | P0 |
| C10-OBS-002 | Field eligibility/denial | classification/reason/collector policy; privacy alert | P0 |
| C10-OBS-003 | Observation/support/abstention | system/archetype/reason/window | P0 |
| C10-OBS-004 | Ambiguity/collision/expiry | policy/system/schema/owner | P0 |
| C10-OBS-005 | Raw/per-record/key/scope violation | source/account/job; immediate security alert | P0 |
| C10-OBS-006 | Labelled precision/FP/FN/abstention | system/archetype/policy/evaluation version | P0 |
| C10-OBS-007 | Source overhead/central cost | CPU/memory/network/job/field pairs | P1 |

Metrics never publish fingerprint/sketch content. C17 displays advisory status,
scope/window/support/ambiguity/expiry/evidence and cap, not a misleading exact
probability unless calibrated policy explicitly defines a user-safe statistic.

## 14. Acceptance Criteria

| ID | Acceptance criterion |
|---|---|
| C10-AC-001 | Given an approved high-cardinality field/window with known match, source-local jobs emit only bounded aggregate sketches and C10 produces an advisory candidate with scope/support/ambiguity/cap. |
| C10-AC-002 | Given raw/per-record content, low-cardinality/sensitive field, unkeyed hash, or key material, validation denies before central persistence and triggers sanitized security evidence. |
| C10-AC-003 | Given insufficient observations, stale window, scope mismatch, tied candidates, multi-producer ambiguity, or collision risk, C10 abstains and emits no selected edge. |
| C10-AC-004 | Given no fingerprint match, C10 reports inconclusive coverage rather than a negative lineage assertion. |
| C10-AC-005 | Given a valid advisory candidate, C13/C15 integration cannot set top band or automated enforcement and requires verification/review. |
| C10-AC-006 | Given kill/expiry/source collector failure, keys/grants stop, observed system continues, pending evidence is incomplete/expired, and no raw fallback occurs. |
| C10-AC-007 | Given labelled positive/negative/ambiguous sample, published precision/FP/FN/abstention exactly match the fixture and gate activation. |
| C10-AC-008 | Scale/recovery meet C10 NFRs and prove restored evidence cannot be linked with destroyed keys or across scope. |

## 15. Component Test Matrix

| ID | Level | Fixture/precondition | Action | Expected result | Retained evidence |
|---|---|---|---|---|---|
| C10-CT-001 | Privacy contract | Raw values, per-record hashes, key, arbitrary maps, valid aggregate | Validate transfer | Prohibited rejected before persistence; aggregate accepted | Validator/store scan |
| C10-CT-002 | Field eligibility | Sensitive, free-text, low/high-cardinality fields | Evaluate | Exact denial/eligible outcomes without values in logs | Policy/audit report |
| C10-CT-003 | Positive/negative | Labelled matching/nonmatching high-cardinality aggregate fixtures | Compare | Advisory match or inconclusive nonmatch | Package goldens |
| C10-CT-004 | Minimum observation | Below/at/above count/entropy/uniqueness thresholds | Compare | Abstain or evaluate exactly at boundary | Threshold matrix |
| C10-CT-005 | Ambiguity/collision | Tied, multi-producer, collision-prone sketches | Compare | Abstain; all aggregate candidates/reason retained | Ambiguity report |
| C10-CT-006 | Scope isolation | Different environment/window/purpose/key policy | Compare | `FINGERPRINT_SCOPE_MISMATCH`; no link | Conflict/audit |
| C10-CT-007 | Key lifecycle | Normal close, expiry, kill, attempted reuse/export | Operate | Grant revoked/destroyed, reuse/export denied/audited | KMS/job evidence |
| C10-CT-008 | Fail-open | Collector/transfer/central analysis failure | Execute | Source system succeeds; incomplete/abstain; no raw fallback | Source/job timeline |
| C10-CT-009 | Confidence/enforcement | Advisory candidate alone and with other evidence | Reconcile/policy | Cap enforced; no top band/blocking input | C13/C14 result |
| C10-CT-010 | Evaluation | Labelled true/false/ambiguous/denied corpus | Calculate | Exact precision/FP/FN/abstention with version | Evaluation report |
| C10-CT-011 | Security | Cross-domain role, tampered collector/sketch, privacy violation | Execute | Deny/quarantine/revoke/alert/audit | Security exercise |
| C10-CT-012 | Load/recovery | 1M field-pair candidates, source budgets, restart/Region restore | Collect/analyze/recover | NFRs/overhead/exact counts; scope/expiry intact; key absent | Load/DR report |

## 16. Integration Obligations

- **INT-063 C01/C04/C05↔C10:** only Lane C enrolled compatible
  systems/environment/schema/bindings are compared; identity/scope gaps abstain.
- **INT-064 C06↔C10:** scheduled/admission/budget/fail-open/kill/finally/result
  workflows preserve lower priority and exact status.
- **INT-065 Source-local collector↔C10/C12:** field eligibility, key lifecycle,
  aggregate-only contract, privacy denial, signed transfer, and immutable storage
  prove no raw/per-record/key content.
- **INT-066 C10↔C13:** G1/G3/G5, ambiguity/coverage/expiry, advisory confidence cap,
  nonmatch semantics, and multi-source behavior are exact.
- **INT-067 C10↔C14/C15:** opaque evidence never enters blocking policy;
  review/labels/evaluation gate any accepted advisory use.
- **INT-068 C10↔C17:** UI/API shows advisory/cap/scope/window/support/ambiguity/
  expiry/coverage and sensitive metadata authorization.
- **INT-069 C10↔C18:** privacy incident/kill/key/source failure/load/cost/audit/
  retention/restore runbooks and gates pass.

## 17. Definition of Done

- Enrollment/privacy policy, source-local collector, key lifecycle, aggregate
  contract/validator, comparison/abstention, expiry/kill, evaluation, immutable
  package, and observability are implemented for approved pilot systems.
- C10 P0 requirements and C10-CT-001 through C10-CT-012 pass.
- INT-063 through INT-069 pass in privacy-approved nonproduction environments.
- Independent privacy/security review confirms threat model and no raw/per-
  record/reversible/key content; violation/kill exercise IDs are retained.
- Labelled evaluation publishes precision/FP/FN/abstention/ambiguity and approves
  the cap; no automated enforcement use exists.
- Load/source-overhead/fail-open/recovery reports meet NFRs and prove scope/key
  semantics after restore.
- Owner/kill/privacy/source failure/expiry/rollback/DR runbooks and alarms are
  exercised.

## 18. Implementation Notes

```text
contracts/schemas/opaque-lineage/
sidecars/opaque-observer/
services/opaque-enrollment/
workers/opaque-analyzer/
infra/lib/constructs/opaque-collection.ts
docs/threat-models/opaque-lineage.md
tests/fixtures/opaque-lineage/
tests/contract/opaque-lineage/
tests/integration/opaque-lineage/
tests/security/opaque-lineage/
tests/load/opaque-lineage/
```

Use Go 1.24 for a minimal source-local collector when a sidecar/job is possible,
Python 3.12 for aggregate analysis, TypeScript 5 for control/IaC. Prefer mature
privacy-reviewed HMAC/sketch primitives; custom cryptography is prohibited.
Specific statistical thresholds are versioned policy derived from labelled
evaluation, not embedded as universal constants.

Build order: threat model/contracts; synthetic privacy fixtures; source-local
aggregate/key/kill; comparison/abstention; C13/C15 cap/evaluation; pilot;
load/DR. Default is disabled; rollout per system/environment/enrollment and
rollback activates kill/expiry without code deployment.

## 19. Traceability

| Source decision | C10 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| Lane C opaque and advisory forever | C10-FR-001/006-012 | C10-CT-003-006/009 | INT-063/066/067/068 |
| No raw/reversible/low-cardinality evidence | C10-FR-002-005/009; C10-SEC-001-006 | C10-CT-001/002/007/011 | INT-065/069; privacy gate |
| Schedule/freshness/kill | C10-FR-013/015 | C10-CT-007/008 | INT-064/069 |
| Labelled precision before activation | C10-FR-014/016 | C10-CT-010 | INT-067; Lane C activation gate |
| Fail-open/scale/recovery | C10-NFR-001-004 | C10-CT-008/012 | INT-064/069 |


---

# 11-runtime-session-and-sidecar.md

# C11 Integration Runtime Session Controller and Sidecar PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C11 |
| Status | Approved for implementation |
| Launch phase | Runtime gate after deterministic collection works |
| Criticality | P0 for runtime-enabled applications; production hard-deny is a launch security gate |
| Primary owner | Runtime evidence team |
| Required approvers | Architecture, application/test platform, privacy/security, operations, trust engine |
| Upstream dependencies | C01, C04-C06, registered integration tests, AppConfig, integration account identity |
| Downstream dependencies | C12-C13, C15, C17-C18 |
| Authoritative sources | AWS architecture §10 and privacy gates; element-level v2 R6/R8 |

## 2. Purpose and Outcomes

C11 creates bounded, signed integration-test sessions and operates a fail-open
sidecar that emits metadata-only boundary evidence. It proves which authorized
paths executed for one test/artifact and supports structural corroboration. It
does not capture payloads or prove internal transformation. Production is
denied by independent template, IAM, AppConfig, organization, validator, and
sidecar-attestation controls.

Measurable outcomes:

- Zero raw/reversible payload, body, header, credential, SQL parameter, or
  unbounded attribute content persists in transport, logs, evidence, or errors.
- Tests begin only after every expected sidecar is `READY`; terminal completeness
  reconciles every expected monotonic sequence and closing manifest.
- Missing sidecar/sequence/manifest, event/byte limit, or storage failure yields
  `INCOMPLETE`/`TRUNCATED`, never silent sampling or confidence promotion.
- 100% of production enablement/submission attempts are technically denied and
  audited; application availability never depends on collector health.

## 3. Scope and Non-Goals

### In scope

- Runtime request authorization, signed expiring session/grant, AppConfig
  control, expected-sidecar readiness barrier, sidecar collection, CloudWatch
  ingress validation, explicit Kinesis ordering, S3 persistence, drain/
  completeness, finally disable, expiry kill switch, and reconciliation.
- Metadata schemas/field paths/types, operation/direction, trace/test/artifact
  identity, session-scoped irreversible fingerprints for approved fields, and
  counts/windows/checksums.

### Non-goals

- Production field-level/runtime lineage collection.
- Capturing raw/encoded payloads, request/response bodies, headers, credentials,
  SQL values, exception payloads, or arbitrary logs.
- Proving transformation/derivational correctness or proving unexecuted paths do
  not exist.
- Failing application containers or business tests solely because the collector
  cannot collect evidence.
- Converting an observed service interaction into lineage by itself.

## 4. Actors and Use Cases

| Actor/component | Use case |
|---|---|
| C06 | Request named tests/session, wait for readiness, start tests, drain/disable |
| Test Automation Service | Attest registered integration test run and expected workloads/sidecars |
| Application sidecar | Observe allowlisted boundary metadata and emit ordered evidence fail-open |
| AppConfig validator | Permit only signed, expiring integration configuration |
| Runtime validator | Reject prohibited/invalid evidence and assign ordered stream partition |
| C13 | Use only `COMPLETE` evidence for bounded structural corroboration |
| Operator/security | Kill/expire session, investigate gaps/privacy/production attempts, reconcile |

## 5. Component Boundary

### Owned behavior

- `RuntimeEvidenceSession`, grants/keys/AppConfig profile, sidecar protocol,
  runtime envelope validator, Kinesis routing/correlation, completeness manifest,
  disable/expiry/kill/reconciliation.

### Inputs

- Registered test run/scenarios, application/repository/commit/artifact digest,
  expected sidecars/versions, environment, schema/field allowlist, budgets,
  fingerprint policy, context/test mappings.

### Outputs

- Immutable validated runtime evidence/sidecar manifests/session manifest,
  terminal status/completeness, coverage/gaps/privacy/audit and C13 reference.

### Forbidden behavior

- Issuing a session without registered test/artifact/environment match.
- Starting tests before all expected compatible sidecars report `READY`.
- Logging/storing/transporting raw or reversible content.
- Enabling in production or accepting production account/OU/environment evidence.
- Silently sampling/truncating when event/byte limits are reached.
- Marking `COMPLETE` before durable evidence, sequence, manifest, checksum, and
  disable confirmation.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C11-FR-001 | C11 must create a session only for a registered integration test run whose application, repository, commit, artifact digest, expected workloads, and environment exactly match C05/Test Automation evidence. | P0 |
| C11-FR-002 | The signed session must include session/test/application/repository IDs, commit/digest, environment exactly `integration`, start/expiry, expected sidecars/minimum versions, schema/field allowlist, maximum events/bytes, fingerprint and sampling/truncation policies. | P0 |
| C11-FR-003 | AppConfig validators must reject unsigned/expired/malformed/mismatched sessions and every production account, OU, environment, application template, or target. | P0 |
| C11-FR-004 | The sidecar must attest integration environment/workload/artifact/session identity, validate the signed grant, register version/capabilities, heartbeat, and report `READY`; C11 must require all expected sidecars ready before test start. | P0 |
| C11-FR-005 | The sidecar may emit only schema URN/hash, field path/logical type/nullability/presence, protocol/operation/direction, trace/span/test IDs, commit/digest, instrumentation version, session-keyed fingerprint where approved, observation count/window, monotonic sequence, and checksum. | P0 |
| C11-FR-006 | Runtime contracts/validators must reject raw or encoded values, payload/body, request/response body, headers, credentials/auth material, SQL parameters, payload-bearing exception text, reversible tokens, free-form logs, and arbitrary/generic attributes. | P0 |
| C11-FR-007 | Fingerprints must use a session-scoped keyed HMAC issued only to active integration sidecars; sensitive/low-cardinality fields are denied and the key becomes inaccessible after close/expiry. | P0 |
| C11-FR-008 | Every sidecar must assign a monotonic sequence to accepted local evidence and finish with a closing manifest containing first/last sequence, emitted/dropped/rejected counts, bytes, aggregate checksum, and terminal time. | P0 |
| C11-FR-009 | Sidecar instrumentation must be asynchronous/fail-open for the application; collector/transport failure must not fail the application container or alter payload/latency beyond approved budget. | P0 |
| C11-FR-010 | Sidecar evidence must enter allowlisted CloudWatch lineage log groups; a validator must authenticate/validate/deduplicate and explicitly assign Kinesis partition `sessionId#sidecarId` to preserve per-sidecar order. | P0 |
| C11-FR-011 | The validator must reject prohibited/mismatched/out-of-budget envelopes before Kinesis/S3, retaining only sanitized hash/reason/audit; identical duplicates are idempotent and conflicting same sequence is a conflict. | P0 |
| C11-FR-012 | Evidence must persist immutably in C12 before drain completion; C11 must reconcile registration, heartbeat, every monotonic sequence, closing manifest, counts/bytes/checksum, persistence, and expected sidecar set. | P0 |
| C11-FR-013 | A missing sequence/sidecar/manifest, checksum mismatch, incompatible sidecar, event/byte cap, expired session, or incomplete persistence must produce `INCOMPLETE` or `TRUNCATED` and prevent confidence promotion. | P0 |
| C11-FR-014 | C06/C11 must disable AppConfig in a finally path after tests or any failure/cancel/expiry, and independent session expiry must revoke grants/keys even if orchestration/control services fail. | P0 |
| C11-FR-015 | C11 must implement production hard-deny by omitting collector from production templates where possible, no production ingestion permission, AppConfig validation deny, Organizations/account policy deny, sidecar environment attestation, registered-test grant condition, and validator deny/audit. | P0 |
| C11-FR-016 | C11 must reconcile active/expired sessions, AppConfig state, grants/keys, expected sidecars, evidence/manifests, and C13 consumption and remediate/alert discrepancies. | P0 |
| C11-FR-017 | C11 output must label runtime evidence `EXECUTED_BOUNDARY_METADATA`; it must not assign derivational confidence or assert an edge from interaction alone. | P0 |
| C11-FR-018 | Sampling is disabled for Tier-1 runtime evidence at launch; any future sampling mode must be explicit in session/coverage, cannot silently activate on overload, and cannot yield `COMPLETE` for omitted required events. | P1 |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C11-NFR-001 | Sidecar overhead must remain below 2% p95 CPU, 128 MiB memory, and 5 ms p95 boundary-call latency in the approved integration load fixture. | P0 |
| C11-NFR-002 | Runtime intake must handle a 10x incident-test storm and at least 10,000 events/second per Region with no silent loss; explicit truncation is allowed only by session cap. | P0 |
| C11-NFR-003 | Session control/intake must be 99.9% available monthly; expiry/production-deny remain effective during control-plane/Region failure. | P0 |
| C11-NFR-004 | 95% of terminal sessions must finish persistence/completeness/disable within five minutes after tests end; all must expire by signed deadline. | P0 |

## 7. Data and Durable State

`RuntimeEvidenceSession` contains all C11-FR-002 fields plus signing/key/grant/
AppConfig policy versions, state/transitions, sidecar registrations/heartbeats,
test start/end, sequence/manifests/persistence, status/reason, disable/expiry,
evidence/session-manifest references, and correlation.

`RuntimeEvidenceEnvelope` is closed (`additionalProperties: false`) and contains
session/sidecar/event/monotonic sequence, allowed context/field/operation fields,
observation/fingerprint where approved, observed time/instrumentation version,
and envelope checksum. It has no generic map.

`SidecarClosingManifest` includes identity/version/digest, sequence range,
attempted/emitted/rejected/dropped counts by reason, bytes, rolling checksum,
heartbeats, close time/status, and signature.

DynamoDB holds sessions/leases/idempotency/sequence/completeness/AppConfig state;
C12 S3 holds validated evidence and immutable manifests; AppConfig holds only
signed bounded session configuration; KMS/Secrets grants the ephemeral HMAC key.

## 8. Interfaces and Contracts

- `POST /v1/runtime-sessions` accepts registered test/context reference,
  expected sidecars, allowlist/budgets/policies, expected environment, and
  idempotency; returns session/status, never the HMAC key.
- `POST /v1/runtime-sessions/{id}/sidecars:register|heartbeat|close` uses workload
  identity and signed grant, exact sidecar/artifact/version.
- `POST /v1/runtime-sessions/{id}:testsStarted|testsEnded|cancel|kill|reconcile`
  requires expected state/version and authorized caller.
- Sidecar writes closed JSON lines to dedicated CloudWatch lineage log stream;
  subscription invokes validator. Validator returns accepted/rejected status
  operationally and writes Kinesis with explicit partition key.
- Kinesis consumer validates per-sidecar sequence/idempotency and writes C12
  partitioned S3 evidence/manifests.
- Events expose readiness, test barrier, sequence gap, truncation, disabled,
  terminal completeness, privacy/production denial, and reconciliation.

## 9. Processing and State Model

```text
REQUESTED -> ENABLING -> READY -> COLLECTING -> DRAINING
          -> DISABLED -> COMPLETE
```

Terminal alternatives: `INCOMPLETE`, `TRUNCATED`, `FAILED`, `EXPIRED`,
`CANCELLED`.

1. Validate registered test/context/integration environment and create signed
   session/expiry/budgets; issue scoped AppConfig/grants/key.
2. Sidecars attest/register/heartbeat. `READY` requires exact expected set and
   compatible versions/digest.
3. Authorize test start; collect allowed evidence asynchronously and sequence.
4. Validate/deduplicate/rate-budget/partition/persist evidence.
5. On test end/failure/cancel/expiry, enter drain; request closing manifests and
   wait only until deadline.
6. Execute disable/revoke/key-inaccessibility in finally and verify AppConfig.
7. Reconcile expected/received sequences/manifests/counts/checksums/persistence/
   disable and select terminal completeness.
8. Emit immutable session manifest to C13; only `COMPLETE` is eligible for
   structural corroboration.

## 10. Failure Semantics

| Code | Class | Required behavior |
|---|---|---|
| `SESSION_NOT_INTEGRATION` | `DETERMINISTIC_INVALID` security | Deny/alert/audit; no config/grant/key |
| `TEST_OR_ARTIFACT_MISMATCH` | `DETERMINISTIC_INVALID` | Reject session/sidecar; no ready |
| `SIDECAR_MISSING_OR_INCOMPATIBLE` | `INCOMPLETE` | Do not start or terminal incomplete by policy/deadline |
| `RUNTIME_EVIDENCE_PRIVACY_VIOLATION` | `DETERMINISTIC_INVALID` security | Reject before stream/store; sanitize, revoke/kill by policy |
| `SEQUENCE_CONFLICT_OR_GAP` | `CONFLICT`/`INCOMPLETE` | Preserve checksums/reconcile; no complete/promotion |
| `EVENT_OR_BYTE_LIMIT` | `INCOMPLETE` | Mark `TRUNCATED`; stop/close, no silent sampling |
| `TRANSPORT_OR_STORE_THROTTLED` | `TRANSIENT` | Bounded buffer/retry; on deadline incomplete, app unaffected |
| `DISABLE_UNCONFIRMED` | `INCOMPLETE` security-critical | Retry/expiry/alert; no complete |
| `PRODUCTION_ENABLE_OR_SUBMIT` | `DETERMINISTIC_INVALID` security | Multi-layer deny and immediate audit/alert |

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C11-SEC-001 | Session creation, AppConfig, sidecar, CloudWatch, validator, Kinesis, C12, and KMS grants must use mutually constrained test/workload/account/environment identities and least-privilege roles. | P0 |
| C11-SEC-002 | Runtime schema and validation must fail closed on all forbidden or unknown fields, encoded/reversible variants, payload-bearing error text, and generic maps; logs retain sanitized field path/hash/reason only. | P0 |
| C11-SEC-003 | Session HMAC keys must be short-lived/nonexportable where supported, scoped to active integration workloads/window, unavailable after terminal/expiry, and never stored in session/evidence/logs. | P0 |
| C11-SEC-004 | Production deny must be tested at template, IAM/SCP/resource policy, AppConfig validator, sidecar attestation, session grant, validator, and C12 bucket policy layers. | P0 |
| C11-SEC-005 | Session/config/grant/key/evidence access/kill/denial changes must be CloudTrail/data-event audited with sensitive-content redaction. | P0 |
| C11-SEC-006 | Runtime evidence must use TLS/private endpoints, KMS separated by environment/data class, retention/deletion, domain ABAC, and no broad production role access. | P0 |

## 12. Scale, Performance, and Availability

- Runtime Kinesis/control capacity is isolated from repository event queues.
  Partition key `sessionId#sidecarId` preserves local order and distributes
  sessions; hot-sidecar/session cap is explicit.
- Sidecar uses bounded in-memory/disk spool, backpressure, and fail-open drop
  accounting; it never blocks/changes application payload processing.
- CloudWatch subscription/validator/Kinesis/S3 quotas are load-tested above 10x
  expected integration storm. Event/byte cap yields `TRUNCATED` before service
  exhaustion.
- Expiry uses trusted service-side time and independent revocation path. Warm-
  Region recovery never enables a production grant and preserves terminal/
  incomplete evidence within RPO/RTO.

## 13. Observability

| ID | Signal | Dimensions/alert | Priority |
|---|---|---|---|
| C11-OBS-001 | Session state/latency/terminal | application/test/artifact/environment/status/reason | P0 |
| C11-OBS-002 | Sidecar expected/registered/ready/heartbeat/version | session/workload/sidecar; barrier/stale alert | P0 |
| C11-OBS-003 | Evidence accepted/rejected/duplicate/conflict | schema/field/reason/sidecar/session; privacy alert | P0 |
| C11-OBS-004 | Sequence/gap/manifest/checksum/completeness | sidecar/session/test; any gap alert | P0 |
| C11-OBS-005 | Event/byte/spool/drop/truncation | sidecar/session/account | P0 |
| C11-OBS-006 | AppConfig/grant/key/disable/expiry | state/age/account; unconfirmed/overdue alert | P0 |
| C11-OBS-007 | Production-deny attempts | layer/account/OU/workload/caller; immediate security alert | P0 |
| C11-OBS-008 | Sidecar/application overhead | version/archetype/CPU/memory/latency | P1 |

Metrics reconcile attempted = emitted + locally rejected + dropped-with-reason;
validator received = accepted + duplicate + rejected + conflict; accepted = S3
persisted + outstanding until deadline. C17 shows completeness and gaps.

## 14. Acceptance Criteria

| ID | Acceptance criterion |
|---|---|
| C11-AC-001 | Given a valid integration test/artifact, session becomes `READY` only after every expected compatible sidecar attests; premature test start is denied/audited. |
| C11-AC-002 | Given allowed metadata, per-sidecar sequences arrive through explicit partitioning, persist, reconcile to closing manifests/checksum, disable, and yield `COMPLETE`. |
| C11-AC-003 | Given raw/encoded payload, body/header/credential/SQL/error content, unknown field, or generic map, validator denies before stream/store and retained telemetry is sanitized. |
| C11-AC-004 | Given missing sequence/sidecar/manifest, conflicting sequence, cap, or store deadline, session is incomplete/truncated and C13 cannot promote confidence. |
| C11-AC-005 | Given test/application/sidecar/transport failure or cancel, application/test behavior is not altered by collector and finally disables/expires grants/key. |
| C11-AC-006 | Given enable/submission from every production-control layer, 100% are denied/audited and no runtime evidence reaches Kinesis/S3. |
| C11-AC-007 | Given complete runtime evidence for a candidate, C13 may strengthen structural confidence only; derivational remains unchanged absent allowed derivational evidence. |
| C11-AC-008 | The 10x storm/overhead/recovery tests meet C11 NFRs with exact sequence/count/byte reconciliation and no silent sample/loss. |

## 15. Component Test Matrix

| ID | Level | Fixture/precondition | Action | Expected result | Retained evidence |
|---|---|---|---|---|---|
| C11-CT-001 | State/contract | Valid/invalid sessions and all transitions | Validate/transition | Exact state machine/conditions/idempotency | Transition report |
| C11-CT-002 | Readiness | Expected, missing, wrong version/digest/environment sidecars | Register/start tests | Ready only exact set; premature denied | Session/timeline |
| C11-CT-003 | Privacy schema | Every forbidden key, encoded variant, error text, generic map | Emit/validate | Reject before Kinesis/S3; sanitized audit | Validator/store scan |
| C11-CT-004 | Sequence | Ordered, duplicate, out-of-order, gap, conflict sequences | Ingest/drain | Dedup/order/reconcile; gap/conflict incomplete | Sequence report |
| C11-CT-005 | Manifest | Matching/missing/mismatched counts/bytes/checksum | Close/drain | Complete only matching all | Session manifest |
| C11-CT-006 | Limits | At/over event and byte caps; transport pressure | Collect | Explicit truncate/incomplete, no silent sampling | Metrics/manifest |
| C11-CT-007 | Fail-open/finally | Sidecar/validator/stream/store/test failure and cancel | Execute | App unaffected; finally disable/revoke/expire; status exact | App/session/audit |
| C11-CT-008 | HMAC/privacy | Eligible, low-cardinality, sensitive field; key expiry/reuse | Fingerprint | Scoped irreversible only; denied fields/key reuse absent | Key/validator evidence |
| C11-CT-009 | Production hard-deny | Attempt each seven control layers | Enable/emit/store | Every attempt denied/audited; zero evidence persisted | Security test matrix |
| C11-CT-010 | Identity/idempotency | Duplicate/conflicting event/session/sidecar evidence | Execute | Same effect or conflict; no overwrite/cross-session mix | State/evidence history |
| C11-CT-011 | Confidence boundary | Complete/incomplete evidence on known transform | Reconcile | Structural-only promotion for complete; derivational unchanged | C13 result golden |
| C11-CT-012 | Load/recovery | 10x/10k events sec, hot sidecar, restart/Region failure | Execute/recover | NFRs, exact reconciliation, expiry/deny survive | Load/DR report |

## 16. Integration Obligations

- **INT-070 C01/C05/C06↔C11:** registered test/context/identity/digest/expected
  sidecars create one exact integration-only workflow/session.
- **INT-071 AppConfig↔C11:** signed validation, readiness enable, finally disable,
  expiry/kill, invalid and production targets pass.
- **INT-072 Sidecar↔CloudWatch/validator/Kinesis/C12:** allowed evidence,
  partition/order/dedup/gap/cap/privacy/persistence/manifests interoperate.
- **INT-073 C11↔C13:** complete versus incomplete/truncated and structural-only
  confidence semantics pass.
- **INT-074 C11↔C15/C17:** session/test/artifact/evidence/coverage/gaps/privacy/
  terminal/timeline are reviewable with ABAC.
- **INT-075 C11↔C18:** production hard-deny at every layer, audit/alarms/runbooks,
  secret/privacy scans, and kill exercises pass.
- **INT-076 C11↔C03/C06 replay/redrive:** duplicate/replay/stale callbacks never
  create a second session or re-enable terminal/expired collection.
- **INT-077 C11↔C18 load/DR:** 10x storm, quota/sidecar/control/Region failures,
  expiry and recovery meet NFR/RPO/RTO with no production exposure.

## 17. Definition of Done

- Session/control APIs, AppConfig profile/validators, Go sidecar, closed runtime
  schemas, CloudWatch validator, explicit Kinesis partitioning, S3 consumer,
  manifests/completeness/finally/expiry/reconciliation are implemented.
- C11 P0 requirements and C11-CT-001 through C11-CT-012 pass.
- INT-070 through INT-077 pass in production-shaped integration and denied
  production accounts.
- Privacy scans prove no forbidden/raw/reversible content across source, logs,
  stream, stores, metrics, traces, DLQ/quarantine, and errors.
- Production-deny matrix, fail-open, incomplete no-promotion, 10x storm,
  overhead, expiry, load, and DR reports meet every criterion.
- Session/privacy/sequence/manifest/kill/disable/production-attempt/restore
  runbooks and alarms are exercised with real IDs.

## 18. Implementation Notes

```text
contracts/schemas/runtime/
services/runtime-controller/
services/runtime-validator/
workers/runtime-evidence-consumer/
sidecars/lineage-observer/
infra/lib/constructs/runtime-sessions.ts
infra/lib/constructs/runtime-stream.ts
docs/runbooks/runtime-evidence/
tests/contract/runtime/
tests/integration/runtime/
tests/security/runtime/
tests/load/runtime/
```

Use Go 1.24 for the sidecar, TypeScript 5 for control/validator/IaC, Python 3.12
for large completeness/reconciliation if needed. Use AWS AppConfig validators,
CloudWatch Logs subscriptions, and Kinesis Data Streams; do not replace the
selected runtime path with a generic Kafka bus.

Build order: closed contracts/privacy tests; session/deny/AppConfig; sidecar
attestation/allowlist/HMAC/sequence/manifest/fail-open; validator/partition/
consumer; drain/finally/completeness; C13; load/security/DR. Default production
template omits the sidecar and all production paths deny grants/ingestion.

## 19. Traceability

| Source decision | C11 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| Bounded integration-only session/readiness | C11-FR-001 through C11-FR-004 | C11-CT-001/002 | INT-070/071 |
| Metadata-only/sequence/manifest/fail-open | C11-FR-005 through C11-FR-013/017 | C11-CT-003 through C11-CT-008, C11-CT-010, C11-CT-011 | INT-072/073/074 |
| Finally disable/expiry/production deny | C11-FR-014 through C11-FR-016; C11-SEC-001-006 | C11-CT-007/009 | INT-071/075/076 |
| Scale/overhead/recovery | C11-NFR-001 through C11-NFR-004 | C11-CT-012 | INT-077; runtime enterprise gate |


---

# 12-evidence-store-and-cache.md

# C12 Immutable Evidence Store and Analysis Cache PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C12 |
| Status | Approved for implementation |
| Launch phase | Foundation before collectors/workflows |
| Criticality | P0; evidence, packages, proposals, labels, and accepted manifests are the rebuild authority |
| Primary owner | Lineage data foundation team |
| Required approvers | Architecture, security/privacy, records governance, operations/DR, publication owners |
| Upstream dependencies | C01 shared contracts/identity, AWS KMS/S3/DynamoDB/Organizations/CloudTrail |
| Downstream dependencies | C02-C18 |
| Authoritative sources | AWS architecture §§6.10-6.12, 12-16; component design §§7, 9, 11 |

## 2. Purpose and Outcomes

C12 preserves the immutable facts from which lineage decisions and projections
can be reproduced. It provides encrypted, versioned, checksummed, retention-
governed S3 namespaces; strict `EvidenceReference` semantics; operational
DynamoDB indexes; content-addressed cache reuse; legal hold; integrity scanning;
cross-Region replication; and rebuild/restore evidence.

Measurable outcomes:

- 100% of material workflow outputs are immutable S3 objects referenced by
  version ID and SHA-256 before a stage is accepted.
- Identical content-addressed writes are idempotent; a key/content mismatch is
  a visible conflict and never overwrite.
- Accepted manifests/reviewer labels/evidence under retention cannot be mutated
  or deleted outside governed S3 Object Lock/legal-hold procedures.
- Neptune/OpenSearch and operational indexes can be deleted and rebuilt from
  accepted manifests/evidence within the four-hour RTO and 15-minute RPO.

## 3. Scope and Non-Goals

### In scope

- S3 evidence/data account buckets, prefixes/access points, versioning, KMS,
  public/TLS controls, S3 Object Lock, retention/lifecycle/legal hold, inventory,
  replication, integrity, backup/restore and access audit.
- `EvidenceReference`, immutable write/read/verify/list protocols.
- Content-addressed analysis/native/agent/schema/cache records and lookup indexes.
- DynamoDB metadata/idempotency/cache/pointer indexes with PITR; TTL only for
  temporary leases/session operational rows.

### Non-goals

- Being the active graph/search query engine (C16/C17).
- Treating DynamoDB cache/index metadata as evidence authority.
- Allowing a cache result to bypass component/version/authorization validation.
- Storing raw integration/production payloads or arbitrary unbounded logs.
- Deleting retained evidence because a projection or proposal is superseded.

## 4. Actors and Use Cases

| Actor/component | Use case |
|---|---|
| Collector/analyzer | Write attempt-scoped evidence/package and receive immutable reference |
| C06/C13-C16 | Verify input/result checksum/version before state transition |
| Cache consumer | Look up exact content identity and reuse an authorized verified result |
| Reviewer/auditor | Read allowed evidence/proposal/label/manifest history |
| Records administrator | Apply retention/legal hold and governed release |
| Operator | Detect corruption/replication lag, restore/rebuild indexes/projections |

## 5. Component Boundary

### Owned behavior

- Evidence/cache physical/contract storage, immutable-write protocol, references,
  metadata indexes, access boundaries, lifecycle/integrity/replication/restore.

### Inputs

- Typed content bytes/stream, schema/version, expected SHA-256/length, business
  identity/cache key, producer/run/attempt, data/retention/access class.

### Outputs

- Verified `EvidenceReference`, cache lookup/result, integrity/access/replication/
  retention events, rebuild manifests and restore evidence.

### Forbidden behavior

- Last-write-wins to an immutable business/cache key.
- Returning an unverified object without version/checksum/schema/access checks.
- Applying TTL to evidence, proposals, labels, accepted manifests, graph pointers,
  eligibility history, or required audit.
- Granting one collector writer access to another component/data-class prefix.
- Treating mutable Neptune/OpenSearch contents as recovery truth.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C12-FR-001 | C12 must provide separate governed namespaces/access points for raw allowed source metadata, normalized evidence, analysis/native/agent/opaque/runtime packages, proposals, reviewer labels, accepted manifests, graph exports, and content-addressed caches. | P0 |
| C12-FR-002 | Every durable bucket must enable versioning, KMS encryption, TLS-only policy, public-access block, ownership enforcement, CloudTrail/S3 access events, lifecycle, replication hooks, and S3 Object Lock where retention authority requires. | P0 |
| C12-FR-003 | Every stored artifact must have an `EvidenceReference` with bucket/key/version, SHA-256, bytes, media/compression, schema ID/version, evidence/provenance/producer versions, artifact/effective version, data/retention class, KMS class, run/attempt, and creation identity/time. | P0 |
| C12-FR-004 | Immutable write must stage attempt-scoped content, validate schema/privacy/size, compute/verify SHA-256, persist, read/HEAD verify version/length/checksum/KMS, then conditionally register business identity/reference before success. | P0 |
| C12-FR-005 | Identical business/cache identity and content checksum must return the verified existing reference; different checksum under the same immutable identity must create `CONTENT_IDENTITY_CONFLICT` and never overwrite. | P0 |
| C12-FR-006 | Readers must fetch by exact version ID/reference, revalidate authorization/schema/checksum/length, and reject mutable alias/latest reads for workflow/trust/publication decisions. | P0 |
| C12-FR-007 | Accepted manifests, material review labels/decisions, publication audit, and governed evidence must use S3 Object Lock retention; corrections/supersession create new objects and links. | P0 |
| C12-FR-008 | Retention/lifecycle/legal hold must be data-class/policy/version driven, auditable, conflict-checked against active hold, replication, investigation, and accepted-graph rebuild dependencies before expiration/deletion. | P0 |
| C12-FR-009 | Content-addressed cache keys must include every determinant/version declared by the producing component and map to immutable verified content; C12 must not invent or omit producer key parts. | P0 |
| C12-FR-010 | Cache lookup must verify organization/domain authorization, key schema/version, producer/model/analyzer/policy compatibility, object integrity, expiry/deprecation, and data-class constraints before returning a result. | P0 |
| C12-FR-011 | Racing first writers must use a conditional cache/business record; one identical result wins idempotently, while differing results are preserved as conflict and the key is quarantined. | P0 |
| C12-FR-012 | C12 must provide immutable manifests for large collections with entry reference/checksum/count, manifest checksum, deterministic order, page/shard metadata, and completeness. | P0 |
| C12-FR-013 | Integrity scanning must use S3 Inventory/version/object metadata and sampled/full checksums by data class, detect missing/version/KMS/length/checksum/retention/replication anomalies, and quarantine corrupt references. | P0 |
| C12-FR-014 | Cross-Region replication must preserve versions, retention/legal holds, KMS class, metadata, and checksums; replication status/lag must be queryable and gate DR readiness. | P0 |
| C12-FR-015 | Operational DynamoDB tables must use KMS, PITR, deletion protection, conditional writes, backups/replication as designed; TTL is allowed only for explicitly temporary leases/session records after immutable terminal evidence exists. | P0 |
| C12-FR-016 | C12 must support rebuilding cache/lookup/operational indexes and C16 graph/search projections from immutable manifests without modifying source artifacts. | P0 |
| C12-FR-017 | A deletion/retention release/legal-hold action must require scoped records authorization, object/version manifest, dry-run impact, reason, policy, approval, audit, and post-action reconciliation. | P0 |
| C12-FR-018 | Storage formats/compression may evolve only via versioned schemas/readers/migration manifests; original retained bytes and provenance remain accessible according to policy. | P1 |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C12-NFR-001 | A verified small-object write/read must complete within 2 seconds p95; 99% of 1 GiB streaming artifacts within 10 minutes under production-like network/load. | P0 |
| C12-NFR-002 | C12 must sustain aggregate 5 GiB/second write and 10 GiB/second read bursts plus 10,000 object operations/second without cross-prefix starvation at validated AWS quotas. | P0 |
| C12-NFR-003 | Evidence durability uses S3 service guarantees; control/index availability must be 99.95% monthly and failure must not accept unverified stage/publication results. | P0 |
| C12-NFR-004 | Cross-Region retained evidence/index recovery must meet 15-minute RPO/four-hour RTO; full projection rebuild performance is governed by C16 but source availability/integrity is C12's gate. | P0 |

## 7. Data and Durable State

Recommended key structure:

```text
s3://lineage-evidence-<env>/<data-class>/<organization>/<component>/
  <schema-major>/<business-id-hash>/<content-sha256>/<artifact-name>
```

Attempt staging uses a distinct write-only prefix and is promoted by immutable
reference registration, not object copy overwrite. Accepted manifests use a
graph-version namespace under S3 Object Lock. Reviewer labels use immutable
proposal/edge/decision IDs. Graph exports are derived and rebuildable but
checksummed/versioned for publication verification.

`EvidenceMetadataRecord` mirrors reference/search fields, business/cache key,
producer/run/attempt, access/retention/hold, replication/integrity/status, prior/
supersedes links, and checksums. It is an index; object/version remains content
authority.

`CacheRecord` holds typed key schema/version/parts hash, producer/version/data
class, object reference/checksum, state `WRITING|ACTIVE|CONFLICT|DEPRECATED|
CORRUPT|EXPIRED`, lease/attempt and timestamps. TTL only applies to `WRITING`
lease, not active result/history.

## 8. Interfaces and Contracts

- `POST /v1/evidence:writes` creates an upload/write intent with schema,
  expected identity/checksum/length, class and idempotency; returns scoped
  attempt location/credentials or streaming endpoint.
- `POST /v1/evidence/writes/{id}:commit` verifies object/version/checksum/schema/
  privacy and conditionally registers; returns `EvidenceReference`.
- `POST /v1/evidence:verify` accepts reference and expected contract/access;
  returns exact status/integrity/retention/replication metadata.
- `GET /v1/evidence/{reference}` or signed scoped access requires exact version,
  purpose, actor/domain, and logs access. Broad presigned URLs are prohibited.
- `POST /v1/cache:lookup|put` uses typed cache key contract, authorization,
  expected producer versions, and immutable result reference/checksum.
- `POST /v1/manifests:validate`, integrity/replication/rebuild/list APIs operate
  over immutable references with pagination/S3 result manifests.

All service responses use references, not large content bodies. Direct S3 roles
are preferred for high-volume component-specific writes with bucket-policy
conditions enforcing exact prefix/KMS/schema metadata and commit registration.

## 9. Processing and State Model

### Immutable write

```text
INTENT -> UPLOADING -> VALIDATING -> OBJECT_VERIFIED
       -> REGISTERING -> ACTIVE
```

Alternative: `DUPLICATE`, `CONFLICT`, `QUARANTINED`, `CORRUPT`, `FAILED`.

1. Authorize producer/data class/business identity and validate intent.
2. Create scoped attempt/lease; upload with exact KMS/metadata/limits.
3. Validate closed contract/privacy/content and compute/compare SHA-256/bytes.
4. HEAD/read exact S3 version; verify encryption/retention/metadata/checksum.
5. Conditional metadata/business/cache registration decides active/duplicate/
   conflict. Return only verified reference.
6. Integrity/replication/lifecycle processes continuously reconcile objects and
   indexes; staging garbage expires only after proving no active reference.

### Cache lookup

Validate key schema/parts/producer compatibility, actor/domain/data class,
record state/expiry, then exact object verification. Integrity failure marks
cache corrupt and returns miss/error according to producer policy; it never
returns unverified bytes.

## 10. Failure Semantics

| Code | Class | Required behavior |
|---|---|---|
| `EVIDENCE_SCHEMA_OR_PRIVACY_INVALID` | `DETERMINISTIC_INVALID` | Quarantine/reject; sanitized reason; no active ref |
| `OBJECT_CHECKSUM_OR_LENGTH_MISMATCH` | `DETERMINISTIC_INVALID` | Mark corrupt/quarantine; block stage/cache/publication |
| `CONTENT_IDENTITY_CONFLICT` | `CONFLICT` | Preserve versions/checksums; no overwrite; owner alert |
| `OBJECT_VERSION_NOT_FOUND` | `INCOMPLETE` | Reject read/result; integrity/recovery investigation |
| `ACCESS_OR_DATA_CLASS_DENIED` | `DETERMINISTIC_INVALID` security | Deny/audit; no existence leakage beyond policy |
| `S3_DYNAMODB_KMS_THROTTLED` | `TRANSIENT` | Bounded retry/idempotent attempt; no premature success |
| `REPLICATION_LAG_OR_FAILURE` | `INCOMPLETE` DR | Alert/gate failover/retention action by policy |
| `RETENTION_OR_LEGAL_HOLD_CONFLICT` | `CONFLICT` | Deny delete/release; record governing hold/policy |
| `CACHE_RECORD_CORRUPT_OR_CONFLICT` | `CONFLICT` | Quarantine key; force producer recompute/review, no result |

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C12-SEC-001 | Evidence/data account buckets/tables/keys must be isolated from application/control/query accounts with Organizations-scoped roles, private endpoints, TLS-only, public block, KMS separation by environment/data class, and explicit access points/prefixes. | P0 |
| C12-SEC-002 | Producer roles must be write-only/read-minimal to exact attempt prefixes and KMS context; reader roles must be purpose/domain/data-class scoped; no wildcard cross-class data-plane permission. | P0 |
| C12-SEC-003 | S3 Object Lock/retention/legal hold and destructive actions must use records-governance role separation, MFA/break-glass where required, approval/audit, and deny ordinary administrators. | P0 |
| C12-SEC-004 | Closed schemas/privacy validators must reject raw production/integration payloads, secrets/credentials, arbitrary attributes, and payload-bearing logs before active evidence registration. | P0 |
| C12-SEC-005 | CloudTrail management/S3 data events and DynamoDB/KMS access audit must identify actor/purpose/object version/checksum/decision; security logs cannot copy sensitive content. | P0 |
| C12-SEC-006 | Malware/content scanning for source archives uses isolated readers and records verdict/checksum without weakening Object Lock or exposing contents broadly. | P1 |

## 12. Scale, Performance, and Availability

- S3 prefixes distribute by organization/component/business hash/content hash;
  no date-only hot prefix or shared mutable object.
- Multipart streaming handles large packages; per-component quotas/cost tags and
  lifecycle tiers prevent runtime/native bursts from starving manifests.
- DynamoDB keys distribute cache/idempotency/index load and use adaptive/on-
  demand/provisioned capacity validated under event spikes. Large listings use
  S3 Inventory/Glue/Athena or manifest workers, not table scans on hot paths.
- Versioned KMS keys/aliases and replication roles are pre-created in warm
  Region. Failover reads only objects whose replication/integrity/retention
  status meets policy.
- Cost dashboards cover bytes/objects/versions/replication/retrieval/KMS by
  component/data class/domain; cost pressure cannot disable retention silently.

## 13. Observability

| ID | Signal | Dimensions/alert | Priority |
|---|---|---|---|
| C12-OBS-001 | Write/read/verify latency/status/bytes | component/class/schema/Region/KMS | P0 |
| C12-OBS-002 | Duplicate/conflict/corrupt/missing | business/cache key class/producer/owner | P0 |
| C12-OBS-003 | Integrity scan findings | bucket/prefix/schema/version/anomaly | P0 |
| C12-OBS-004 | Replication lag/failure/RPO readiness | class/bucket/Region; DR alert | P0 |
| C12-OBS-005 | Retention/hold/lifecycle/delete actions | policy/class/actor/result; audit alert | P0 |
| C12-OBS-006 | Cache hit/miss/conflict/deprecated/corrupt | producer/key schema/version/domain | P0 |
| C12-OBS-007 | Access denied/unusual reads/data class | actor/purpose/prefix/domain | P0 |
| C12-OBS-008 | Storage/KMS/transfer cost/quota | component/class/domain/Region | P1 |

Inventory-to-index and accepted-manifest-to-object reconciliation produce signed
reports. Any missing accepted-manifest dependency or unexpected mutable version
is a launch/operational defect.

## 14. Acceptance Criteria

| ID | Acceptance criterion |
|---|---|
| C12-AC-001 | Given valid content, write commits only after exact object version/schema/KMS/length/SHA-256/read-back validation and returns a complete `EvidenceReference`. |
| C12-AC-002 | Given identical business/cache key/content twice, one active object/reference is reused; given different content, conflict preserves both and no overwrite occurs. |
| C12-AC-003 | Given an accepted manifest/reviewer label under retention/legal hold, mutation/deletion by ordinary/admin/producer roles fails and immutable audit remains. |
| C12-AC-004 | Given corrupted/missing/version-mismatched content, reader/cache/stage/publication rejects it and integrity alert/recovery path activates. |
| C12-AC-005 | Given unauthorized cross-domain/data-class access or payload-bearing invalid artifact, C12 denies before active registration/read and emits sanitized audit. |
| C12-AC-006 | Given expired temporary lease versus durable record, TTL removes only the lease after terminal evidence; no durable evidence/decision/pointer is TTL eligible. |
| C12-AC-007 | Given primary projection/index loss, immutable accepted manifests/evidence rebuild operational indexes and C16 projections with matching counts/checksums. |
| C12-AC-008 | Load/replication/failover/restore meets C12 NFR/RPO/RTO with exact object/version/checksum/retention reconciliation. |

## 15. Component Test Matrix

| ID | Level | Fixture/precondition | Action | Expected result | Retained evidence |
|---|---|---|---|---|---|
| C12-CT-001 | IaC/security | Synthesized buckets/tables/keys/access points | Assert policies/config | Version/KMS/TLS/public/Object Lock/PITR/deletion/least privilege exact | CDK/policy report |
| C12-CT-002 | Write/read | Valid small/large/streaming artifacts | Stage/commit/read verify | Exact reference/version/bytes/SHA-256/schema | Golden refs/content hashes |
| C12-CT-003 | Idempotency/conflict | Same identity+same/different content racing | Commit | Duplicate reuse or conflict, never overwrite | Object/index histories |
| C12-CT-004 | Contract/privacy | Invalid schema, raw payload, secret, generic map, oversized | Commit | Reject/quarantine before active registration; sanitized | Validator/store/log scan |
| C12-CT-005 | Access isolation | Cross-component/domain/class/account roles | Put/get/list/delete/KMS | Only exact allowed actions; deny/audit no leakage | IAM/access analyzer/audit |
| C12-CT-006 | Retention/hold | Locked manifest/label/evidence and roles | Mutate/delete/release/expire | Governed deny/approved procedure only | S3 retention/audit |
| C12-CT-007 | Cache | Exact/missing/version-changed/deprecated/corrupt/conflict keys | Lookup/put | Valid hit or exact miss/error/quarantine | Cache matrix |
| C12-CT-008 | Integrity | Tamper metadata/version, remove/corrupt replica/index | Scan/read | Detection, quarantine, alert/rebuild; no bad read | Integrity report |
| C12-CT-009 | TTL/lifecycle | Lease/session temp plus all durable classes | Advance time/lifecycle | Only eligible temp/staged objects removed under proof | Inventory before/after |
| C12-CT-010 | Replication/legal hold | Versions/retention/hold across Regions | Replicate/failover | Metadata/checksum/hold preserved; lag gates failover | Replication report |
| C12-CT-011 | Rebuild | Delete cache/index and empty Neptune/OpenSearch | Rebuild from manifests | Counts/checksums/active versions exact | Rebuild report |
| C12-CT-012 | Load/DR | 5/10 GiB sec bursts, 10k ops sec, throttle/Region failure | Write/read/recover | NFR/RPO/RTO, fairness, no unverified success | Load/DR report |

## 16. Integration Obligations

- **INT-078 C01/C02-C11↔C12:** every producer contract writes/reads only its
  authorized data class and complete `EvidenceReference`; privacy/schema invalid
  content fails closed.
- **INT-079 C06↔C12:** stage starts/results verify exact versions/checksums;
  duplicate/redrive/stale attempts cannot overwrite authority.
- **INT-080 C08/C09/C10↔C12:** content-addressed analysis/agent/opaque cache keys,
  first writer/conflict/invalidation/auth and reproducibility interoperate.
- **INT-081 C11↔C12:** runtime validator is the only allowed path; sequence/
  manifests/retention and production deny prevent raw/unapproved writes.
- **INT-082 C12↔C13/C15:** evidence/proposals/labels read exact immutable versions;
  corrections/supersession preserve history.
- **INT-083 C12↔C16/C17:** accepted manifests/graph exports/pointers/projection
  rebuild and evidence ABAC/access audit pass.
- **INT-084 C12↔C18 security/records:** IAM/KMS/private access/Object Lock/legal
  hold/retention/delete/audit/privacy scans and runbooks pass.
- **INT-085 C12↔C18 operations:** integrity/replication/load/cost/backup/restore/
  index+projection rebuild meet RPO/RTO/exact reconciliation.

## 17. Definition of Done

- IaC creates production-shaped evidence/data account buckets, access points,
  KMS, Object Lock, retention/lifecycle/replication/inventory, DynamoDB state,
  APIs/protocols, validators, integrity/rebuild jobs, and dashboards/alarms.
- C12 P0 requirements and C12-CT-001 through C12-CT-012 pass.
- INT-078 through INT-085 pass against all production-shaped producers/readers.
- Security/records evidence proves no wildcard cross-class access, privacy-
  invalid active object, unauthorized retention/hold bypass, sensitive audit,
  or improper TTL.
- Load/replication/integrity/failover/restore/rebuild reports meet NFR/RPO/RTO
  and match object/version/checksum/count/retention/active graph evidence.
- Conflict/corruption/access/retention/legal-hold/replication/KMS/rebuild/DR
  runbooks and alarms are exercised with real artifact IDs.

## 18. Implementation Notes

```text
contracts/schemas/evidence/
services/evidence-registry/
services/evidence-validator/
workers/evidence-integrity/
workers/evidence-rebuild/
infra/lib/stacks/data-stack.ts
infra/lib/constructs/evidence-store.ts
infra/lib/constructs/control-tables.ts
docs/runbooks/evidence-store/
tests/contract/evidence/
tests/integration/evidence/
tests/security/evidence/
tests/load/evidence/
tests/chaos/evidence/
```

Use TypeScript 5/CDK for data/control APIs/IaC and Python 3.12 for integrity/
large manifest/rebuild workers. Prefer S3 checksum headers plus independently
computed SHA-256 recorded in the closed contract; ETag is not a content checksum.
Enable S3 Object Lock at bucket creation because it cannot be retrofitted safely
as an assumption.

Build order: schemas/reference; secure immutable stores/tables; write/read/
verify; per-component prefixes; cache; retention/hold; replication/integrity;
rebuild; load/security/DR. Migration uses new versioned prefix/manifests; never
in-place rewrite of retained evidence.

## 19. Traceability

| Source decision | C12 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| S3 immutable truth, projections rebuildable | C12-FR-001-008/012-016 | C12-CT-001-006/008/010/011 | INT-078/079/082/083/085 |
| Content-addressed reuse/idempotency | C12-FR-004-006/009-011 | C12-CT-002/003/007 | INT-080 |
| Privacy/security/retention/legal hold | C12-FR-007/008/017; C12-SEC-001-006 | C12-CT-004-006/009 | INT-081/084 |
| Enterprise load/integrity/DR | C12-FR-013-016; C12-NFR-001-004 | C12-CT-008/010-012 | INT-085; resilience/DR gate |


---

# 13-reconciliation-verification-confidence.md

# C13 Reconciliation, Verification, and Two-Axis Confidence PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C13 |
| Status | Approved for implementation |
| Launch phase | Trust gate before proposal/review |
| Criticality | P0; no collector candidate may reach proposal/publication without C13 outcome |
| Primary owner | Lineage trust and reconciliation team |
| Required approvers | Architecture, analyzer/native/runtime owners, data governance, product/review |
| Upstream dependencies | C01, C05, C07-C12, C15 calibration policy/labels |
| Downstream dependencies | C14-C17, C18 |
| Authoritative sources | Element-level v2 R5-R7 and residual risks; AWS architecture §§11-12, 17-18 |

## 2. Purpose and Outcomes

C13 resolves cross-lane identity, deduplicates candidates without erasing
conflict, applies verification gates G1-G5, returns dropped candidates to named
holes, calculates coverage, and assigns independent structural confidence and
derivational confidence under a calibrated versioned policy. It produces a
deterministic, evidence-complete candidate set for human proposal/review.

Measurable outcomes:

- Every input candidate has a terminal accept/drop/downgrade/conflict/unresolved
  outcome with gate/evidence/reason; zero silent disappearance.
- G1, G2, or G4 failure drops the candidate and opens/returns a hole; G3 or G5
  failure downgrades/flags but does not erase an otherwise real relationship.
- Runtime/OTel evidence never raises derivational confidence; sole-LLM evidence
  never reaches the top band; incomplete runtime never promotes either axis.
- Until labelled calibration exists, both axes render `UNCALIBRATED`; no
  collapsed confidence number is emitted or displayed.

## 3. Scope and Non-Goals

### In scope

- Candidate/evidence normalization and canonical identity/version reconciliation.
- Exact duplicate merge, provenance union, conflict/coverage/hole accounting.
- G1 existence, G2 evidence anchoring, G3 type compatibility, G4 reachability,
  G5 native/opaque oracle agreement with applicability/reason.
- Drop/downgrade/review-routing rules and deterministic output.
- Independent confidence policies, caps, calibration, reason/evidence and
  correction feedback aggregation.

### Non-goals

- Generating missing candidates; verification gate recall is zero by
  construction because a gate cannot test an edge that was never proposed.
- Using one model to judge another model's transform prose as correctness.
- Approving/correcting proposals (C15) or publishing graph (C16).
- Treating human acceptance as execution evidence; it is governed accepted state
  and a calibration label.
- Averaging conflicting evidence or confidence into one float.

## 4. Actors and Use Cases

| Actor/component | Use case |
|---|---|
| C07-C11 | Submit versioned candidate/evidence packages and explicit gaps |
| C08/C09 | Receive gate-dropped candidate as same/open hole with reason |
| C15 reviewer | Inspect gates/evidence/conflicts/coverage and correct proposal |
| Confidence policy owner | Calibrate bands from labels and activate versioned policy |
| C14 | Select deterministic-only/blocking-eligible inputs and freshness behavior |
| Operator | Reconcile input/outcome counts, investigate gate/confidence drift |

## 5. Component Boundary

### Owned behavior

- `VerifiedLineageCandidateSet`, verification policy/gate results, normalized
  conflicts, coverage, returned holes, confidence-axis objects and calibration.

### Inputs

- Immutable C07 native, C08 deterministic, C09 agent, C10 opaque, C11 runtime
  packages; C01 registry, C05 context/determinants, schemas/catalog, accepted
  graph/base version; C15 label/calibration manifests.

### Outputs

- Accepted/downgraded candidates, dropped candidates/returned holes, conflicts,
  unresolved/coverage, gate details, structural/derivational confidence,
  proposal-input manifest/checksum and metrics.

### Forbidden behavior

- Selecting a canonical endpoint when C01 remains ambiguous.
- Keeping a candidate that fails G1, G2, or applicable G4 at low confidence.
- Dropping solely for G3/G5 mismatch without preserving the structurally real
  candidate and conflict/downgrade.
- Promoting from incomplete/stale/mismatched runtime evidence.
- Allowing an LLM self-score, OTel execution, or bulk acceptance to set
  derivational `VERIFIED`.
- Emitting `confidence`, `score`, or a collapsed float in the edge contract.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C13-FR-001 | C13 must validate every input package/reference/schema/checksum and pin C01/context/base graph/verification/confidence/calibration versions before processing. | P0 |
| C13-FR-002 | C13 must resolve source/target/environment/effective version and preserve `IDENTITY_AMBIGUITY`, `VERSION_MISMATCH`, and `SCHEMA_MISMATCH` as conflicts rather than forced merges. | P0 |
| C13-FR-003 | Exact candidates may deduplicate only when canonical source/target, level, environment/effective version, path guard, and transformation identity are compatible; provenance/evidence/determinants/gates are unioned without loss. | P0 |
| C13-FR-004 | Structurally or derivationally disagreeing candidates must remain linked conflict claims; C13 must not average them or discard lower-precedence evidence silently. | P0 |
| C13-FR-005 | G1 existence must verify both endpoint URNs and effective schema/catalog versions resolve; G1 failure must drop the candidate and open/return a hole. | P0 |
| C13-FR-006 | G2 evidence anchoring must re-read every cited immutable file:line/span/fact, verify version/path/range/quote hash and that cited symbols support the asserted mapping; missing/stale/mismatched required citation must drop and return a hole. | P0 |
| C13-FR-007 | G3 type compatibility must apply versioned logical-type/nullability/shape/allowed-conversion policy; failure must retain relationship only as downgraded/type conflict requiring review, not silently drop. | P0 |
| C13-FR-008 | G4 reachability must verify applicable deterministic/agent candidates against C08's pinned call/data-flow/path facts; applicable failure must drop and return a hole. | P0 |
| C13-FR-009 | G5 oracle agreement must compare overlapping candidate claims with C07 exact native or qualified C10 advisory evidence by matching artifact/environment/schema/window; disagreement/absence must downgrade/flag, not drop solely. | P0 |
| C13-FR-010 | Gate applicability must be typed by provenance/candidate class; `NOT_APPLICABLE`, `NOT_OBSERVED`, `PASS`, `FAIL_DROP`, and `FAIL_DOWNGRADE` require a reason/evidence and cannot be used to bypass a required gate. | P0 |
| C13-FR-011 | G1/G2/applicable G4 failure must create a `DroppedCandidate` and restore/open the stable hole with verification reason; counts must reconcile and dropping must never be silent. | P0 |
| C13-FR-012 | G3/G5 failures and governed cheap unsound heuristics (argument/input mismatch, near-identical sibling field) must route downgrade/conflict/human review with explicit risk. | P0 |
| C13-FR-013 | C13 must publish that gate recall is zero by construction and report candidate-conditional gate precision/outcomes separately from lineage recall/coverage. | P0 |
| C13-FR-014 | Every retained edge must carry separate structural confidence and derivational confidence objects with band, reasons, evidence, policy/calibration versions, and calibrated flag; a shared numeric score is prohibited. | P0 |
| C13-FR-015 | Structural confidence may be influenced only by version-matched deterministic reachability, native execution/plan, complete integration runtime execution, deployment binding, and qualified boundary fingerprint agreement under policy. | P0 |
| C13-FR-016 | Derivational confidence may be influenced only by exact C07 native plan/dbt compiled mapping, deterministic transform proof, governed contract test, qualified C10 agreement, and calibrated review labels; OTel/runtime execution must not raise it. | P0 |
| C13-FR-017 | Sole-LLM provenance must remain below the top band on both axes; only independent qualifying oracle/multi-source evidence under calibrated policy may remove the sole-source cap. | P0 |
| C13-FR-018 | Incomplete, truncated, stale, mismatched-artifact/environment, or expired evidence must not promote confidence; it must appear in coverage/gaps. | P0 |
| C13-FR-019 | Until a confidence policy is calibrated against material per-edge C15 labels, all bands must be `UNCALIBRATED`; activation requires corpus/gate metrics, approval, versioning, canary, rollback, and quarterly distribution publication. | P0 |
| C13-FR-020 | C13 must reconcile input candidates, exact duplicates, retained/downgraded/dropped/conflict edges, open/closed/reopened holes, evidence sources, and coverage by application/archetype/provenance. | P0 |
| C13-FR-021 | Identical immutable inputs/policies must produce byte-identical candidate sets/gate/confidence/coverage/checksum; policy change creates a new version and preserves prior result. | P0 |
| C13-FR-022 | C13 should support counterfactual confidence-policy preview against the labelled corpus and current proposals without changing active proposal/graph state. | P1 |

### Gate matrix

| Gate | Claim tested | Fail effect | Not applicable example |
|---|---|---|---|
| G1 | Both canonical versioned endpoints exist | drop/open hole | none for an edge candidate |
| G2 | Required evidence is immutable, current, quote/fact anchored | drop/open hole | Native engine facet uses facet/checksum validation rather than source lines |
| G3 | Source/target logical types/shapes are compatible | downgrade/conflict | Type unknown is `NOT_OBSERVED`, never pass |
| G4 | Applicable source-code path reaches the sink | drop/open hole | Exact native engine plan has native plan proof, not C08 call graph |
| G5 | Independent oracle/opaque overlap agrees | downgrade/conflict | No eligible overlap is `NOT_OBSERVED`, not failure/pass |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C13-NFR-001 | A standard repository candidate package (up to 100k candidates) must reconcile/verify within five minutes p95; a 10M-edge application baseline within two hours at approved Batch scale. | P0 |
| C13-NFR-002 | C13 must scale horizontally without non-deterministic merge ordering and support 500 concurrent repository verification jobs under C06 quotas. | P0 |
| C13-NFR-003 | Trust output/policy service must be 99.9% available monthly; failure leaves immutable inputs/base graph unchanged and does not create a proposal. | P0 |
| C13-NFR-004 | 100 repeated/parallel/cross-Region runs of identical inputs/policy must have zero checksum divergence. | P0 |

## 7. Data and Durable State

`VerificationGateResult` contains gate/version/applicability/status, claim/input,
evidence refs/checksums, observed values, reason, effect, time, verifier version.

`ConfidenceAxis` contains `axis`, band (`UNCALIBRATED` or calibrated enum),
calibrated flag, policy/calibration version, evidence refs, positive/negative/
missing/stale reasons and applicable caps. It has no generic float.

`LineageConflict` typed variants: identity, structure, derivation, type, version,
schema, evidence, oracle. It records all claims/provenance/evidence and
resolution status/rule/reviewer if later resolved.

`CoverageReport` contains expected/analyzed/source/sink/field/candidate counts,
package/evidence completeness, exact duplicates, gates, retained/downgraded/
dropped/conflicts, holes opened/closed/reopened, unsupported/unobserved/stale,
and denominators by provenance/archetype/application/domain.

`VerifiedLineageCandidateSet` contains base graph/context versions, canonical
retained candidates with axes/gates, dropped/returned holes, conflicts,
unresolved/coverage, policy/calibration, immutable input refs and checksum.
C12 stores immutable sets/policies/calibration manifests; DynamoDB indexes run/
cache/status. C15 owns proposal/review labels.

## 8. Interfaces and Contracts

- `POST /v1/verification-runs` accepts checksummed input manifest, base graph/
  C01/context/verification/confidence/calibration versions and idempotency;
  returns run/reference.
- C06 invokes Batch shards over S3 manifest and deterministic reduce/merge.
- `GET /v1/verification-runs/{id}` returns status/counts/references.
- `POST /v1/confidence-policies/{version}:preview|activate|rollback` requires
  labelled corpus/eval/distribution, expected active policy, approval/audit.
- Events: `verification.completed|incomplete|conflict`,
  `verification.candidate.dropped`, `lineage.hole.reopened`,
  `confidence.policy.activated`, `coverage.report.created`.

Outputs to C15 are immutable S3 references/checksums plus summary counts; no
candidate body is placed on EventBridge/Step Functions.

## 9. Processing and State Model

```text
REQUESTED -> INPUT_VERIFY -> IDENTITY_RECONCILE -> DEDUP_CONFLICT
          -> G1 -> G2 -> G3 -> G4 -> G5
          -> HOLE_COVERAGE_RECONCILE -> CONFIDENCE -> CANONICALIZE
          -> PACKAGE_VERIFY -> COMPLETE
```

1. Verify all exact input versions/checksums and reject mixed artifact/
   environment/base versions.
2. Canonicalize identity/path/transform; group exact-compatible candidates,
   preserve conflicts.
3. Apply gates under provenance applicability. Once drop gate fails, record
   remaining gates `NOT_EVALUATED_AFTER_DROP` and return hole; do not hide why.
4. Apply downgrade/review flags and evidence precedence without erasing claims.
5. Reconcile holes/coverage/input-output counts.
6. Calculate axes from allowed evidence and caps using pinned calibration; if
   uncalibrated, band is `UNCALIBRATED` while reasons still show evidence.
7. Canonical sort/serialize/write/read-back and emit one terminal output.

## 10. Failure Semantics

| Code | Class | Required behavior |
|---|---|---|
| `INPUT_PACKAGE_INVALID_OR_MIXED` | `DETERMINISTIC_INVALID` | Quarantine run; no proposal output |
| `IDENTITY_OR_VERSION_CONFLICT` | `CONFLICT` | Preserve claims; no forced edge merge |
| `G1_ENDPOINT_MISSING` | correctness drop | Drop/reopen hole with endpoint evidence |
| `G2_EVIDENCE_STALE_OR_MISMATCHED` | correctness drop | Drop/reopen hole; no low-confidence edge |
| `G3_TYPE_INCOMPATIBLE` | downgrade/conflict | Retain relationship risk/review unless another drop applies |
| `G4_UNREACHABLE` | correctness drop | Drop/reopen hole with call/data-flow facts |
| `G5_ORACLE_DISAGREEMENT` | downgrade/conflict | Retain risk/review; preserve oracle claim |
| `CONFIDENCE_POLICY_UNCALIBRATED` | `INCOMPLETE` calibration | Emit `UNCALIBRATED`, never guessed bands |
| `NONDETERMINISTIC_OUTPUT` | `DETERMINISTIC_INVALID` defect | Block verifier/policy version; preserve diff |
| `STORE_OR_BATCH_FAILURE` | `TRANSIENT` | Bounded retry/idempotent shard/reduce; no partial proposal |

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C13-SEC-001 | Verification workers must use tenant/run-scoped roles for exact C12 evidence/schema/fact/proposal-input prefixes and no graph publication permission. | P0 |
| C13-SEC-002 | Source citations/snippets, schemas, sensitive field metadata, runtime and opaque evidence must enforce domain ABAC/data class and never be copied into broad logs/events/metrics. | P0 |
| C13-SEC-003 | Verification/confidence/calibration policies and activations must be signed/versioned, separated from analyzer producers, reviewed, canaried, rollbackable, and audited. | P0 |
| C13-SEC-004 | Workers run in private encrypted Batch environments with controlled egress, signed images, ephemeral cleanup, and no direct mutable Neptune/OpenSearch access. | P0 |
| C13-SEC-005 | Gate/errors/audit must use allowlisted facts/checksums/reasons; payload values, credentials, sensitive source bodies, and model prompts/transcripts are prohibited. | P0 |

## 12. Scale, Performance, and Availability

- Shard verification by application/repository/artifact and candidate hash while
  keeping conflict/duplicate groups in one deterministic reducer partition.
- Gate fact/schema/oracle reads batch and cache immutable versions; cache key
  includes all input/policy/verifier versions. Integrity/authorization rechecks
  on lookup.
- Use Batch for G1-G5 and merge; Lambda only validates/dispatches small control.
  S3 manifests carry large input/output.
- One large application/domain cannot consume Tier-1 verification capacity;
  C06 admission applies.
- Immutable results/policies replicate; operational index/cache rebuild and
  rerun from C12 supports RPO/RTO. Current graph remains unchanged on failure.

## 13. Observability

| ID | Signal | Dimensions/alert | Priority |
|---|---|---|---|
| C13-OBS-001 | Candidate input/dedup/retained/drop/downgrade/conflict | provenance/archetype/app/policy | P0 |
| C13-OBS-002 | G1-G5 applicability/pass/fail/effect | gate/reason/provenance/verifier version | P0 |
| C13-OBS-003 | Holes opened/closed/reopened and coverage | reason/archetype/analyzer/app/owner | P0 |
| C13-OBS-004 | Structural/derivational band/cap/distribution | evidence/provenance/policy/calibration | P0 |
| C13-OBS-005 | Incomplete/stale/mismatched evidence | component/type/artifact/environment/owner | P0 |
| C13-OBS-006 | Verification versus human correction | provenance/archetype/gate/model/analyzer/policy | P0 |
| C13-OBS-007 | Determinism/latency/resource/cache/cost | shard/reducer/app/version | P0 |

Dashboards label gate metrics candidate-conditional and display the recall-zero
limitation. Correction rates use per-edge material labels; bulk unreviewed is
not accuracy evidence.

## 14. Acceptance Criteria

| ID | Acceptance criterion |
|---|---|
| C13-AC-001 | Given exact duplicates from multiple collectors, C13 emits one compatible edge with all provenance/evidence/determinants and no lost claim. |
| C13-AC-002 | Given G1, G2, or applicable G4 failure, candidate is absent from retained set, a dropped record and same/open hole exist, and counts reconcile. |
| C13-AC-003 | Given only G3 or G5 failure, structurally supported candidate remains downgraded/conflicted for review with no top-band promotion. |
| C13-AC-004 | Given complete runtime/OTel evidence, structural may increase and derivational is unchanged; incomplete/stale/mismatched evidence changes neither axis and appears as gap. |
| C13-AC-005 | Given exact Lane B mapping, native edge may be derivational oracle; its observation of a Lane A-produced field corroborates producer structure only, not producer derivation. |
| C13-AC-006 | Given sole-LLM or Lane C-only candidate, policy caps top bands/enforcement; no self-score or runtime changes cap incorrectly. |
| C13-AC-007 | Given no approved calibration, both axes are `UNCALIBRATED`; given labelled policy activation, expected independent bands/reasons/distribution result and collapsed score remains absent. |
| C13-AC-008 | Load/determinism/recovery meet NFRs with exact input/outcome/hole/coverage reconciliation and zero checksum divergence. |

## 15. Component Test Matrix

| ID | Level | Fixture/precondition | Action | Expected result | Retained evidence |
|---|---|---|---|---|---|
| C13-CT-001 | Dedup/conflict | Compatible duplicates plus structural/derivation/version conflicts | Reconcile | Exact merge or linked conflict, all claims retained | Candidate/conflict golden |
| C13-CT-002 | G1 | Existing/missing/ambiguous/versioned endpoints | Verify | Pass or drop/open hole; no forced identity | Gate/outcome |
| C13-CT-003 | G2 | Valid, moved/stale quote, wrong version/path/range, missing citation | Verify | Pass or drop/open hole | Reread/quote report |
| C13-CT-004 | G3 | Compatible cast, incompatible type/shape/nullability, unknown | Verify | Pass/downgrade/not observed exactly | Type matrix |
| C13-CT-005 | G4 | Reachable/unreachable/applicability native versus source | Verify | Pass/drop or typed not applicable | Graph/gate evidence |
| C13-CT-006 | G5 | Agree/disagree/no overlap/mismatched scope native/opaque | Verify | Pass/downgrade/not observed; no drop solely | Oracle matrix |
| C13-CT-007 | Gate combinations | Pairwise/all fail combinations | Verify | Drop precedence and remaining gate status exact; no lost reason | Combination matrix |
| C13-CT-008 | Confidence axes | Deterministic/native/LLM/runtime/opaque/human evidence combinations | Calculate | Independent allowed effects/caps; no shared float | Policy golden |
| C13-CT-009 | Runtime boundary | Complete/incomplete/truncated/stale/mismatched runtime | Calculate | Structural only for complete; derivational never; gaps exact | Confidence/coverage |
| C13-CT-010 | Calibration | No labels, material labels, bulk unreviewed, policy canary/rollback | Calculate/activate | Uncalibrated or expected bands; bulk excluded | Calibration report |
| C13-CT-011 | Determinism/security | Random input/shard order, sensitive citations, unauthorized domain | Verify repeatedly/access | Same bytes; ABAC deny/redacted logs | Checksums/security scan |
| C13-CT-012 | Load/recovery | 100k package, 10M app, 500 concurrency, failure/Region restart | Verify/recover | NFR/RPO/RTO/exact reconciliation/no partial proposal | Load/DR report |

## 16. Integration Obligations

- **INT-086 C01/C05↔C13:** canonical identity/environment/version/schema/
  determinants/base graph pin and ambiguity/conflict behavior pass.
- **INT-087 C07↔C13:** native exact oracle, unresolved/coverage, duplicate,
  artifact/environment, and Lane A producer asymmetry pass.
- **INT-088 C08/C09↔C13:** deterministic proof/hole/citation/tools undergo
  G1/G2/G4; drop reopens same hole and LLM caps/feedback are exact.
- **INT-089 C10↔C13:** advisory scope/abstention/G3/G5/cap/nonmatch/expiry never
  produces top band or blocking eligibility alone.
- **INT-090 C11↔C13:** complete versus incomplete runtime affects structural
  only and interaction alone is not lineage.
- **INT-091 C13↔C14/C15:** deterministic-only blocking selection, immutable
  proposal inputs, before/after gates/conflicts/coverage and review labels feed
  calibration without circular self-validation.
- **INT-092 C13↔C17:** UI/API render both axes, evidence/gates/caps/holes/conflicts/
  coverage and recall limitation; single score absent.
- **INT-093 C13↔C18:** policy security, deterministic/load/chaos, reconciliation,
  calibration drift, audit and DR runbooks/gates pass.

## 17. Definition of Done

- Candidate/group/conflict/coverage contracts, deterministic merge, G1-G5,
  drop/downgrade/hole reconciliation, two-axis policy/calibration, immutable
  output/cache, and telemetry are implemented.
- C13 P0 requirements and C13-CT-001 through C13-CT-012 pass.
- INT-086 through INT-093 pass with production-shaped C07-C12 and C14-C17.
- Gate combination/recall limitation and every confidence evidence combination
  have golden results; no schema/UI/API contains collapsed score.
- Labelled calibration/canary report proves bands/distributions or system remains
  visibly `UNCALIBRATED`; no unsupported enforcement advancement.
- Load/determinism/security/recovery reports meet NFRs, exact reconciliation,
  zero checksum divergence, ABAC/no-sensitive-log, and no partial proposal.
- Gate/policy/calibration/conflict/reconciliation/rollback/DR runbooks and alarms
  are exercised with real IDs.

## 18. Implementation Notes

```text
contracts/schemas/verification/
contracts/schemas/confidence/
workers/verifier/
workers/verifier/gates/
workers/verifier/confidence/
services/confidence-policy/
infra/lib/constructs/verification-jobs.ts
tests/fixtures/verification-microworld/
tests/contract/verification/
tests/integration/verification/
tests/load/verification/
tests/security/verification/
```

Use Python 3.12 for deterministic verification/confidence workers, TypeScript 5
for policy/control/IaC. Implement gates as pure versioned functions returning
typed results, not exceptions or side effects. Canonical merge/sort is stable
and uses exact rational/decimal or policy bands, never floating-point summation
over unordered inputs.

Build order: contracts/microworld; identity/dedup/conflict; G1-G5 one at a time;
hole/coverage reconciliation; uncalibrated axes/caps; C15 labels/calibration;
C14/C17; load/security/DR. Rollback activates prior immutable policy for new
runs; prior output/proposals retain their original policy/version.

## 19. Traceability

| Source decision | C13 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| Five verification gates/drop versus downgrade | C13-FR-005 through C13-FR-013 | C13-CT-002 through C13-CT-007 | INT-087-091; verification gate |
| Cross-lane reconciliation/conflict | C13-FR-001 through C13-FR-004/020/021 | C13-CT-001/011/012 | INT-086-090 |
| Independent confidence/evidence/caps | C13-FR-014 through C13-FR-019 | C13-CT-008-010 | INT-087-092; calibration gate |
| Scale/determinism/security/recovery | C13-NFR-001-004; C13-SEC-001-005 | C13-CT-011/012 | INT-093; enterprise/security/DR gates |


---

# 14-ci-artifact-binding-and-freshness.md

# C14 CI Drift, Artifact Binding, and Freshness PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C14 |
| Status | Approved for implementation |
| Launch phase | Observation with Lane A; binding/freshness required before enforcement |
| Criticality | P0; every deployed artifact must have a visible lineage decision |
| Primary owner | Lineage CI/CD and release-integrations team |
| Required approvers | Architecture, release engineering, application security, trust/review owners |
| Upstream dependencies | C03-C06, C08-C13, enterprise CI/build/deployment systems, signing service |
| Downstream dependencies | C15-C18 and external deployment policy |
| Authoritative sources | Element-level v2 R8-R10; AWS architecture §§9, 14, 17-19 |

## 2. Purpose and Outcomes

C14 keeps lineage synchronized with code and immutable deployed artifacts while
stating CI's limits honestly. Lane A CI re-derivation is a drift check, not
semantic validation. An unskippable release step binds the reviewed LineageSpec
package to the exact artifact digest, including an already-built image and every
hotfix/emergency path. Deployment reconciliation exposes missing/stale lineage
and suppresses lineage more than two deploys behind from blast-radius claims.

Measurable outcomes:

- 100% of PR checks use only `Lineage drift: none` or `Lineage drift detected`
  status language; no CI output claims semantic validation.
- 100% of deployed artifacts have a current/approved lineage binding or an
  explicit missing/stale/blocked/exception decision and alert.
- LLM/opaque provenance is structurally absent from blocking policy inputs.
- Scheduled full analysis produces zero unexplained full-scan divergence from
  incremental state; non-zero is an owned defect.

## 3. Scope and Non-Goals

### In scope

- Lane A pull-request deterministic lineage re-derivation/diff, checks,
  comments, patch/proposal artifact, observe/acknowledge/block phases.
- Signed `ArtifactLineageBinding` for existing artifact digest without rebuild.
- Deployment event/binding/freshness reconciliation, hotfix/emergency coverage,
  missing alert, staleness/suppression, full-scan divergence, policy/audit.

### Non-goals

- Claiming CI proves lineage correctness; generator and checker share machinery.
- Running Lane B's authoritative per-run lineage through Lane A PR drift.
- Letting an LLM-provenance edge block CI/deployment.
- Silently committing generated lineage to a branch.
- Rebuilding an image merely to attach lineage or allowing image tag as identity.
- Production SCA/LLM; production emits digest/schema/boundary confirmation only.

## 4. Actors and Use Cases

| Actor/system | Use case |
|---|---|
| Developer/PR author | See deterministic lineage drift and apply an explicit patch |
| Reviewer | Compare proposed deterministic changes/evidence before merge |
| Release pipeline | Bind signed approved LineageSpec to exact already-built digest |
| Deployment controller | Evaluate binding/freshness policy for normal/hotfix deploy |
| Incident responder | Know whether an edge matches the running artifact or is suppressed |
| Operator | Reconcile deployments/bindings, full-vs-incremental divergence, exceptions |

## 5. Component Boundary

### Owned behavior

- CI drift result/patch artifact and deterministic-only policy input.
- Artifact-lineage signing/attestation registry, deployment freshness decision,
  reconciliation, stale suppression and enforcement phase policy.

### Inputs

- PR commit/base and C08/C13 deterministic results/determinants.
- C15 approved proposal/LineageSpec package and C12 reference/checksum.
- Immutable build artifact digest/signature/SBOM/provenance and deployment event.
- Active/previous bindings, policy/phase, full scan/incremental manifests.

### Outputs

- CI status/comment/patch artifact, `ArtifactLineageBinding`, deployment lineage
  decision, freshness/suppression, alerts/exceptions/divergence/audit.

### Forbidden behavior

- Outputting "validated" or equivalent correctness claim for the drift check.
- Including LLM/Lane C/unreviewed evidence in blocking input.
- Pushing/committing a generated contract automatically.
- Binding a mutable tag, branch, missing digest, or package from another digest.
- Skipping binding for hotfix/emergency/already-built artifacts.
- Using stale-suppressed lineage in automated blast radius while hiding reason.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C14-FR-001 | Lane A PR check must deterministically regenerate the scoped LineageSpec/candidate set from the PR commit and compare it with the repository's declared/base lineage using pinned analyzer/policy versions. | P0 |
| C14-FR-002 | The only success/failure summary strings must be `Lineage drift: none` and `Lineage drift detected`; the word `validated` and semantic-correctness claims are prohibited in status/comment text. | P0 |
| C14-FR-003 | CI drift output must separate added/removed/modified deterministic edges, determinants, holes/coverage, unsupported/incomplete and artifact/policy versions with evidence references. | P0 |
| C14-FR-004 | Only deterministic-provenance edges may enter blocking policy; LLM, Lane C, runtime-only, conflict, uncalibrated, and bulk-unreviewed inputs must be structurally excluded before policy evaluation. | P0 |
| C14-FR-005 | CI must never silently commit generated lineage; it must publish a checksummed patch/proposal artifact and PR comment/status with explicit developer/reviewer action. | P0 |
| C14-FR-006 | Lane B native workloads must not use Lane A PR drift as their authoritative lineage gate; their per-run native evidence/freshness is reconciled separately. | P0 |
| C14-FR-007 | Enforcement phases must be versioned `OBSERVE`, `ACKNOWLEDGE_CRITICAL`, `BLOCK_MISSING_CRITICAL_MAPPING`, and `BLOCK_HIGH_CONFIDENCE_BREAKING_IMPACT`; transition requires approved measured false-positive/correction/SLO/security evidence. | P0 |
| C14-FR-008 | Advancement beyond observation must require false-positive rate below 20% for four consecutive weeks for the gated scope, calibrated bands, sufficient material labelled corpus, no unexplained full-scan divergence, and approved rollback. | P0 |
| C14-FR-009 | Release binding must take an immutable already-built image/artifact digest and approved LineageSpec package/reference/checksum, verify application/repository/commit/environment/policy compatibility, and produce a signed immutable `ArtifactLineageBinding`. | P0 |
| C14-FR-010 | Binding must be unskippable for normal, hotfix, emergency, rollback, promotion, and manual deployment paths and must run against an already-built image without rebuild or tag mutation. | P0 |
| C14-FR-011 | Signature/attestation must cover artifact digest, lineage package checksum/version, proposal/accepted manifest/base graph, application/repository/commit, environment scope, signer, policy, and creation/expiry/revocation. | P0 |
| C14-FR-012 | Every deployment event must reconcile by immutable digest/environment to a valid binding or explicit `MISSING`, `MISMATCHED`, `STALE`, `REVOKED`, `BLOCKED`, or governed time-bounded exception; absence is never silent. | P0 |
| C14-FR-013 | An artifact observed in production without valid lineage package must raise an owned alert and follow policy (observe/warn/block) while preserving the deployment decision and hotfix identity. | P0 |
| C14-FR-014 | Freshness must compare the active approved package with deployed digest/version sequence; more than two deploys behind must be `STALE_SUPPRESSED` and excluded from blast-radius automation with reason visible. | P0 |
| C14-FR-015 | Freshness/invalidation must use C05 determinants and all deploys, not changed-file proximity; configuration-only, dependency, schema, contract, infrastructure, and analyzer/policy changes must trigger correct decisions. | P0 |
| C14-FR-016 | Scheduled full rescan must diff against accumulated incremental result; any unexplained full-scan divergence must create a defect/alert and block enforcement advancement rather than be accepted as tolerance. | P0 |
| C14-FR-017 | Production collection for freshness must be limited to artifact digest, schema/version, deployment and boundary metadata; production SCA/LLM/raw field payload capture is prohibited. | P0 |
| C14-FR-018 | Exceptions must be scope/digest/environment/policy/reason/owner/approver/effective/expiry constrained, nonrenewing without review, visible in CI/deployment/UI, and reconciled on expiry. | P0 |
| C14-FR-019 | CI/binding/deployment/full-scan decisions must be immutable, idempotent by exact business identity, correlated, queryable, and auditable. | P0 |
| C14-FR-020 | C14 should support policy preview against historical PR/deployment/label data and current estate without changing active checks/gates. | P1 |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C14-NFR-001 | Incremental PR drift must finish within 10 minutes p95 and artifact binding within two minutes p95 excluding required human review. | P0 |
| C14-NFR-002 | Deployment binding/freshness decision must be available within 60 seconds p95 of deployment event; Tier-1 within 30 seconds p95. | P0 |
| C14-NFR-003 | C14 must process at least 10,000 deployment decisions/day and 100 events/second bursts without losing hotfix or exception-expiry decisions. | P0 |
| C14-NFR-004 | CI/binding/freshness service must be 99.95% available monthly; policy defines fail-open/closed per phase while preserving visible decision and recovery within C18 RPO/RTO. | P0 |

## 7. Data and Durable State

`CiDriftResult` contains repository/base/head/analyzer/policy, deterministic input
manifest/checksum, added/removed/modified edges, holes/coverage, exclusions by
provenance/reason, summary string, status, patch/comment refs, and audit.

`ArtifactLineageBinding` contains artifact digest/type/signature/build provenance,
application/repository/commit/environment, LineageSpec/accepted proposal/base
graph reference/checksum/version, analyzer/policy/contract versions, signer/
signature/key, effective/expiry/revocation, and immutable checksum.

`DeploymentLineageDecision` contains deployment/digest/environment/time/tier,
binding/freshness, deploy sequence/behind count, suppression, policy/phase,
action/exception/alert, run/proposal/graph refs and checksum.

`DivergenceReport` contains full/incremental refs/checksums, missing/extra/
modified edges/holes/determinants by archetype/provenance, explanation/status,
defect/owner and enforcement-gate effect.

C12 stores immutable results/bindings/decisions/reports; DynamoDB holds current
binding/freshness/exception/deployment indexes and idempotency.

## 8. Interfaces and Contracts

- CI command/API `lineage drift --base <sha> --head <sha> --output <dir>` emits
  machine JSON, LineageSpec patch, human summary and process status; server API
  uses S3 references for analysis.
- `POST /v1/artifact-lineage-bindings` accepts artifact provenance/digest and
  approved lineage ref/checksum/compatibility; signing service returns immutable
  binding/attestation.
- `POST /v1/deployment-lineage-decisions` normally consumes C03 normalized
  deployment event and binding registry.
- `GET /v1/artifacts/{digest}/lineage` and deployment/freshness endpoints return
  decision/history with authorization.
- Events: `lineage.drift.detected|none`, `artifact.lineage.bound|missing|revoked`,
  `deployment.lineage.current|stale|suppressed|blocked`,
  `incremental.full-scan.diverged`, `lineage.exception.expiring|expired`.

## 9. Processing and State Model

### CI drift

```text
REQUESTED -> INPUT_PINNED -> DETERMINISTIC_REDERIVE -> DIFF
          -> POLICY_FILTER -> ARTIFACTS_PUBLISHED -> REPORTED
```

### Artifact/deployment freshness

```text
BUILT -> LINEAGE_APPROVED -> BOUND_SIGNED -> DEPLOY_OBSERVED
      -> CURRENT | BEHIND_ONE | BEHIND_TWO | STALE_SUPPRESSED
      -> REBOUND/CURRENT
```

Alternative: `MISSING`, `MISMATCHED`, `REVOKED`, `BLOCKED`, `EXCEPTION_ACTIVE`,
`EXCEPTION_EXPIRED`.

1. Verify exact commit/digest/approved package/policy and sign binding without
   rebuilding artifact.
2. On every deploy, fetch/verify binding/signature/revocation/environment and
   active package/graph sequence.
3. Compute behind count/freshness and policy action; persist decision before
   acknowledge.
4. Reconcile deployment inventory to decisions/bindings and exceptions.
5. Scheduled full result compares incremental state and gates enforcement.

## 10. Failure Semantics

| Code | Class | Required behavior |
|---|---|---|
| `DRIFT_INPUT_OR_ANALYSIS_INCOMPLETE` | `INCOMPLETE` | Non-success check with gap; no semantic claim |
| `NONDETERMINISTIC_PROVENANCE_IN_BLOCK_INPUT` | `DETERMINISTIC_INVALID` policy | Reject policy input/alert; no block decision from it |
| `ARTIFACT_DIGEST_MISSING_OR_MISMATCH` | `DETERMINISTIC_INVALID`/`CONFLICT` | No binding; exact defect/decision |
| `LINEAGE_PACKAGE_NOT_APPROVED_OR_MISMATCHED` | `DETERMINISTIC_INVALID` | No signature/binding |
| `SIGNING_SERVICE_UNAVAILABLE` | `TRANSIENT` | Bounded retry; phase policy fail behavior, visible decision |
| `BINDING_MISSING_REVOKED_EXPIRED` | `INCOMPLETE` | Alert/warn/block by phase; never assume current |
| `STALE_OVER_TWO_DEPLOYS` | deterministic freshness | Suppress blast-radius use and display reason |
| `FULL_SCAN_DIVERGENCE` | correctness defect | Alert/block phase advancement; preserve exact diff |
| `EXCEPTION_EXPIRED` | deterministic policy | Re-evaluate immediately; no silent renewal |

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C14-SEC-001 | CI/release/deployment callers must use workload/repository/environment-scoped identities; signer keys/roles are separate from build/analyzer/reviewer/deployer roles and require exact digest/package conditions. | P0 |
| C14-SEC-002 | Artifact/lineage signatures and attestations must use approved KMS/signing profile, key rotation/revocation, immutable transparency/audit, and verification in deployment decisions. | P0 |
| C14-SEC-003 | CI logs/comments/status/patches must not include source secrets, payloads, sensitive evidence bodies, model prompts, or signing material; references enforce ABAC. | P0 |
| C14-SEC-004 | Policy/phase/exception/signing/revocation changes require scoped role separation, expected version, evidence/rationale/expiry, approval, and CloudTrail/audit. | P0 |
| C14-SEC-005 | Production roles must have no SCA/LLM/runtime-field ingestion permission; allowed digest/schema/boundary metadata contracts are closed and audited. | P0 |

## 12. Scale, Performance, and Availability

- CI uses C08 content cache and C05 determinant scope; full reanalysis is
  scheduled separately and never omitted as soundness oracle.
- Binding is O(artifact/package) verification/signing, not repository analysis.
  Registry/index partitions by organization/digest/environment.
- Deployment events are Tier-1 through C03/C06; every hotfix identity remains
  independent. Backfill/full scan cannot consume reserved decision capacity.
- Signer/registry/decision services are Multi-AZ with queued retry and warm-
  Region keys/IaC/replicated immutable evidence. Phase policy defines whether
  dependency outage observes/warns/blocks without losing audit.

## 13. Observability

| ID | Signal | Dimensions/alert | Priority |
|---|---|---|---|
| C14-OBS-001 | CI drift/status/latency | repo/archetype/deterministic count/policy | P0 |
| C14-OBS-002 | Blocking exclusions | provenance/conflict/calibration/coverage reason | P0 |
| C14-OBS-003 | Binding/sign/verify/revoke | digest/app/env/key/policy/status | P0 |
| C14-OBS-004 | Deployment current/missing/stale/suppressed/blocked/exception | tier/app/domain/owner; missing hotfix alert | P0 |
| C14-OBS-005 | Deploy-to-decision latency/backlog/reconciliation | priority/domain/system | P0 |
| C14-OBS-006 | Full-scan divergence | archetype/reason/missing/extra/modified; any unexplained alert | P0 |
| C14-OBS-007 | Phase metrics | false positive/correction/labelled corpus/SLO/security/rollback | P0 |

C17 displays digest/binding/freshness/behind count/suppression/exception and
LineageSpec/proposal/graph versions. Dashboard metrics reconcile all deployment
inventory to decisions.

## 14. Acceptance Criteria

| ID | Acceptance criterion |
|---|---|
| C14-AC-001 | Given no/detected deterministic diff, CI emits exactly the approved summary string, full patch/evidence, and never uses `validated` as correctness language. |
| C14-AC-002 | Given LLM/Lane C/runtime-only/unreviewed candidates, they are absent from blocking input by schema/filter assertion, not merely ignored by convention. |
| C14-AC-003 | Given a PR drift, C14 publishes patch/comment/artifact but does not commit/push source automatically. |
| C14-AC-004 | Given an already-built normal or hotfix image, C14 binds the exact digest to compatible approved package without rebuild; mismatches fail. |
| C14-AC-005 | Given a deployed digest with missing/revoked/stale binding, an exact visible policy decision/alert occurs and more than two deploys behind is suppressed. |
| C14-AC-006 | Given configuration-only/dependency/schema/infrastructure/test changes, determinant-based freshness targets match C05; changed-file-only under-report is absent. |
| C14-AC-007 | Given non-zero full-scan divergence or unmet FP/corpus/calibration/SLO/security gate, enforcement phase cannot advance. |
| C14-AC-008 | Load/outage/recovery meet NFRs and every deployment/hotfix/exception reconciles to one immutable decision with no silent absence. |

## 15. Component Test Matrix

| ID | Level | Fixture/precondition | Action | Expected result | Retained evidence |
|---|---|---|---|---|---|
| C14-CT-001 | CI golden | No drift and added/removed/modified deterministic drift | Run check | Exact strings/status/diff/versions | CI artifacts |
| C14-CT-002 | Semantics/negative | Scan all check text plus generator/validator same engine | Execute | No `validated` claim; docs/status state drift limitation | Output scan |
| C14-CT-003 | Provenance policy | Deterministic, LLM, runtime, opaque, conflict, unreviewed inputs | Build block set | Deterministic eligible only, exact exclusions | Policy input golden |
| C14-CT-004 | No silent commit | Repository/PR token with generated patch | Run CI | Comment/artifact only; git ref unchanged | SCM before/after/audit |
| C14-CT-005 | Binding | Correct/missing/mismatched digest/package; already-built image | Bind | Signed exact binding or deterministic failure; image digest unchanged | Attestation/image evidence |
| C14-CT-006 | Hotfix/emergency | All normal/manual/hotfix/rollback/promotion paths | Deploy | Every digest passes binding decision; none skipped/coalesced | Deployment decision set |
| C14-CT-007 | Freshness | Current, one/two/three deploys behind, revoked, exception | Decide/query | Exact states; >2 suppressed/visible | Freshness matrix |
| C14-CT-008 | Determinants | Config/library/infra/contract/test changes | Invalidate/decide | Exact impacted/no-impact, no file-only gap | Plan/decision report |
| C14-CT-009 | Divergence | Full result differs missing/extra/modified | Compare/advance phase | Defect/alert; advancement denied | Divergence/gate evidence |
| C14-CT-010 | Exception/security | Unauthorized/expired/overbroad exception, bad signature/key | Apply/verify | Denied or exact expiry/re-evaluation/audit | IAM/sign/audit report |
| C14-CT-011 | Phase | Historical four-week FP/corpus/calibration/SLO combinations | Preview/activate | Advance only all conditions/approval; rollback exact | Phase decision report |
| C14-CT-012 | Load/DR | 10k/day, 100/sec burst, signer outage, Region failover | Decide/recover | NFR/RPO/RTO and exact deployment reconciliation | Load/DR report |

## 16. Integration Obligations

- **INT-094 C05/C08/C13↔C14:** determinant-scoped deterministic drift, holes/
  coverage, provenance block filtering, and full-scan comparison interoperate.
- **INT-095 C03/C06↔C14:** every deployment/hotfix/exception expiry creates one
  priority idempotent decision under duplicates/out-of-order/replay.
- **INT-096 CI/SCM↔C14:** exact strings/status/comment/patch/no-auto-commit,
  permissions, timeout and deterministic-only policy pass.
- **INT-097 Build/release/signing↔C14:** already-built digest, approved package,
  signature/attestation, mismatch/revoke/outage and all paths pass.
- **INT-098 C14↔C15/C16:** approved proposal/package binds to artifact and only
  matching approved graph version publishes/becomes current.
- **INT-099 Deployment↔C14/C17:** current/missing/stale/suppressed/blocked/
  exception decisions/alerts are visible and reconciled.
- **INT-100 C14↔C18:** policy/phase/signing/IAM/privacy/audit/alarms/runbooks/
  exceptions/reconciliation/load/DR gates pass.
- **INT-101 C14↔Incident queries:** stale-suppressed lineage is excluded from
  blast-radius automation with reason, while historical evidence remains.

## 17. Definition of Done

- CI command/service, deterministic policy filter, patch/comment/status,
  binding signer/registry/attestation, deployment decision/freshness/suppression,
  exception, full-scan/phase policy, reconciliation and telemetry are implemented.
- C14 P0 requirements and C14-CT-001 through C14-CT-012 pass.
- INT-094 through INT-101 pass with enterprise SCM/build/release/deployment and
  production-shaped platform components.
- Every deployment/hotfix in the acceptance window reconciles to one immutable
  decision; missing/stale alerts and >2 suppression are proven.
- Phase remains observation unless corpus/calibration/FP/SLO/security/divergence
  evidence meets the exact gate; activation/rollback report is retained.
- Signing/security/privacy/load/outage/DR reports meet NFRs and prove no rebuild,
  skipped path, nondeterministic block input, production SCA/LLM, or secret leak.
- CI/binding/missing/stale/exception/signing/phase/reconciliation/DR runbooks and
  alarms are exercised with real IDs.

## 18. Implementation Notes

```text
contracts/schemas/ci-drift/
contracts/schemas/artifact-binding/
services/ci-drift/
services/artifact-binder/
services/deployment-lineage-controller/
workers/full-scan-divergence/
infra/lib/constructs/artifact-binding.ts
docs/runbooks/artifact-freshness/
tests/contract/ci-binding/
tests/integration/ci-binding/
tests/security/ci-binding/
tests/load/ci-binding/
```

Use TypeScript 5 for CI/control/signing/IaC integration and Python 3.12 for
manifest diff/large reconciliation. Sign an attestation referencing existing
artifact digest and C12 package; never mutate/rebuild image. Prefer the
enterprise artifact-attestation standard and KMS keys rather than a new private
signature format.

Build order: drift schema/CLI/exact language; provenance filter/patch; binding/
sign/verify; deploy decisions/freshness/suppression; exceptions/reconciliation;
full-scan/phase; load/security/DR. Default phase is `OBSERVE` and policy rollback
is independent of application deployment.

## 19. Traceability

| Source decision | C14 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| CI is drift, deterministic blocking only, no auto-commit | C14-FR-001-008 | C14-CT-001-004/011 | INT-094/096; CI observation gate |
| Artifact digest binding unskippable incl hotfix | C14-FR-009-013/019 | C14-CT-005/006/010/012 | INT-095/097/098 |
| Freshness >2 suppressed/determinant/full divergence | C14-FR-014-018 | C14-CT-007-009 | INT-099/101; freshness gate |
| Security/scale/recovery | C14-SEC-001-005; C14-NFR-001-004 | C14-CT-010/012 | INT-100; security/enterprise/DR gates |


---

# 15-proposal-review-and-corpus.md

# C15 Proposal, Human Review, and Calibration Corpus PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C15 |
| Status | Approved for implementation |
| Launch phase | Required before first canonical publication |
| Criticality | P0; all material launch proposals require explicit human approval |
| Primary owner | Lineage governance and review team |
| Required approvers | Product, architecture, data governance, application ownership, security |
| Upstream dependencies | C01, C06, C12-C14, enterprise SSO/SCIM/ownership |
| Downstream dependencies | C13 calibration, C14 enforcement policy, C16-C18 |
| Authoritative sources | AWS architecture §12 and rollout/launch gates; element-level v2 R7/R10 |

## 2. Purpose and Outcomes

C15 turns a verified candidate set into an immutable before/after proposal,
supports evidence-aware human correction/approval/rejection, and records the
material per-edge labels needed to measure and calibrate trust. Review is a
governance boundary, not a checkbox: corrections create a new immutable proposal
version, approvals bind the exact checksum, and bulk accept is `unreviewed` for
calibration.

Measurable outcomes:

- Every material launch proposal is explicitly approved/rejected/corrected by
  an authorized reviewer; no production auto-publication.
- Every decision binds exact proposal version/checksum, base graph, reviewer,
  rationale, time, policy and audit; no stale browser overwrite.
- A material per-edge acknowledgement emits `diff(engineProposal,
  acceptedProposal)` as immutable `ReviewLabel`; bulk accept creates zero false
  correctness labels.
- Before enforcement beyond observation, corpus contains at least 200 labelled
  edges across all six archetypes including dynamic SQL, opaque UDF and multi-
  producer cases, with correction rate published by provenance and archetype.

The normative corpus shorthand used by gates is **200 labelled edges across six
archetypes**, subject to the materiality and hard-case rules below.

## 3. Scope and Non-Goals

### In scope

- `LineageProposal` construction/version/state, before/after diff, review
  assignment/authorization, correction/comment/rationale, approve/reject/
  supersede/rebase/expiry, decision/manifest handoff.
- Material-edge acknowledgement and immutable label corpus/metrics/quality gate.
- Review backlog/SLO, notification/escalation, audit and read/write APIs used by
  C17.

### Non-goals

- Rendering UI details (C17) or publishing graph state (C16).
- Treating bulk acceptance, a human decision, or a model self-score as runtime
  execution/derivational oracle.
- Mutating a prior proposal/label/decision.
- Automatically resolving critical UNKNOWN, identity ambiguity, or policy-
  blocking incomplete evidence.
- Training a model or selecting a model from labels without separate governed
  evaluation/AI process.

## 4. Actors and Use Cases

| Actor | Use case |
|---|---|
| Application/domain owner | Review baseline/incremental changes and evidence |
| Data steward | Correct canonical field/transform/metadata and classify conflict |
| Proposer | Submit verified proposal; cannot self-approve when separation required |
| Approver | Approve/reject exact immutable version with rationale |
| Calibration analyst | Build quality-controlled material-edge corpus/metrics |
| Operator | Reassign/escalate backlog, supersede stale proposal, redrive publication |

## 5. Component Boundary

### Owned behavior

- Proposal/decision/correction/comment/label contracts and immutable lifecycle.
- Reviewer assignment/authorization/separation, optimistic concurrency,
  materiality/acknowledgement and corpus calculations.

### Inputs

- C13 verified set/gates/confidence/holes/conflicts/coverage, base/active graph,
  C14 artifact/freshness, identity/context, reviewer ownership/role/policy.

### Outputs

- Immutable proposal versions, decisions/corrections/comments/labels, approved
  manifest request to C16, corpus/calibration/enforcement metrics.

### Forbidden behavior

- Updating a proposal version after publication to reviewers.
- Approval that does not name exact checksum/base/versions.
- Last-write-wins for concurrent review.
- Producing a correctness label from bulk accept or material edge not actually
  acknowledged.
- Auto-approving on confidence or allowing unreviewed LLM/Lane C evidence to
  bypass human review.
- Publishing directly to Neptune/OpenSearch.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C15-FR-001 | C15 must create an immutable `LineageProposal` version bound to application/environment, base graph version, C13 set/checksum/policies, context/artifact, creator and prior proposal version. | P0 |
| C15-FR-002 | Proposal must present before/after nodes/edges and separate added, removed, transformation/path, structural confidence, derivational confidence, evidence, coverage, holes, conflicts, freshness, and no-impact changes. | P0 |
| C15-FR-003 | Every proposed edge must expose canonical endpoints, environment/effective artifact, both confidence axes/caps/calibration, provenance/evidence, G1-G5, determinants, holes/conflicts and review materiality. | P0 |
| C15-FR-004 | The lifecycle must support `DRAFT -> AWAITING_REVIEW -> APPROVED -> PUBLISHING -> ACTIVE`, plus `REJECTED`, `SUPERSEDED`, and `FAILED` publication redrive; transitions are expected-state/version conditional. | P0 |
| C15-FR-005 | Reviewer correction must create a new immutable proposal version linked to the prior, recompute/verify affected diff and checksum, and return to `DRAFT`/`AWAITING_REVIEW`; prior version remains read-only. | P0 |
| C15-FR-006 | Approval/rejection must record exact proposal version/checksum/base graph, reviewer identity/role, decision/rationale, policy, time, evidence acknowledgements, and immutable audit. | P0 |
| C15-FR-007 | Stale/concurrent edit or decision must fail with current version/checksum/state and require deliberate rebase/review; it must not overwrite a newer change. | P0 |
| C15-FR-008 | Reviewer authorization must derive from enterprise SSO/SCIM, application/domain ownership, RBAC/ABAC and optional separation of proposer/approver; access is rechecked at every write. | P0 |
| C15-FR-009 | Critical UNKNOWN repository, unresolved identity/version conflict, blocking incomplete evidence, stale base graph, or expired artifact/policy must prevent approval until corrected, explicitly waived where permitted, rebased or superseded. | P0 |
| C15-FR-010 | At launch, every material baseline/incremental proposal must require explicit human approval; no production auto-approval/auto-publication policy exists. | P0 |
| C15-FR-011 | Proposal assignment must support owner queue, due/SLO, notifications/escalation, delegation with expiry, and absence/conflict handling without changing decision authority silently. | P0 |
| C15-FR-012 | A material edge acknowledgement must record `engineSaid`, `humanSaid`, edge, provenance, archetype, repository, commit, reviewer, timestamp, proposal versions and acknowledgement mode in immutable `ReviewLabel`. | P0 |
| C15-FR-013 | Bulk accept must mark material edges `unreviewed` and must not produce correctness/correction labels; a reviewer must explicitly acknowledge each material mapping used for calibration. | P0 |
| C15-FR-014 | `diff(engineProposal, acceptedProposal)` must classify unchanged-confirmed, corrected source/target/transform/path, added missing edge, removed false edge, confidence/evidence/metadata correction, unresolved/waived and unreviewed. | P0 |
| C15-FR-015 | Corpus gate must require at least 200 material labelled edges spanning Spring, FastAPI, Dask, Spark, dbt and Airflow/SQL archetypes and deliberately hard dynamic SQL, opaque UDF and multi-producer cases before enforcement beyond observation. | P0 |
| C15-FR-016 | C15 must publish correction rate by provenance (deterministic versus LLM/native/opaque as applicable) and by archetype, plus confirmed/added/removed/changed/unreviewed distribution and labelled sample counts/uncertainty. | P0 |
| C15-FR-017 | Label/corpus quality must detect duplicates/leakage, invalid reviewer scope, nonmaterial/bulk labels, superseded artifacts, missing evidence and imbalanced archetype/case coverage before calibration use. | P0 |
| C15-FR-018 | Proposal staleness must compare active graph/context/artifact/policy/evidence versions; stale proposals are rebased or superseded, never published against a changed expected base. | P0 |
| C15-FR-019 | Rejection/supersession/expiry/publication failure must retain all proposal/evidence/comment/decision/label history and expose governed retry/rebase/closure action. | P0 |
| C15-FR-020 | Post-launch auto-approval research may be evaluated only in shadow mode and requires a separate approved policy/change after measured gates; it is not initial scope. | P1 |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C15-NFR-001 | Proposal creation/diff for 100,000 changed edges must complete within five minutes p95; standard proposal API writes within two seconds p95. | P0 |
| C15-NFR-002 | Review APIs/queues must be 99.95% available monthly and preserve read/write consistency/optimistic concurrency across Multi-AZ failure. | P0 |
| C15-NFR-003 | 95% of Tier-1 material proposals must be assigned/notified within one minute and reviewed within the governed Tier-1 SLO or escalated. | P0 |
| C15-NFR-004 | Proposal/decision/label history must recover within C18 RPO/RTO with no duplicate/lost decision or publication from stale state. | P0 |

## 7. Data and Durable State

`LineageProposal` contains ID/version/state/application/environment/base/target
intent, immutable C13 before/after/diff refs, context/artifact/digest/freshness,
confidence/gates/coverage/conflicts/holes summaries, creator/assignment/material
edge manifest, policy/schema versions, prior/supersedes, checksum/timestamps.

`ReviewCorrection` contains proposal/version/checksum, material edge/object,
operation, engine value, human value, evidence/rationale, reviewer, expected
state/version, time and new proposal ref/checksum.

`ProposalDecision` contains exact reviewed checksum/base, approve/reject,
reviewer/role, separation result, rationale, material acknowledgement manifest,
waivers, policy and signature/audit.

`ReviewLabel` contains edge/engineSaid/humanSaid/change class/provenance/
archetype/repository/commit/artifact/reviewer/time/ack mode/evidence/policy and
immutable checksum. Acknowledgement mode is `MATERIAL_EDGE_REVIEWED` or
`UNREVIEWED_BULK`; only the first enters labelled accuracy corpus.

C12 S3 Object Lock stores proposal versions, corrections, decisions, labels and
accepted manifest input. DynamoDB holds lifecycle/assignment/concurrency/
notification/publication status; analytics catalog reads immutable labels.

## 8. Interfaces and Contracts

- `POST /v1/proposals` accepts C13 set/base/context/artifact refs/checksums and
  idempotency; returns draft ref/version.
- `POST /v1/proposals/{id}/versions/{v}:submit|correct|approve|reject|supersede|
  rebase` requires expected state/version/checksum, role, rationale/input.
- `POST /v1/proposals/{id}:assign|delegate|escalate` uses owner policy/expiry.
- `GET /v1/proposals`, `/versions`, `/diff`, `/edges`, `/evidence`, `/comments`,
  `/labels` paginate and ABAC filter.
- `POST /v1/review-labels:validateCorpus` and metrics endpoints produce immutable
  manifests/reports for C13/C14.
- Events: `proposal.created|submitted|corrected|approved|rejected|superseded|
  stale|publishing|active|failed`, `review.label.created`,
  `review.corpus.gate.passed|failed`, assignment/SLO events.

## 9. Processing and State Model

```text
DRAFT -> AWAITING_REVIEW -> APPROVED -> PUBLISHING -> ACTIVE
                         -> REJECTED
                         -> SUPERSEDED
AWAITING_REVIEW -> DRAFT  (correction creates new immutable proposal version)
PUBLISHING -> FAILED -> PUBLISHING  (governed redrive)
```

1. Validate C13/base/context/artifact/policy and create deterministic immutable
   before/after/diff/materiality manifest.
2. Assign owner/reviewer; submit conditionally and notify/escalate.
3. Review writes require current state/version/checksum/authorization.
4. Correction creates a new version, triggers affected C13 verification as
   needed, recalculates diff/materiality and resubmits.
5. Decision validates blockers/separation/material acknowledgements, persists
   immutable decision/labels, then conditionally transitions.
6. Approval creates exact accepted-manifest input and requests C16. Publication
   callback uses expected proposal/version/graph/token result.
7. Corpus validates labels and publishes metrics/gate to C13/C14.

## 10. Failure Semantics

| Code | Class | Required behavior |
|---|---|---|
| `PROPOSAL_INPUT_INVALID_OR_INCOMPLETE` | `DETERMINISTIC_INVALID`/`INCOMPLETE` | No reviewable proposal; exact gaps |
| `PROPOSAL_VERSION_OR_STATE_CONFLICT` | `CONFLICT` | Reject stale write; return current version/state |
| `REVIEWER_UNAUTHORIZED_OR_SEPARATION_FAILED` | `DETERMINISTIC_INVALID` security | Deny/audit; no decision |
| `APPROVAL_BLOCKER_PRESENT` | `INCOMPLETE` | Deny approval; list UNKNOWN/conflict/stale/policy/evidence blocker |
| `BASE_GRAPH_CHANGED` | `CONFLICT` | Rebase/supersede; do not publish stale proposal |
| `LABEL_NOT_MATERIAL_OR_ACKNOWLEDGED` | `DETERMINISTIC_INVALID` corpus | Store unreviewed/audit but exclude accuracy corpus |
| `CORPUS_GATE_INSUFFICIENT_OR_INVALID` | `INCOMPLETE` calibration | No enforcement advancement/confidence calibration use |
| `PUBLICATION_FAILED` | `TRANSIENT`/`CONFLICT` | Preserve approved state, redrive or rebase/supersede |
| `NOTIFICATION_DEPENDENCY_FAILED` | `TRANSIENT` | Retry/escalate; proposal remains durable/queryable |

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C15-SEC-001 | Enterprise SSO/SCIM, domain RBAC, sensitive-metadata ABAC, owner mapping and optional proposer/approver separation must be enforced on every read/write/decision/export. | P0 |
| C15-SEC-002 | Proposal services must have no direct Neptune/OpenSearch mutation; approved handoff is an immutable C12 manifest to a separate C16 publication role. | P0 |
| C15-SEC-003 | Proposal/evidence/comments/labels must not contain payload values, credentials, broad source/model transcript content, or unauthorized sensitive field details; references and redaction apply. | P0 |
| C15-SEC-004 | Decisions/corrections/labels/comments/assignments/delegations/exports/policy changes must be immutable/audited with actor/purpose/version/checksum and S3 data events where required. | P0 |
| C15-SEC-005 | Reviewer/admin/publication/analytics roles and KMS/prefix access must be least privilege/separated; bulk data export requires explicit purpose/approval/watermark. | P0 |

## 12. Scale, Performance, and Availability

- Large proposals store before/after/diff/material-edge pages in C12 S3 and
  indexed DynamoDB/OpenSearch review read models; APIs paginate/filter and never
  load an unbounded graph in one request.
- Proposal creation/diff uses Batch for millions of edges, conditional state for
  lifecycle, and deterministic content addressing for retries.
- Review queue partitions by domain/application/priority; Tier-1 assignment/
  notification/escalation remains isolated from baseline bulk review.
- Labels are append-only, deduplicated by proposal edge/decision/reviewer and
  partitioned for analytics by archetype/provenance/time without mutating source.
- Replication/backups restore proposal/decision/label authority before read
  models; stale workers/notifications cannot decide/publish after recovery.

## 13. Observability

| ID | Signal | Dimensions/alert | Priority |
|---|---|---|---|
| C15-OBS-001 | Proposal state/count/age/latency | type/priority/app/domain/owner | P0 |
| C15-OBS-002 | Assignment/review/SLO/escalation | team/reviewer/tier/state | P0 |
| C15-OBS-003 | Correction/approve/reject/supersede/rebase | provenance/archetype/diff/materiality | P0 |
| C15-OBS-004 | Concurrent/stale/unauthorized/blocker decisions | reason/app/reviewer | P0 |
| C15-OBS-005 | Material labels/unreviewed/corpus coverage | archetype/provenance/hard case/reviewer | P0 |
| C15-OBS-006 | Correction rate/distribution | provenance/archetype/model/analyzer/policy/sample count | P0 |
| C15-OBS-007 | Publication handoff/failure/redrive | proposal/base/target/reason | P0 |

Metrics distinguish accepted proposal from reviewed material edge. Bulk accept
increases adoption/review throughput but not labelled correctness denominator.

## 14. Acceptance Criteria

| ID | Acceptance criterion |
|---|---|
| C15-AC-001 | Given C13 verified baseline/incremental set, C15 creates deterministic immutable before/after proposal with all diff, confidence, gates, evidence, holes, conflicts, coverage and versions. |
| C15-AC-002 | Given two concurrent reviewers, only the expected current version writes; stale correction/decision receives conflict and cannot overwrite. |
| C15-AC-003 | Given correction, prior proposal remains immutable, new version is reverified/diffed, and approval applies only to new exact checksum. |
| C15-AC-004 | Given unauthorized/self-approval under separation or critical blocker/stale base, approval is denied/audited with exact remediation. |
| C15-AC-005 | Given per-edge material acknowledgement, correct label diff is emitted; given bulk accept, edge is `unreviewed` and excluded from corpus metrics. |
| C15-AC-006 | Given fewer/imbalanced/invalid labels or missing hard cases, corpus gate fails; given 200 valid labelled edges across six archetypes/hard cases, exact metrics/gate publish. |
| C15-AC-007 | Given base graph changes before publication, proposal rebases/supersedes and cannot activate against stale expected version. |
| C15-AC-008 | Load/outage/DR meet NFRs with no lost/duplicate decision/label/publication, exact lifecycle and Tier-1 review escalation. |

## 15. Component Test Matrix

| ID | Level | Fixture/precondition | Action | Expected result | Retained evidence |
|---|---|---|---|---|---|
| C15-CT-001 | Golden proposal | Baseline/incremental C13 set with all diff types | Create | Exact immutable proposal/diff/materiality/checksum | Proposal goldens |
| C15-CT-002 | State matrix | Every valid/invalid transition and redrive | Transition | Exact allowed/denied conditional state | State report |
| C15-CT-003 | Concurrent/stale | Two corrections/decisions same expected version | Write | One wins; stale conflict/current returned; history intact | State/audit history |
| C15-CT-004 | Correction | Source/target/transform/path/confidence/evidence changes | Correct/resubmit | New immutable version/reverification/diff/labels | Version chain |
| C15-CT-005 | Authorization | Domain/ABAC/self-approval/delegation expiry | Read/write/approve | Exact allow/deny/separation/audit | IAM/API report |
| C15-CT-006 | Approval blockers | UNKNOWN/identity conflict/incomplete/stale base/digest/policy | Approve | Denied with exact blocker/rebase/waiver path | Decision responses |
| C15-CT-007 | Label materiality | Explicit per-edge, bulk accept, nonmaterial, superseded | Decide/validate | Valid labels or `unreviewed`/excluded | Label/corpus rows |
| C15-CT-008 | Corpus metrics | 200+ labelled six archetypes/hard cases plus duplicates/imbalance | Calculate | Exact counts/correction rates/gate/invalid exclusions | Corpus report |
| C15-CT-009 | Publication conflict | Active graph changes after approval | Publish callback/rebase | No stale active; rebase/supersede history | Proposal/publication history |
| C15-CT-010 | Privacy/export | Sensitive evidence/comments and bulk export | Read/comment/export | ABAC/redaction/purpose/watermark/audit | Security/export scan |
| C15-CT-011 | SLO/notification | Tier-1/standard queues, owner absent, dependency outage | Assign/escalate | Exact notification/escalation; durable proposal | Timeline/metrics |
| C15-CT-012 | Load/DR | 100k diff, concurrent review, failure/Region restore | Create/review/recover | NFR/RPO/RTO, no duplicate/lost decision/label | Load/DR report |

## 16. Integration Obligations

- **INT-102 C13↔C15:** immutable verified set becomes deterministic proposal;
  corrections reverify affected claims and labels feed calibration without
  circular self-validation.
- **INT-103 C14↔C15:** artifact/freshness/phase/blocker/approved package and
  enforcement corpus metrics interoperate.
- **INT-104 C15↔C16:** exact approved checksum/base/manifest publishes with
  conditional callbacks; stale/version conflict rebase/supersede/redrive.
- **INT-105 C15↔C17:** assignment, diff, evidence, two axes, gates, holes,
  conflicts, correction/comments/decision/concurrency/accessibility flows pass.
- **INT-106 SSO/SCIM/catalog↔C15:** owner/domain/role/delegation/separation and
  access removal propagate before every decision.
- **INT-107 C15↔C12:** immutable proposal/correction/decision/label/Object Lock,
  exact references/access/audit/replication/restore pass.
- **INT-108 C15↔C18:** SLO/notification/escalation/audit/security/privacy/export/
  backlog/reconciliation/load/DR runbooks/gates pass.
- **INT-109 C15↔C13/C14 corpus:** 200-edge six-archetype/hard-case quality,
  correction metrics and unreviewed exclusion gate policy activation.

## 17. Definition of Done

- Proposal/diff/materiality/state/assignment/correction/comment/decision/label/
  corpus contracts/services/indexes/immutable writes and notifications exist.
- C15 P0 requirements and C15-CT-001 through C15-CT-012 pass.
- INT-102 through INT-109 pass with production-shaped C12-C17 and enterprise
  identity/ownership systems.
- No production auto-approval/publication exists; authorization/separation,
  concurrency/blockers, immutable history, exact checksum and stale-base tests
  pass.
- Corpus report proves or explicitly fails 200 labelled/six archetype/hard-case
  gate, exact correction metrics and bulk-unreviewed exclusion.
- Load/security/privacy/SLO/outage/DR reports meet NFRs with no lost/duplicate
  decision/label/publication.
- Review/backlog/identity/blocker/correction/rebase/publication/corpus/export/DR
  runbooks and alarms are exercised.

## 18. Implementation Notes

```text
contracts/schemas/proposals/
contracts/schemas/review-labels/
contracts/openapi/review-api.yaml
services/proposal-api/
services/review-assignment/
workers/proposal-diff/
workers/calibration-corpus/
infra/lib/constructs/proposal-review.ts
tests/contract/proposals/
tests/integration/proposal-review/
tests/security/proposal-review/
tests/load/proposal-review/
```

Use TypeScript 5 for APIs/control/IaC, Python 3.12 for large deterministic diff/
corpus jobs. C12 S3 holds immutable content, DynamoDB conditional state/queues,
and a rebuildable search/read model may support review. C15 never gets Neptune
write credentials.

Build order: contracts/state; proposal/diff/materiality; review/concurrency/auth;
correction/reverification; approval/labels; C16/C17; corpus/metrics; load/security/
DR. Launch feature policy requires explicit approval; shadow research cannot
change state.

## 19. Traceability

| Source decision | C15 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| Immutable before/after human review | C15-FR-001-011/018-019 | C15-CT-001-006/009/011 | INT-102-106; publication gate |
| Per-edge labels; bulk unreviewed | C15-FR-012-014/017 | C15-CT-004/007/010 | INT-107/109 |
| 200 labels/six archetypes/correction metrics | C15-FR-015/016 | C15-CT-008 | INT-109; calibration/enforcement gate |
| Security/scale/recovery | C15-SEC-001-005; C15-NFR-001-004 | C15-CT-005/010-012 | INT-108; security/enterprise/DR gates |


---

# 16-publication-and-projections.md

# C16 Fenced Publication and Graph/Search Projections PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C16 |
| Status | Approved for implementation |
| Launch phase | Required before approved lineage becomes queryable |
| Criticality | P0; protects active graph from concurrent, stale, partial, or unapproved mutation |
| Primary owner | Lineage graph publication team |
| Required approvers | Architecture, graph/search, data foundation, governance, operations/DR |
| Upstream dependencies | C01, C06, C12, C15 approved manifest, C14 artifact compatibility |
| Downstream dependencies | C17-C18 |
| Authoritative sources | AWS architecture §§6.12-6.13, 12.2-15; shared state/error model |

## 2. Purpose and Outcomes

C16 is the only service allowed to make approved lineage active. It validates an
immutable accepted manifest, conditionally reserves one application/environment
against the expected prior graph version, issues a lease and fencing token,
stages Neptune into an immutable target-version namespace, verifies it, and
atomically advances the active pointer. It then rebuilds/refreshes OpenSearch and
records a projection watermark. S3 accepted manifests remain authority.

Measurable outcomes:

- Zero unapproved, partial, stale-worker, or expected-version-conflicting graph
  mutation becomes active.
- Concurrent publication for one application/environment produces at most one
  active pointer advance; losing proposal rebases/supersedes without data loss.
- A worker with an expired/lower fencing token cannot commit even if its staging
  work finishes later.
- Neptune/OpenSearch can be emptied and rebuilt from accepted manifests with
  matching node/edge/evidence/version checksums within RPO/RTO.

## 3. Scope and Non-Goals

### In scope

- Accepted-manifest and artifact/version validation, publication reservation/
  lease/fencing, immutable graph export/stage/verify, atomic active pointer,
  proposal callback/state record, OpenSearch projection/watermark, redrive/
  rebase/supersede, retention/cleanup, rebuild/reconciliation/DR.

### Non-goals

- Creating/approving/correcting proposals (C15).
- Letting UI/users/workers directly mutate active Neptune/OpenSearch.
- Treating Neptune/OpenSearch as evidence or accepted-state authority.
- In-place mutation of the namespace addressed by the active pointer.
- Rolling back accepted S3 manifests to hide bad publication; rollback is a new
  governed active pointer/publication from an accepted manifest.

## 4. Actors and Use Cases

| Actor/component | Use case |
|---|---|
| C15 | Request publication of exact approved proposal/manifest/base graph |
| Publication worker | Stage/verify immutable graph target under lease/fence |
| Projection worker | Build OpenSearch from newly active graph/manifest and report watermark |
| C17 query layer | Resolve active pointer/version and expose projection lag |
| Operator | Redrive failed publish, reconcile pointer/namespaces/watermarks, rebuild |
| DR operator | Restore/fail over from replicated manifests/state and verify checksums |

## 5. Component Boundary

### Owned behavior

- `PublicationReservation`, `ActiveGraphPointer`, immutable Neptune graph version,
  graph export, OpenSearch projection/watermark and rebuild/reconcile state.

### Inputs

- C15 approved proposal/version/decision and C12 `AcceptedLineageManifest` exact
  reference/checksum/Object Lock status.
- Expected prior graph version, application/environment, artifact binding,
  publication/projection policy and idempotency.

### Outputs

- Target/active graph version, publication result/audit, proposal callback,
  projection watermark/status, rebuild/reconciliation reports.

### Forbidden behavior

- Accepting draft/rejected/superseded/unlocked/mismatched manifest.
- Mutating active version namespace while readers use it.
- Advancing pointer without valid current reservation/lease/fencing token and
  expected prior graph version.
- Letting OpenSearch success define graph approval/authority.
- Serving a projection version as current without its active pointer/watermark.
- Deleting old graph versions before retention/rollback/audit/rebuild policy.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C16-FR-001 | C16 must accept only a C15 `APPROVED` exact proposal version/checksum and C12 Object-Locked `AcceptedLineageManifest` whose reviewer/decision/application/environment/base/artifact/policy signatures validate. | P0 |
| C16-FR-002 | Publication idempotency must include application, environment, proposal/version, manifest checksum, expected prior graph version, and publication policy; identical requests return prior/resume state and conflicting content is rejected. | P0 |
| C16-FR-003 | C16 must conditionally acquire an application/environment publication reservation requiring the active pointer equal the expected prior graph version and no incompatible live reservation. | P0 |
| C16-FR-004 | Reservation must issue immutable target graph version, owner/attempt, lease expiry, monotonically increasing fencing token, expected prior graph version, manifest reference/checksum and state. | P0 |
| C16-FR-005 | Lease renewal must be conditional on same owner/attempt/fencing/current state and bounded; loss/expiry prevents commit even if worker continues local/staging work. | P0 |
| C16-FR-006 | C16 must generate/verify a checksummed graph export from the accepted manifest and stage Neptune nodes/edges/evidence into an immutable target-version namespace; it must never mutate the active namespace. | P0 |
| C16-FR-007 | Staging must be idempotent by target/entity identity and detect conflicting duplicate properties/edges rather than last-write-win. | P0 |
| C16-FR-008 | Before activation, C16 must verify manifest/export/staged graph versions, canonical URNs, application/environment, expected prior/target, node/edge/evidence/confidence counts, required indexes, referential integrity and checksums/sample/full validation by policy. | P0 |
| C16-FR-009 | One DynamoDB transaction must recheck reservation owner/unexpired lease/fencing token, active pointer expected prior, target verification and approved proposal, then advance `ActiveGraphPointer` and record publication/proposal transition. | P0 |
| C16-FR-010 | A worker with stale/lower fencing token, expired lease, changed active pointer, superseded proposal or mismatched manifest must be unable to advance state. | P0 |
| C16-FR-011 | After pointer activation, C16 must build/refresh OpenSearch only from the newly active version/manifest, atomically expose an index alias/version, and record monotonic `ProjectionWatermark` with graph version/count/checksum/time. | P0 |
| C16-FR-012 | OpenSearch failure/lag after graph activation must not roll back approved Neptune pointer; it must expose lag/error, retry idempotently, and make C17 use documented graph/search freshness behavior. | P0 |
| C16-FR-013 | Publication retry/redrive must resume verified stages using exact references/fence semantics; partial target namespace is never active and may be rebuilt/cleaned only by governed retention procedure. | P0 |
| C16-FR-014 | If expected prior graph changed, C16 must stop with version conflict and request C15 rebase/supersede; it must not merge/rebase graph implicitly. | P0 |
| C16-FR-015 | C16 must retain publication attempts, reservations, graph exports, accepted manifests, prior graph versions, pointer history, projection watermarks, failures and audit according to rollback/governance policy. | P0 |
| C16-FR-016 | C16 must reconcile accepted/approved requests, reservations/leases, target namespaces, active pointers, proposal states, OpenSearch aliases/watermarks and C17 observed versions and repair/alert discrepancies. | P0 |
| C16-FR-017 | C16 must rebuild Neptune/OpenSearch from C12 accepted manifests and active pointer history, validate exact counts/checksums/versions, and prove query readiness before traffic/alias cutover. | P0 |
| C16-FR-018 | Rollback must select a previously accepted immutable manifest or new corrected proposal through the same reservation/fencing/verification protocol and create a new pointer/audit event. | P0 |
| C16-FR-019 | Graph/search schema/index evolution must be versioned, backward/query compatible or use parallel target namespaces/indexes and verified cutover; no in-place incompatible migration. | P1 |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C16-NFR-001 | 95% of approved changes up to 100,000 affected edges must be Neptune-active and OpenSearch-queryable within 60 seconds; larger baselines publish within measured size-class SLO. | P0 |
| C16-NFR-002 | C16 must support 100 concurrent different-application publications and serialize conflicting same-application publication without global lock. | P0 |
| C16-NFR-003 | Active pointer/reservation service must be 99.99% available monthly; publication failure must leave prior active graph readable. | P0 |
| C16-NFR-004 | Projection rebuild/failover must meet 15-minute RPO/four-hour RTO with exact accepted-manifest/pointer/count/checksum reconciliation. | P0 |

## 7. Data and Durable State

`PublicationReservation` includes application/environment, proposal/version/
checksum, accepted manifest ref/checksum/signature, expected prior/target graph,
owner/attempt, fencing token, lease start/expiry/renewals, state, graph export/
verification/projection refs, errors and audit.

`ActiveGraphPointer` includes application/environment/domain, active graph
version, accepted manifest/export refs/checksums, publication/fencing token,
expected prior, activation time, proposal/decision/artifact/policy versions,
Neptune namespace, OpenSearch projection watermark/status and pointer version.

`GraphExportManifest` lists canonical nodes/edges/evidence/confidence/version
files with shard refs/checksums/counts, graph schema/index version, application/
environment/base/target and aggregate checksum.

`ProjectionWatermark` includes graph version, OpenSearch index/alias/schema,
expected/actual document counts/checksum, started/completed, lag/status/error,
retry/rebuild and audit.

C12 stores accepted/export/rebuild/audit. DynamoDB stores reservation/pointer/
watermark/idempotency/history with PITR/conditional transactions. Neptune stores
versioned immutable namespaces; OpenSearch stores versioned indexes/aliases.

## 8. Interfaces and Contracts

- `POST /v1/publications` accepts approved proposal/decision/manifest refs,
  expected prior, policy and idempotency; returns publication/target/status.
- `POST /v1/publications/{id}:renew|redrive|cancel|reconcile` requires expected
  state/fencing token/role/reason.
- Internal stage APIs register graph export, staging, verification, pointer commit
  and projection result with exact attempt/fence/checksum.
- `GET /v1/graph-pointers/{environment}/{application}`, publication history,
  projection watermarks and rebuild status provide authoritative read metadata.
- `POST /v1/projections:rebuild` accepts accepted-manifest set/active history,
  target Region/schema and dry-run/verification/cutover policy.
- Events: `publication.reserved|staged|verified|active|failed|conflicted`,
  `projection.started|ready|lagging|failed|rebuilt`, `graph.pointer.changed`.

## 9. Processing and State Model

```text
REQUESTED -> RESERVING -> EXPORTING -> STAGING -> VERIFYING
          -> COMMITTING -> GRAPH_ACTIVE -> PROJECTING -> ACTIVE
```

Alternatives: `DUPLICATE`, `VERSION_CONFLICT`, `FAILED_REDRIVABLE`,
`CANCELLED_BEFORE_COMMIT`, `PROJECTION_LAGGING`, `SUPERSEDED`.

1. Verify approved decision/manifest/Object Lock/signature/artifact/base/policy.
2. Conditional reserve and issue target/lease/fencing token.
3. Generate/read graph export and stage immutable target namespace under fence
   heartbeats; idempotently validate conflicts.
4. Verify target/manifest/count/checksum/referential/index invariants.
5. Transactionally recheck fence/lease/prior/proposal and advance pointer/state.
6. Notify C15 graph active, emit pointer event, project OpenSearch and watermark.
7. Reconcile C17 visibility; complete or keep projection lagging/retry status.

Before step 5, failure leaves active pointer unchanged. After step 5, graph is
approved active; projection failure is a separate recoverable read-model state.

## 10. Failure Semantics

| Code | Class | Required behavior |
|---|---|---|
| `MANIFEST_OR_APPROVAL_INVALID` | `DETERMINISTIC_INVALID` | No reservation/stage; audit exact mismatch |
| `EXPECTED_PRIOR_GRAPH_CHANGED` | `CONFLICT` | Stop; rebase/supersede via C15 |
| `RESERVATION_BUSY` | `TRANSIENT`/`CONFLICT` | Wait/defer or surface competing proposal; no global lock |
| `LEASE_EXPIRED_OR_STALE_FENCE` | `CONFLICT` | Deny renew/result/commit; reconcile target |
| `TARGET_CONTENT_CONFLICT` | `CONFLICT` | Fail verification; preserve diagnostics, no active |
| `TARGET_VERIFICATION_FAILED` | `DETERMINISTIC_INVALID` | No pointer advance; retain report/target under policy |
| `NEPTUNE_THROTTLED_OR_UNAVAILABLE` | `TRANSIENT` | Bounded retry/redrive before commit; prior active remains |
| `POINTER_TRANSACTION_CONFLICT` | `CONFLICT` | Re-read current; no blind retry across changed expected prior |
| `OPENSEARCH_PROJECTION_FAILED_OR_LAGGING` | `INCOMPLETE` projection | Graph remains active; alert/retry/rebuild/watermark visible |
| `REBUILD_MISMATCH` | `DETERMINISTIC_INVALID` | No cutover; retain old serving projections/report |

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C16-SEC-001 | Only C16 publication roles may write target Neptune namespaces, graph pointers or OpenSearch indexes/aliases; C15/UI/analyzers/query users have no mutation permission. | P0 |
| C16-SEC-002 | Publication roles must be application/environment/stage scoped, use private networking/TLS/KMS/Secrets, exact C12 prefixes/Neptune/OpenSearch resources where possible, and separate reserve/stage/commit/operate duties. | P0 |
| C16-SEC-003 | Sensitive metadata fields/evidence references must retain ABAC/redaction in graph/search; projection must not denormalize unauthorized evidence bodies or payloads. | P0 |
| C16-SEC-004 | Accepted manifest/signature/Object Lock, fence/pointer transaction, target counts/checksums and image/IaC versions must be audited for every attempt/cutover/rollback/rebuild. | P0 |
| C16-SEC-005 | Cancel/redrive/rebuild/cleanup/rollback/schema migration requires scoped operator role, reason, expected state/fence, dry-run/verification and immutable audit; no direct console mutation is an approved path. | P0 |

## 12. Scale, Performance, and Availability

- Partition publication locks by organization/environment/application; unrelated
  apps publish concurrently. Domain-wide proposal uses a manifest of app-scoped
  publications plus a governed aggregate visibility contract, not a global
  mutable transaction.
- Graph exports shard by node/edge hash; Batch prepares/validates large exports.
  Neptune bulk/Gremlin/OpenCypher loader choice is benchmarked, idempotent and
  versioned. OpenSearch bulk indexes versioned targets then atomically moves alias.
- Active graph pointer reads use strongly consistent DynamoDB where decision
  requires. C17 caches only with pointer version/watermark and bounded TTL.
- Neptune writer/read replicas and OpenSearch Multi-AZ remain serving prior
  active versions during publication failure. Rebuild/failover uses warm Region
  C12/DynamoDB replicated state and IaC.

## 13. Observability

| ID | Signal | Dimensions/alert | Priority |
|---|---|---|---|
| C16-OBS-001 | Publication state/latency/counts | application/domain/size/policy/Region | P0 |
| C16-OBS-002 | Reservation/lease/fencing/conflict | app/token/age/owner/reason | P0 |
| C16-OBS-003 | Stage/verify node-edge-evidence counts/checksums | target/base/schema/status | P0 |
| C16-OBS-004 | Pointer transaction/active version | app/env/old/new/proposal/fence | P0 |
| C16-OBS-005 | Projection watermark/lag/failure | graph/index/alias/schema/seconds | P0 |
| C16-OBS-006 | Orphan target/stale worker/reconciliation | namespace/proposal/state/action | P0 |
| C16-OBS-007 | Neptune/OpenSearch capacity/query/build/cost | cluster/domain/app/operation | P1 |
| C16-OBS-008 | Rebuild/DR RPO/RTO/count/checksum | Region/manifest set/status | P0 |

C17 displays active graph and projection watermark/lag. Reconciliation asserts
one active pointer target exists/verified, proposal state matches, and no stale
fence changed it.

## 14. Acceptance Criteria

| ID | Acceptance criterion |
|---|---|
| C16-AC-001 | Given exact approved Object-Locked manifest/base, C16 reserves/stages/verifies/transactionally advances one active pointer and projects matching OpenSearch watermark. |
| C16-AC-002 | Given two concurrent proposals for the same expected prior, at most one activates; the other receives version conflict and requires C15 rebase/supersede. |
| C16-AC-003 | Given worker lease expiry/newer fencing token, old worker cannot renew/register/commit even after staging completes. |
| C16-AC-004 | Given partial Neptune write/count/checksum/referential failure, target never becomes active and prior pointer remains serving. |
| C16-AC-005 | Given OpenSearch failure after pointer advance, Neptune graph remains active, lag is visible, C17 uses documented behavior, and idempotent retry reaches exact watermark. |
| C16-AC-006 | Given duplicate/redrive, completed verified stages reuse exact outputs without duplicate graph version/pointer/proposal transition. |
| C16-AC-007 | Given empty/corrupt Neptune/OpenSearch operational projections, rebuild from accepted manifests/pointer history matches nodes/edges/evidence/checksums before cutover. |
| C16-AC-008 | Load/failure/Region recovery meet NFR/RPO/RTO with prior active availability and exact proposal/manifest/pointer/projection reconciliation. |

## 15. Component Test Matrix

| ID | Level | Fixture/precondition | Action | Expected result | Retained evidence |
|---|---|---|---|---|---|
| C16-CT-001 | Contract/security | Approved versus draft/rejected/unlocked/mismatched manifests | Request | Only exact approved accepted manifest reserves | Validation/audit report |
| C16-CT-002 | Happy path | Small/large accepted manifest/base | Publish | Exact target/count/checksum/pointer/proposal/watermark | Publication golden |
| C16-CT-003 | Concurrency | Two same-app proposals same prior; many different apps | Publish concurrently | One same-app winner; unrelated parallel; no global lock | State/history/load |
| C16-CT-004 | Fencing | Lease expiry/renewal race/new worker/old late callback | Stage/commit | Only current fence operates/commits | Token/state/audit |
| C16-CT-005 | Partial/conflict | Missing/conflicting node/edge, checksum/count/ref integrity failure | Stage/verify | No activation; prior serving; diagnostics retained | Verification report |
| C16-CT-006 | Pointer transaction | Expected prior/proposal/reservation changes at commit | Commit | Atomic success or conflict, never partial pointer/state | DynamoDB transaction history |
| C16-CT-007 | OpenSearch lag | Fail/throttle midway after graph active | Project/query/retry | Visible lag, no rollback, exact eventual alias/watermark | Watermark/query report |
| C16-CT-008 | Idempotency/redrive | Duplicate request/fail at each stage/redrive | Publish | One target/active transition; valid stage reuse | Attempt/stage refs |
| C16-CT-009 | Authorization/privacy | UI/analyzer/cross-domain/direct console and sensitive fields | Mutate/project/query | Mutation denied/audited; ABAC/redaction preserved | IAM/security scan |
| C16-CT-010 | Reconciliation/cleanup | Orphan targets/stale reservations/mismatched proposal/watermark | Reconcile/cleanup | Exact safe action; retained versions not deleted early | Reconciliation report |
| C16-CT-011 | Rebuild/rollback | Empty projections, prior accepted manifest, bad candidate rebuild | Rebuild/cutover/rollback | Verified exact cutover; mismatch stays isolated; rollback new event | Rebuild/rollback report |
| C16-CT-012 | Load/chaos/DR | 100 concurrent apps, large graphs, service/Region failure | Publish/recover | NFR/RPO/RTO/prior availability/exact reconciliation | Load/chaos/DR report |

## 16. Integration Obligations

- **INT-110 C12/C15↔C16:** Object-Locked accepted manifest/approval/checksum/base/
  artifact validation, exact access and lifecycle pass.
- **INT-111 C06↔C16:** workflow submit/retry/redrive/cancel/reconcile uses exact
  idempotency/stage/fence/result and no duplicate state.
- **INT-112 C16↔DynamoDB/Neptune:** reservation/lease/fence/stage/verify/atomic
  pointer/concurrent/stale worker/partial failure behavior pass.
- **INT-113 C16↔OpenSearch:** active-version bulk build/alias/watermark/lag/retry/
  schema/ABAC behavior passes.
- **INT-114 C16↔C17:** active pointer, bounded graph and search versions,
  projection lag/error and query cutover semantics are consistent.
- **INT-115 C16↔C15:** proposal publishing/active/failed/version-conflict callbacks
  preserve state and drive rebase/supersede/redrive exactly.
- **INT-116 C16↔C18 security/operations:** IAM/network/KMS/audit/alarms/runbooks/
  reconciliation/cleanup/capacity/cost/chaos pass.
- **INT-117 C12/C16/C18 DR:** restore accepted manifests/pointer history and
  rebuild Neptune/OpenSearch within RPO/RTO with exact checksums before traffic.

## 17. Definition of Done

- Publication contracts/services/IaC implement manifest validation, app-scoped
  reservation/lease/fencing, export, immutable target, verification, atomic
  pointer, proposal callback, OpenSearch projection/watermark, reconciliation,
  rebuild/rollback and telemetry.
- C16 P0 requirements and C16-CT-001 through C16-CT-012 pass.
- INT-110 through INT-117 pass with production-shaped data/state/graph/search/
  review/query/operations components.
- Concurrency/stale fence/partial failure/redrive tests prove no unapproved or
  partially active graph and prior active remains available.
- Security/privacy proves only C16 mutation, stage-role separation, ABAC, no
  payload denormalization, audited operations and no direct-console path.
- Load/chaos/rebuild/DR reports meet NFR/RPO/RTO and exact accepted manifest/
  proposal/pointer/node/edge/evidence/watermark reconciliation.
- Publication/fence/version conflict/projection lag/rebuild/rollback/cleanup/DR
  runbooks and alarms are exercised with real IDs.

## 18. Implementation Notes

```text
contracts/schemas/publication/
services/publication-controller/
workers/graph-exporter/
workers/neptune-projector/
workers/opensearch-projector/
workers/projection-reconciler/
infra/lib/stacks/projection-stack.ts
infra/lib/constructs/publication-state.ts
docs/runbooks/publication/
tests/contract/publication/
tests/integration/publication/
tests/load/publication/
tests/chaos/publication/
```

Use TypeScript 5 for controller/transaction/IaC and Python 3.12 for graph export/
projection/rebuild workers. Benchmark Neptune bulk loader versus idempotent
transactions and pin one versioned strategy per graph schema/size. OpenSearch
uses versioned indexes plus atomic alias cutover; never rebuild in place.

Build order: contracts/state/fencing; export; target stage/verify; pointer txn;
C15 callback; OpenSearch/watermark/C17; reconcile/redrive; rebuild/rollback;
load/security/DR. Feature canary publishes a nonserving application/domain and
verifies before allowing production active pointer transitions.

## 19. Traceability

| Source decision | C16 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| Approved manifest plus fenced publication | C16-FR-001-010/013-015/018 | C16-CT-001-006/008/011 | INT-110-112/115; publication gate |
| Rebuildable Neptune/OpenSearch projections | C16-FR-006-008/011-012/016-019 | C16-CT-005/007/010-012 | INT-113/114/117 |
| Concurrency/performance/availability | C16-NFR-001-004 | C16-CT-003/012 | INT-112/116; enterprise gate |
| Security/privacy/audit/operations | C16-SEC-001-005 | C16-CT-009-012 | INT-116/117; security/DR gates |


---

# 17-query-api-review-ui-and-timeline.md

# C17 Query APIs, Review UI, and Run Timeline PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C17 |
| Status | Approved for implementation |
| Launch phase | Required for pilot review, publication validation, and production query |
| Criticality | P0; the governed user and machine access boundary |
| Primary owner | Lineage experience and API team |
| Required approvers | Product, architecture, governance, application owners, security, accessibility, operations |
| Upstream dependencies | C01, C06, C12-C16, enterprise identity/ownership |
| Downstream dependencies | Users, incident response, automation clients, C18 operations |
| Authoritative sources | AWS architecture §§6.12-6.13, 12, 14, 16-18; component package design |

## 2. Purpose and Outcomes

C17 provides the only supported user and application access to approved lineage,
evidence, proposal review, coverage, and collection status. It resolves one
active graph version per request, performs bounded traversal in Neptune, uses
OpenSearch for discovery with an explicit projection watermark, applies
evidence-level authorization, and renders review and run timeline experiences
without hiding stale, incomplete, conflicting, or unresolved state.

Measurable outcomes:

- A permitted user can find an asset, inspect upstream/downstream lineage,
  evidence, two independent confidence axes, coverage, and the exact active
  version without observing a mixed-version response.
- One-hop graph requests return within two seconds p95 at target graph size,
  and every traversal has deterministic depth/result/time/cost bounds.
- A reviewer can understand a before/after proposal, correct or decide it
  through C15 optimistic concurrency, and never overwrite a newer version.
- Every collection run exposes intake through publication and projection as a
  correlated run timeline including retry, redrive, incomplete, and stale states.
- Primary user journeys meet WCAG 2.2 AA and are exercised by automated and
  manual assistive-technology tests.

## 3. Scope and Non-Goals

### In scope

- Versioned OpenAPI 3.1 read/review/timeline/export interfaces and generated
  client compatibility.
- Active-version graph traversal, asset/field discovery, autocomplete, filters,
  evidence/coverage/conflict/hole views, proposal before/after review, and
  collection/publication timeline.
- Web application shell, routes, accessibility, responsive layout, visual
  empty/loading/error/stale/partial states, and deep links.
- Enterprise authentication, domain RBAC, sensitive-metadata ABAC, purpose-
  bound evidence access, audit and export controls.

### Non-goals

- Accepting arbitrary Gremlin, openCypher, Lucene, or OpenSearch DSL from users.
- Mutating graph/search projections, evidence, confidence, proposals, or
  workflow history directly.
- Combining structural confidence and derivational confidence into one score.
- Treating an OpenSearch result as current when its projection watermark lags
  the active graph version.
- Hiding missing, stale, excluded, conflicting, unknown, unresolved, redacted,
  or incomplete data behind a generic success state.
- Replacing C15 decision policy, C16 publication authority, or C18 operations.

## 4. Actors and Use Cases

| Actor | Primary use case |
|---|---|
| Application owner/reviewer | Review before/after lineage, evidence, holes and approve/correct/reject |
| Data engineer/steward | Find fields, traverse dependencies, inspect provenance and conflicts |
| Incident responder | Perform bounded blast-radius traversal on approved state |
| Developer | Inspect why a CI/deployment lineage decision occurred |
| Auditor/governance user | Export an authorized, versioned evidence/decision report |
| Platform operator | Diagnose a run timeline, redrive link, projection lag or partial state |
| Automation client | Query version-pinned lineage through stable OpenAPI contracts |

## 5. Component Boundary

### Owned behavior

- API composition, query validation/bounds, active-version pinning, pagination,
  search/graph consistency metadata, response redaction, and export audit.
- UI navigation, discovery, graph/detail/review/timeline rendering, accessible
  interaction, optimistic edit presentation and user-visible failure states.

### Inputs

- C16 active pointer and projection watermark; Neptune/OpenSearch projections.
- C12 evidence references; C13 gates/confidence/coverage/conflicts/holes.
- C15 proposal/version/diff/decision APIs; C06/C03/C14/C16 stage histories.
- C01 URNs/schema versions; C18 identity, ownership, policy, audit and telemetry.

### Outputs

- Authorized version-pinned query/search/evidence responses, review commands to
  C15, timeline views, audited exports and user-experience telemetry.

### Forbidden behavior

- Querying Neptune or OpenSearch without resolving and pinning the permitted
  application/environment active graph version.
- Mixing active graph version, proposal version, evidence version, or search
  watermark without labeling and enforcing the allowed consistency policy.
- Returning data outside caller domain/sensitivity scope through counts,
  autocomplete, graph topology, errors, exports, logs, traces or caches.
- Executing unbounded traversal/search or client-selected backend queries.
- Retrying a non-idempotent review write after an ambiguous response without
  reading its operation/result identity.
- Making a stale or partial page appear current or complete.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C17-FR-001 | C17 must publish a versioned OpenAPI 3.1 contract for applications, assets, fields, lineage, search, evidence, proposals/review, coverage, conflicts, holes, runs, stages, projection status and exports, with valid/invalid examples and generated-client tests. | P0 |
| C17-FR-002 | Every graph/search/evidence request must resolve one application/environment active graph version and return it with accepted-manifest checksum, projection watermark, generated-at time and consistency status. | P0 |
| C17-FR-003 | Graph APIs must implement bounded traversal with allowlisted directions/relationships, default one hop, maximum two hops, maximum 10,000 returned vertices/edges, server timeout, response-size cap and continuation rather than arbitrary graph language. | P0 |
| C17-FR-004 | A continuation cursor must be opaque, signed, expiring and bound to caller authorization, query/filter/order, application/environment, active graph version and projection version; a changed version returns a restart conflict rather than mixed results. | P0 |
| C17-FR-005 | Search must support asset/field text, exact canonical URN, owner/domain/application/environment/type filters, autocomplete and stable relevance/order, while disclosing OpenSearch index version and projection lag. | P0 |
| C17-FR-006 | When OpenSearch lags the active graph version, C17 must show a stale banner/status, return graph-version-qualified results, disable any unsafe completeness claim, and either use an approved graph fallback for exact lookup or return retry guidance. | P0 |
| C17-FR-007 | Lineage responses must expose canonical endpoints, direction/path, effective versions/artifacts, transformation/path semantics, evidence provenance, G1-G5 results, structural confidence, derivational confidence, calibration/caps, freshness and accepted proposal/version. | P0 |
| C17-FR-008 | Evidence detail must authorize each reference at request time, return metadata/redacted preview or short-lived download only within purpose/sensitivity policy, and distinguish unavailable, redacted, expired and unauthorized without leaking existence. | P0 |
| C17-FR-009 | Coverage views must show included/excluded/mixed/unknown inventory, analyzed/native/opaque/runtime counts, holes, dropped edges, conflicts, incomplete stages, stale inputs and coverage denominator/version; no empty collection may display as 100 percent. | P0 |
| C17-FR-010 | Review UI must render immutable before/after nodes/edges and added/removed/modified/no-impact changes with side-by-side evidence, two confidence axes, coverage, freshness, holes, conflicts, blockers, materiality and reviewer assignment/SLO. | P0 |
| C17-FR-011 | Correction, comment, assignment, approve and reject actions must call C15 with exact proposal/version/checksum/base/expected state and idempotency identity; a concurrent edit returns the new version and requires explicit reload/rebase. | P0 |
| C17-FR-012 | Bulk acceptance must state that material edges remain unreviewed for calibration, require explicit confirmation, and never imply correctness labels were created. | P0 |
| C17-FR-013 | The run timeline must correlate intake, inventory, classification, context, scheduling, lane collection, evidence, verification, CI/freshness, proposal/review, publication and projection stages by tenant/domain/application/run/correlation and show attempts, durations, retry/redrive, warnings, errors and artifact refs. | P0 |
| C17-FR-014 | Timeline stage state must distinguish queued, running, succeeded, incomplete, failed, quarantined, cancelled, superseded, retrying, awaiting review, publishing, active and projection lag, with reason/error class and permitted next action. | P0 |
| C17-FR-015 | Deep links must encode stable resource IDs and version/context but never credentials or sensitive raw data; historical links must render read-only historical state clearly separated from active state. | P0 |
| C17-FR-016 | Exports must be asynchronous for large results, bound to exact query/version/authorization/purpose, encrypted, checksummed, expiring, redacted, audited and downloadable by the requesting identity or approved delegate only. | P0 |
| C17-FR-017 | The UI must implement keyboard-complete operation, semantic landmarks/headings/tables, visible focus, skip links, accessible names, non-color-only states, graph textual equivalent, zoom/reflow, reduced motion, screen-reader announcements and WCAG 2.2 AA contrast. | P0 |
| C17-FR-018 | Loading, empty, no-access, redacted, partial, stale, conflict, dependency-error, rate-limit and timeout states must state what is known, exact version/time and safe retry/help action without losing user filters/context. | P0 |
| C17-FR-019 | API and UI caches must be private and authorization/version keyed, invalidate or expire on active-pointer/ownership/policy change, and never serve a response to a caller with different effective access. | P0 |
| C17-FR-020 | C17 must provide stable machine-readable problem details with correlation ID, safe error code, retryability and field violations; internal identifiers, queries, policy details and sensitive existence must not leak. | P0 |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C17-NFR-001 | Bounded one-hop traversal must complete within two seconds p95 and five seconds p99 at representative target graph size; search/autocomplete must complete within one second p95. | P0 |
| C17-NFR-002 | Read APIs and the web shell must be 99.95 percent available monthly; review writes must preserve C15 consistency and never acknowledge an uncommitted decision. | P0 |
| C17-NFR-003 | APIs must sustain 500 read requests/second and 50 concurrent complex traversals per domain test profile while enforcing per-user/domain quotas and fair degradation. | P0 |
| C17-NFR-004 | Standard pages must meet agreed web performance budgets on enterprise desktop/mobile profiles and primary journeys must have zero critical accessibility violations. | P0 |
| C17-NFR-005 | Active-pointer change must be visible to uncached exact graph reads within five seconds and search status must expose lag until its C16 watermark catches up. | P0 |

## 7. Data and Durable State

C17 owns no canonical lineage state. It stores only versioned API specifications,
UI configuration, private short-lived response caches, export jobs, user
preferences that do not affect approval, and audit/telemetry.

Query context contains caller/tenant/domain/roles/attributes/purpose,
application/environment, active graph version, accepted-manifest checksum,
projection watermark, query hash, limits, cursor, request/correlation ID and
policy version. Cache keys include every field that can alter authorization or
content.

ExportJob contains request/query hash, exact graph/search/proposal versions,
authorization/purpose snapshot, redaction policy, state, output C12 reference/
checksum, expiry, requester/delegate and audit reference. Export content is
immutable and never becomes graph authority.

UI routes use canonical URNs and immutable IDs. Browser storage may retain
non-sensitive presentation preferences only; tokens, evidence, proposal content,
exports and graph results must not be persisted in local storage.

## 8. Interfaces and Contracts

- GET /v1/applications and /v1/applications/{application}/environments returns
  authorized scope, active graph version and coverage summary.
- GET /v1/assets and /v1/search provide discovery/filter/autocomplete with
  signed cursor and search projection watermark.
- GET /v1/lineage/{urn}?direction=upstream|downstream&depth=1..2 returns bounded
  version-pinned nodes/edges/continuation and truncation reason.
- GET /v1/assets/{urn}, /fields/{urn}, /edges/{edgeId}, /evidence/{evidenceId},
  /coverage, /conflicts and /holes return authorized detail.
- GET /v1/proposals and proposal diff/material edges delegate reads to C15;
  POST review actions are conditional C15 commands, not C17 state changes.
- GET /v1/runs/{runId}/timeline and /stages compose immutable stage events and
  C16 projection status in monotonic event/attempt order.
- POST /v1/exports and GET /v1/exports/{id} implement asynchronous governed
  export. DELETE cancels only a not-yet-complete job and preserves audit.
- All responses use schema/content version, request/correlation ID, ETag,
  Cache-Control, RFC-style problem details and rate-limit metadata. Writes use
  Idempotency-Key and If-Match/expected version.

Compatibility is additive within a major version. Removing/renaming a field,
changing confidence meaning, pagination order, bounds, redaction or default
version requires a new major contract and overlapping deprecation window.

## 9. Processing and State Model

Read request:

1. Authenticate, authorize application/domain/purpose and assign correlation.
2. Validate allowlisted query and hard bounds before backend access.
3. Resolve and pin C16 active graph version plus projection watermark.
4. Query version namespace/index, apply row/field/evidence authorization and
   redaction, then verify returned version/count/truncation metadata.
5. Emit safe response/audit/telemetry; cursor binds the exact context.

Review write:

1. Read authorized immutable proposal/version and current ETag.
2. Collect explicit action/rationale/material acknowledgements.
3. Send idempotent expected-state/version/checksum command to C15.
4. On success, render returned new version/state; on conflict, preserve local
   draft separately, display differences and require deliberate reload/reapply.

Run timeline:

1. Load normalized stage events by run/correlation and stable event sequence.
2. Join attempts/artifact refs without rewriting source events.
3. Add current proposal/publication/projection status as labeled observations.
4. Mark delayed/missing/out-of-order stages; never infer success from absence.

## 10. Failure Semantics

| Code | Class | Required behavior |
|---|---|---|
| QUERY_INVALID_OR_UNBOUNDED | DETERMINISTIC_INVALID | Reject before backend query; safe field/bound guidance |
| ACTIVE_VERSION_CHANGED | CONFLICT | Abort cursor/request and require restart on new version |
| SEARCH_PROJECTION_LAGGING | INCOMPLETE | Return explicit watermark/lag and safe fallback/retry |
| GRAPH_OR_SEARCH_UNAVAILABLE | TRANSIENT | Bounded retry/circuit break; status and correlation ID |
| EVIDENCE_UNAVAILABLE_OR_REDACTED | INCOMPLETE/security | No existence leak; show permitted state/action |
| REVIEW_VERSION_CONFLICT | CONFLICT | No overwrite; return current C15 version/ETag and reload path |
| REVIEW_DEPENDENCY_FAILED | TRANSIENT | Resolve idempotency result before user retry |
| TIMELINE_GAP_OR_DELAY | INCOMPLETE | Render known events and missing-stage diagnostic |
| EXPORT_TOO_LARGE_OR_POLICY_DENIED | DETERMINISTIC_INVALID/security | Deny/audit; smaller query or policy path |
| RATE_LIMITED | TRANSIENT/capacity | Retry-After and fair quota; no silent partial result |

Dependency retries are read-only or idempotency-resolved. C17 never fabricates
success during backend failure, never falls back to an unauthorized source, and
never converts a partial query into a complete status.

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C17-SEC-001 | Users must authenticate through enterprise federation/IAM Identity Center path; API authorization must enforce tenant/domain/application RBAC and sensitive-metadata ABAC on every resource, relationship, count, search suggestion, evidence item and export. | P0 |
| C17-SEC-002 | API/UI compute must use private networking to Neptune/OpenSearch/internal services, TLS, managed WAF/rate limits, short-lived credentials, encrypted stores and no public projection endpoint. | P0 |
| C17-SEC-003 | Browser protections must include secure HttpOnly SameSite cookies or approved token pattern, CSRF protection, strict CSP, output encoding, dependency integrity, clickjacking defense and no tokens/sensitive metadata in URLs/logs/analytics/storage. | P0 |
| C17-SEC-004 | Review/decision/export/evidence access and privileged searches must emit immutable CloudTrail/application audit with actor, purpose, scope, versions, outcome and correlation, while audit itself excludes payload values. | P0 |
| C17-SEC-005 | Backend queries must be parameterized/allowlisted; arbitrary graph/search language, SSRF destinations, user-selected S3 URIs and cross-tenant identifiers must be rejected before dependency access. | P0 |
| C17-SEC-006 | C17 roles must be read-only for Neptune/OpenSearch/C12 evidence and have only C15 command permissions; no UI or API identity may advance the C16 active pointer. | P0 |

## 12. Scale, Performance, and Availability

- Benchmark with the target node/edge distribution, high-degree hubs, 10,000
  repositories, cold/warm caches, permitted/redacted mixes and concurrent users.
- Query guards apply before and during traversal: depth, fan-out, vertices,
  edges, time, bytes, concurrency and per-domain cost. Truncation is explicit.
- Neptune read replicas serve pinned read traffic; circuit breakers/bulkheads
  isolate search, graph, evidence, review, timeline and export dependencies.
- OpenSearch is discovery only. Exact graph detail uses the active Neptune
  namespace; search lag cannot make an older projection appear current.
- Multi-AZ stateless API/UI deploys retain prior version during rollout.
  Contracts and UI remain backward-compatible across rolling deployment.
- Large exports run asynchronously with bounded concurrency and never consume
  interactive query capacity.

## 13. Observability

| ID | Signal | Dimensions / alarm |
|---|---|---|
| C17-OBS-001 | API rate/latency/error and backend time | route/domain/status/version; SLO burn |
| C17-OBS-002 | Traversal vertices/edges/depth/truncation/cost | route/domain/bound; abuse/capacity alarm |
| C17-OBS-003 | Search active-version versus projection watermark lag | application/environment/index; lag alarm |
| C17-OBS-004 | Authorization deny/redaction/evidence/export events | policy/domain/action; anomaly alarm |
| C17-OBS-005 | Review submit/conflict/retry/result latency | action/proposal/domain; conflict/error alarm |
| C17-OBS-006 | Timeline gap/out-of-order/stage delay | run/stage/error class; completeness alarm |
| C17-OBS-007 | UI route/Web Vitals/client error/accessibility checks | build/route/browser; regression gate |
| C17-OBS-008 | Cache hit/invalidation/version/access-key isolation | cache/route/policy; leakage invariant |

Logs/traces use the common correlation contract and safe resource hashes. The
user can copy request/correlation ID. Dashboards show query SLO, projection lag,
review experience, timeline completeness, export backlog, access denials and
dependency saturation without sensitive payloads.

## 14. Acceptance Criteria

| ID | Given / When / Then |
|---|---|
| C17-AC-001 | Given an authorized active application, when a user searches and opens a field, then discovery, one-hop lineage, evidence, confidence, coverage and versions are consistent and within SLO. |
| C17-AC-002 | Given high-degree/cyclic lineage, when depth/result/time bounds are reached, then traversal terminates, labels truncation and supplies a version-bound cursor without backend language exposure. |
| C17-AC-003 | Given OpenSearch watermark behind active Neptune, when search/detail load, then stale state and exact versions are visible and no completeness/currentness claim is made. |
| C17-AC-004 | Given sensitive/cross-domain evidence, when an unauthorized caller searches, traverses, opens or exports it, then content/existence/count leakage is denied and audited. |
| C17-AC-005 | Given a proposal, when reviewer compares before/after and corrects/approves, then the exact C15 version/checksum is updated; concurrent stale action cannot overwrite. |
| C17-AC-006 | Given failed/retried/redriven collection, when timeline opens, then every attempt, gap, artifact, reason, next action, publication and projection status is ordered and correlated. |
| C17-AC-007 | Given keyboard/screen-reader/reflow/reduced-motion use, when primary journeys execute, then WCAG 2.2 AA behavior and textual graph equivalence pass. |
| C17-AC-008 | Given active pointer/ownership/policy change, when cached or cursor request repeats, then stale/cross-authority data is not served and restart/re-authorization is explicit. |

## 15. Component Test Matrix

| ID | Type | Fixture / fault | Action | Expected result | Evidence |
|---|---|---|---|---|---|
| C17-CT-001 | Contract | OpenAPI valid/invalid/golden and previous client | Generate/validate/call | Schemas/examples/problem details compatible | Contract report |
| C17-CT-002 | Graph happy/bounds | Pilot, cycle, high-degree, 10k-result graph | One/two-hop queries | Correct version/path; hard bounds/truncation/cursor | Query golden/plan |
| C17-CT-003 | Version consistency | Pointer changes between resolve/query/page | Query/page | One pinned version or restart conflict; never mixed | Version trace |
| C17-CT-004 | Search lag | OpenSearch old/missing/partial watermark | Search/open detail | Stale state/fallback/retry; no false completeness | UI/API capture |
| C17-CT-005 | Confidence/coverage | Two axes, caps, unknowns, holes/conflicts | Render/API | Separate axes/provenance/G1-G5/denominator/states | Snapshot/schema |
| C17-CT-006 | Review concurrency | Before/after proposal; two browser versions | Correct/approve concurrently | Exact C15 write; stale loses without overwrite | C15/audit record |
| C17-CT-007 | Authorization/privacy | Cross-domain/sensitive/hidden evidence and counts | Search/query/export/direct ID | Denied/redacted/no existence leak; audited | IAM/ABAC report |
| C17-CT-008 | Timeline/recovery | Retry, redrive, cancel, quarantine, delayed event | Open timeline | Ordered attempts/gaps/reasons/actions/watermark | Timeline golden |
| C17-CT-009 | Accessibility | Keyboard, screen reader, 200% zoom, contrast, reduced motion | Complete primary journeys | WCAG 2.2 AA; textual graph equivalent | axe/manual report |
| C17-CT-010 | Browser steel thread | Mixed application baseline through active graph | Search/review/traverse/timeline | Complete usable journey with exact versions | Playwright trace |
| C17-CT-011 | Cache/security | Ownership/policy/pointer change and poisoned cursor | Repeat requests | Reauthorize/invalidate/reject; no cross-user content | Cache/security log |
| C17-CT-012 | Load/availability | Target graph, 500 rps, hot hubs, dependency throttles | Query/search/export | NFR p95/p99, fair limits, graceful errors | Load/chaos report |

## 16. Integration Obligations

- **INT-118 C16↔C17:** active pointer, immutable namespace, accepted checksum and
  projection watermark changes produce version-consistent graph/search reads.
- **INT-119 C15↔C17:** proposal/diff/materiality/assignment and conditional
  correction/decision preserve immutable version, auth and concurrency.
- **INT-120 C12↔C17:** evidence/export references enforce checksum, Object Lock,
  purpose/ABAC, short-lived access, redaction, expiry and audit.
- **INT-121 C13↔C17:** G1-G5, separate confidence axes, caps/calibration,
  coverage denominator, holes/conflicts/drop reasons render without collapse.
- **INT-122 C03/C06/C14/C16↔C17:** common correlation and stage events form an
  ordered run timeline with attempts, decisions, gaps and next action.
- **INT-123 C01↔C17:** canonical URNs, schema versions and compatibility generate
  valid OpenAPI/client/entity deep links and reject ambiguous identity.
- **INT-124 C18↔C17:** SSO/RBAC/ABAC/WAF/network/audit/SLO/alarms/runbooks/DR and
  no-payload telemetry controls pass for API, UI and export.
- **INT-125 Neptune/OpenSearch↔C17:** query bounds, replica/index versions,
  throttling, high-degree paths and lag behave per active-version policy.
- **INT-126 Browser↔C17:** supported browsers and assistive technologies pass
  search-to-lineage, review, timeline, error, stale and concurrent-edit flows.

## 17. Definition of Done

- OpenAPI 3.1 schemas, generated clients, API service, UI routes/components,
  query guards, auth/redaction, private cache, exports and telemetry are deployed.
- C17 P0 requirements and C17-CT-001 through C17-CT-012 pass in production-
  shaped graph/search/review/evidence/timeline infrastructure.
- INT-118 through INT-126 pass, including version races, dependency faults,
  authorization boundaries and browser/accessibility steel threads.
- Performance report proves two seconds p95 bounded one-hop traversal and search,
  quota, high-degree and degraded dependency behavior at approved scale.
- Threat model/security tests prove no arbitrary backend query, cross-domain
  leak, unsafe browser persistence, unauthorized export or projection mutation.
- Product/accessibility owners approve empty/error/stale/partial/conflict and
  confidence/coverage/review/timeline semantics.
- Dashboards, alerts, SLOs and runbooks are linked to release evidence; rollback
  preserves compatible API/UI and active approved graph access.

## 18. Implementation Notes

Approved repository targets:

    contracts/openapi/lineage-query-v1.yaml
    services/query-api/
    apps/lineage-web/
    packages/api-client/
    packages/ui-components/
    infra/lib/stacks/experience-stack.ts
    tests/contract/query-api/
    tests/integration/experience/
    tests/e2e/experience/
    tests/accessibility/
    tests/load/query/

Use TypeScript 5 for API composition, web application and IaC. Use a supported
React framework with server-side authorization and generated contract types.
Backend adapters expose typed bounded operations, never generic query strings.
Playwright covers browser steel threads; axe plus manual assistive-technology
evidence covers accessibility. Pin runtime/framework versions in the root
toolchain and software bill of materials.

Build order: OpenAPI/problem details; auth/version context; graph bounds; search
watermark; evidence/coverage; C15 review; timeline; exports; UI states and
accessibility; load/chaos/security. Feature flags may hide a UI route but must
not weaken API authorization, review policy, query bounds or version semantics.

## 19. Traceability

| Source decision | C17 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| Approved graph traversal/discovery | C17-FR-001-007/015/019-020 | C17-CT-001-005/011-012 | INT-118/123/125; functional/performance gates |
| Evidence/confidence/coverage/review | C17-FR-007-012/016 | C17-CT-005-007/010 | INT-119-121; review/privacy/accuracy gates |
| End-to-end visibility and timeline | C17-FR-013-014/018 | C17-CT-008/010 | INT-122/124; operational gate |
| Security/privacy/accessibility | C17-SEC-001-006, C17-FR-017-020 | C17-CT-007/009-012 | INT-124/126; security/privacy/experience gates |
| Query SLO/availability/scale | C17-NFR-001-005 | C17-CT-002/004/011-012 | INT-118/125; performance/resilience gates |


---

# 18-security-observability-operations-dr.md

# C18 Security, Observability, Operations, and Disaster Recovery PRD

## 1. Document Control

| Field | Value |
|---|---|
| Component | C18 |
| Status | Approved for implementation |
| Launch phase | Foundation controls before component deployment; full DR gate before enterprise rollout |
| Criticality | P0; cross-cutting trust, operability, reconciliation, and recovery boundary |
| Primary owner | Lineage platform security and reliability team |
| Required approvers | Security, privacy, architecture, SRE, compliance, data governance, finance, application platform |
| Upstream dependencies | Enterprise AWS Organizations, identity, networking, security, audit and incident platforms |
| Downstream dependencies | C01-C17 and every production environment |
| Authoritative sources | AWS architecture §§15-19; component package design; shared contracts/state model |

## 2. Purpose and Outcomes

C18 supplies the common security, privacy, telemetry, reconciliation, operating,
backup, rebuild, and disaster-recovery controls used by every lineage component.
It makes local component obligations deployable and testable while preserving
component ownership of business behavior and component-specific alarms.

Measurable outcomes:

- Policy-as-code proves account, IAM, ABAC, network, encryption, egress,
  retention, audit, no-payload and production runtime hard-deny controls before
  every deployment.
- Operators diagnose every trigger through active projection using one common
  correlation contract, actionable SLOs, alarms and linked runbooks without
  direct service-console archaeology.
- inventory-to-run reconciliation, deployment-to-lineage reconciliation,
  projection reconciliation and full-scan divergence identify every missing or
  inconsistent business effect and produce safe repair or escalation.
- Governed backup/restore and warm standby recovery prove a 15-minute RPO and
  four-hour RTO in a regional exercise with exact immutable-truth reconciliation.
- All security exceptions and operational waivers are scoped, owned, audited,
  automatically expiring, alerted before expiry and fail closed after expiry.

## 3. Scope and Non-Goals

### In scope

- Multi-account/Region environment topology, organization guardrails, IAM
  Identity Center federation, RBAC/ABAC, workload identity and separation.
- KMS/TLS, private networking, endpoint/resource policies, controlled egress,
  secret/credential lifecycle, vulnerability/supply-chain and no-payload rules.
- CloudTrail, S3 data events, immutable audit, retention/legal hold/deletion,
  security findings and incident evidence.
- Common metrics/logs/traces/audit/correlation, dashboards, SLOs, burn-rate
  alarms, synthetics, runbooks, on-call routing and cost allocation.
- Reconciliation, DLQ/archive/workflow redrive/replay governance, backup,
  restore, projection rebuild, Multi-AZ, cross-Region replication, warm standby,
  failover/failback, chaos and recovery exercises.

### Non-goals

- Redefining C01-C17 functional state machines, evidence meaning, approval
  policy, confidence, query behavior, or publication protocol.
- Granting direct production-console mutation as an ordinary operating path.
- Treating Neptune/OpenSearch snapshots as authoritative accepted lineage.
- Collecting production payload values or raw/reversible integration payloads
  for observability, debugging, analytics or incident response.
- Making a waiver permanent, global, ownerless or exempt from compensating
  controls and expiry.
- Claiming availability or recovery from untested service capability.

## 4. Actors and Use Cases

| Actor | Primary use case |
|---|---|
| Component engineer | Adopt paved-road identity/network/telemetry/audit constructs and local controls |
| Security/privacy engineer | Define policy-as-code, threat controls, findings and exception governance |
| SRE/on-call operator | Detect, diagnose, mitigate, redrive, reconcile, rebuild and recover |
| Incident commander | Coordinate security/availability event with immutable timeline and approvals |
| Auditor/compliance owner | Prove access, review, export, retention, legal hold and recovery evidence |
| FinOps owner | Attribute cost by application/domain/lane/analyzer/environment and enforce budgets |
| Application owner | Receive lineage/freshness/review impact without direct AWS console access |
| DR exercise lead | Activate warm standby, reconcile truth, cut traffic and fail back safely |

## 5. Component Boundary

### Owned behavior

- Reusable infrastructure/security/telemetry constructs, organization controls,
  common dashboards/alarms/runbook catalog, audit lake and exception registry.
- Reconciliation scheduler/framework, recovery orchestration and evidence
  capture; component repair commands remain typed, scoped and owner-approved.

### Inputs

- C01-C17 resource/identity/data classifications, permissions, metrics, events,
  state/watermarks/idempotency, SLOs, runbooks, backup and recovery hooks.
- Enterprise identity/ownership, organization policies, network/egress,
  security/audit/SIEM, incident/on-call and finance tag standards.

### Outputs

- Guardrailed accounts/environments, deploy-time evidence, roles/policies,
  telemetry/audit, findings/alarms/incidents, reconciliation reports/actions,
  backups/replicas, recovery/failback reports and cost/waiver records.

### Forbidden behavior

- A broad shared execution role, wildcard cross-account trust, long-lived source
  credential, public data-plane endpoint, unrestricted egress or shared KMS key
  across data classes/environments.
- Logging/tracing/auditing payload values, credentials, model prompt content,
  source spans beyond approved references, reversible fingerprints or sensitive
  metadata without purpose authorization.
- Automated repair that bypasses business preconditions, approval, fencing,
  idempotency, retention or immutable audit.
- Destructive replay/redrive/rebuild/failover without dry-run, bounded scope,
  expected state, approval and rollback/failback plan.
- Closing an alarm because data stopped arriving.

## 6. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| C18-FR-001 | C18 must deploy separate lineage control/compute, evidence/data, application/API, central observability/security and integration workload account boundaries, with production/nonproduction/environment isolation and AWS Organizations-scoped trust. | P0 |
| C18-FR-002 | Human access must federate through enterprise SSO/SCIM and IAM Identity Center with short sessions, phishing-resistant MFA for privileged roles, domain RBAC, sensitive-metadata ABAC and just-in-time approved elevation. | P0 |
| C18-FR-003 | Every workload must use a component/stage/environment-specific least-privilege role with short-lived credentials, explicit trust conditions, resource/tag/source constraints and no shared administrator execution role. | P0 |
| C18-FR-004 | Infrastructure must use private networking, private subnets and VPC endpoints/resource policies for supported AWS services; public ingress terminates only at approved WAF/API/identity boundaries and all other public data-plane access is blocked. | P0 |
| C18-FR-005 | Internet/enterprise SCM egress must pass an allowlisted proxy/firewall/DNS policy with destination, method, identity, bytes and outcome audit; analyzer jobs have no arbitrary internet or user-supplied destination access. | P0 |
| C18-FR-006 | Secrets Manager or an approved broker must issue/rotate/revoke short-lived source credentials; secrets must not enter source, images, workflow state, artifacts, logs, traces, caches or environment dumps. | P0 |
| C18-FR-007 | Data must use TLS in transit and KMS encryption at rest with keys separated by environment and data class, least-privilege key policy, rotation, monitored grants and tested key recovery/replication. | P0 |
| C18-FR-008 | C18 must enforce no production payload capture and no raw/reversible integration-test payload storage through schemas, validators, IAM/resource policies, AppConfig environment checks, sidecar attestation, scanning and deterministic quarantine/audit. | P0 |
| C18-FR-009 | Analyzer workspaces must be ephemeral/encrypted, prohibit persistence after job closure, scan outputs for secrets/prohibited data, and clean on success/failure/cancel/host interruption with verifiable lifecycle evidence. | P0 |
| C18-FR-010 | CloudTrail organization trails must capture management/configuration/access/review/export/administration events in a protected audit account; required S3 data events must capture evidence/manifest/label/export object access and changes. | P0 |
| C18-FR-011 | Audit records must be immutable, time-synchronized, centrally searchable, actor/purpose/resource/version/outcome/correlation complete, protected from workload deletion, retained by approved class and included in incident/legal hold. | P0 |
| C18-FR-012 | Retention policy must classify evidence, proposals, accepted manifests, labels, operational state, audit, logs, traces, exports, backups and projections; automate retention/legal hold/deletion and prove projections/caches do not outlive their source authorization. | P0 |
| C18-FR-013 | Every applicable event, artifact, log, metric, trace, audit and timeline stage must implement the common correlation contract: collectionRunId, applicationId, repositoryId, commitSha, artifactDigest, runtimeSessionId, proposalId, graphVersion, traceId, policyVersion and analyzerVersion; unknown fields are absent, never empty identity. | P0 |
| C18-FR-014 | The observability SDK/construct must emit structured redacted logs, OpenTelemetry/ADOT traces, CloudWatch embedded/business metrics and audit events with bounded cardinality, schema/version validation and sampling that never drops security/audit/business completion signals. | P0 |
| C18-FR-015 | C18 must provide service and end-to-end SLOs, multi-window burn-rate alarms, queue/workflow/data-quality/security/cost/capacity alarms, dependency-aware dashboards, synthetic steel threads and on-call routing with tested acknowledgements/escalation. | P0 |
| C18-FR-016 | Every actionable alarm must link an owner, severity, user/business impact, dashboard/query, typed runbook, safe command or workflow, verification, rollback/escalation and recent exercise; unowned/no-data alarms fail launch review. | P0 |
| C18-FR-017 | C18 must schedule inventory-to-run reconciliation comparing every inventory snapshot member/eligibility state with a visible collection decision/run, and classify missing/duplicate/stale/orphan outcomes without silently synthesizing success. | P0 |
| C18-FR-018 | C18 must schedule deployment-to-lineage reconciliation comparing every deployed artifact/environment decision, artifact-lineage binding, active accepted graph version and freshness, alerting/repairing missing or stale lineage including hotfix paths. | P0 |
| C18-FR-019 | Reconciliation must also compare triggers/queues/workflows/stage checkpoints/evidence/manifests/proposal state/active pointer/Neptune/OpenSearch watermark and scheduled full-scan divergence; repair requires expected state, idempotency, authorization and audit. | P0 |
| C18-FR-020 | DLQ redrive, EventBridge replay, Step Functions redrive, checkpoint resume and full reprocessing must support dry-run/count/sample, immutable operation ID, bounded filter/time range, compatibility precheck, rate/cost limit, duplicate-safe effects, cancellation and completion reconciliation. | P0 |
| C18-FR-021 | All production components must deploy Multi-AZ or stateless replacement patterns appropriate to their state, with health checks, capacity headroom, dependency circuit breaking and tested zone-failure behavior. | P0 |
| C18-FR-022 | The warm standby Region must continuously receive governed S3 cross-Region replication, required DynamoDB global/backup state, KMS/key policy, container/IaC artifacts and accepted-manifest/pointer recovery inputs; Neptune/OpenSearch remain rebuildable by validated strategy. | P0 |
| C18-FR-023 | Recovery must restore immutable S3 authority and required control state first, reconcile proposal/pointer/fencing/idempotency history, rebuild or restore Neptune/OpenSearch, verify exact counts/checksums/watermarks, then enable C17 traffic only through approved cutover. | P0 |
| C18-FR-024 | Regional failover/failback must use declared incident/approval, recovery point and data-loss assessment, DNS/traffic and write-fencing plan, communication, security validation, exact reconciliation, rollback criteria and immutable exercise/incident report. | P0 |
| C18-FR-025 | Backup/restore and warm-standby exercises must prove the 15-minute RPO and four-hour RTO at least quarterly for critical state and after material topology/schema/retention changes. | P0 |
| C18-FR-026 | Chaos tests must inject zone/Region, dependency, network, throttling, queue, worker, Kinesis, Neptune, OpenSearch, KMS, identity and observability faults and prove safe retry/incomplete/quarantine/fencing/rebuild behavior without truth loss. | P0 |
| C18-FR-027 | Resource tags and cost telemetry must attribute spend by component/application/domain/environment/lane/analyzer/workload type; budgets/anomaly alarms and per-run cost guardrails must stop optional work before critical fairness is lost. | P0 |
| C18-FR-028 | Security/operational waivers must name control, scope, owner, reason, risk, compensating control, approvers, creation and expiry; alerts begin before expiry and the waived behavior fails closed or is removed automatically at expiry. | P0 |
| C18-FR-029 | C18 must maintain tested incident, privacy breach, credential compromise, prohibited-payload, corrupt evidence, stale graph, backlog, dependency outage, cost excursion and regional recovery runbooks with evidence-preservation rules. | P0 |
| C18-FR-030 | Software supply chain controls must pin dependencies/images/actions, generate SBOM and provenance, sign/scan artifacts and IaC, block critical exploitable findings or record an expiring waiver, and preserve deploy attestation. | P0 |

### Non-functional requirements

| ID | Requirement | Priority |
|---|---|---|
| C18-NFR-001 | Critical security/audit/business completion events must reach the central account/search within five minutes p95 and must remain durable during workload account compromise or telemetry dependency degradation. | P0 |
| C18-NFR-002 | Reconciliation must cover 100 percent of in-scope inventory and deployment decisions daily, Tier-1 deployment decisions within five minutes, and report zero silent/unclassified discrepancies. | P0 |
| C18-NFR-003 | The platform must meet each component SLO and end-to-end capacity envelope while retaining 30 percent measured headroom or an approved autoscaling/reservation plan for critical paths. | P0 |
| C18-NFR-004 | Regional recovery must meet 15-minute RPO and four-hour RTO with exact accepted-manifest, decision, pointer, graph, search and audit reconciliation. | P0 |
| C18-NFR-005 | Security/operations control planes and central audit must be 99.99 percent available or fail components safely; loss of audit/auth/policy validation cannot silently permit a protected action. | P0 |

## 7. Data and Durable State

AccountEnvironmentRegistry records account/organizational unit/Region/
environment/data class, owners, network zones/endpoints, KMS keys, allowed
trust/egress, compliance profile, deployment version and last conformance result.

AccessPolicyBundle records RBAC roles, ABAC attributes, resource tags, trust/
permission boundaries/service control policies, schema/policy version, tests,
approval, deploy hash and effective time. WaiverRecord contains exact failed
control/resource/scope, risk, compensating controls, owner/approvers, alert and
hard expiry with immutable status history.

CorrelationEnvelope is the shared metadata subset carried across telemetry and
artifacts. TelemetrySchemaRegistry defines redaction, cardinality, retention,
required dimensions, audit/non-sampled classes and compatibility.

ReconciliationRun contains rule/version, source watermarks/checksums, scope,
expected/observed sets, discrepancies, classification, proposed/executed repair,
authorization, idempotency, evidence refs and closure. RedriveOperation contains
source/DLQ/archive/workflow filters, compatibility report, dry-run counts/sample,
rate/cost cap, execution/checkpoint/cancel/result and reconciliation.

RecoveryPlanVersion, BackupInventory, ReplicationWatermark, RecoveryExercise and
FailoverRecord preserve component/resource dependency order, recovery point,
restore/rebuild checksums, RPO/RTO timestamps, security validation, traffic/write
fencing, deviations, approvals, failback and corrective actions. C12/audit
storage retains immutable reports; operational indexes are reconstructable.

## 8. Interfaces and Contracts

- Infrastructure libraries expose approved account, role, KMS, private network,
  VPC endpoint, audit, telemetry, alarm, backup and tagging constructs; raw
  escape hatches require explicit security approval and expiring waiver.
- POST /v1/operations/reconciliations:run and GET reports accept named rule,
  immutable watermarks, scope, dry-run/repair mode, expected state and operation
  idempotency. Repair invokes component-owned typed APIs.
- POST /v1/operations/redrives:plan|execute|cancel and GET status implement the
  governed replay protocol; execution requires exact approved plan checksum.
- POST /v1/operations/rebuilds:plan|execute and recovery workflow interfaces
  accept resource/application scope, accepted source manifests, target Region,
  recovery point, expected current state and approvals.
- Security findings, audit events, alarms, incidents, reconciliation
  discrepancies, waiver expiry, cost anomaly, backup/replication and recovery
  events use versioned EventEnvelope types and immutable evidence references.
- Component health/SLO APIs expose readiness, dependency status, watermark and
  safe operator action; a health endpoint never performs repair.

Compatibility changes to IAM meaning, audit/correlation fields, retention,
recovery ordering, redrive filters, reconciliation semantics or encryption
require versioned migration, dual-read/validation where needed and rollback.

## 9. Processing and State Model

Deployment/control validation:

1. Generate IaC/policies/contracts and run static/schema/unit policy tests.
2. Deploy to ephemeral/nonproduction account and run permission/network/egress/
   encryption/audit/no-payload/backup/fault tests.
3. Produce signed conformance report and evaluate unexpired scoped waivers.
4. Promote immutable artifact; continuously detect configuration drift and
   quarantine/rollback/incident on unauthorized control weakening.

Reconciliation state:

    PLANNED -> DRY_RUN -> APPROVED -> EXECUTING -> VERIFYING -> CLOSED
                            |              |            |
                            +-> REJECTED   +-> PAUSED   +-> FAILED

Every discrepancy remains OPEN, REPAIRING, VERIFIED_CLOSED, ACCEPTED_EXCEPTION
with expiry, or ESCALATED. Absence of an observed record is never success.

Regional recovery state:

    NORMAL -> INCIDENT_DECLARED -> RECOVERY_POINT_SELECTED -> RESTORING_TRUTH
           -> RESTORING_CONTROL -> REBUILDING_PROJECTIONS -> VERIFYING
           -> TRAFFIC_CUTOVER -> RECOVERED -> FAILBACK_PLANNED -> NORMAL

Each transition requires expected state, actor/automation identity, immutable
plan/checksum, evidence and abort criteria. Only current Region writer/fencing
authority may mutate control state. Failback is a new recovery operation.

## 10. Failure Semantics

| Code | Class | Required behavior |
|---|---|---|
| POLICY_OR_CONTROL_NONCONFORMANT | DETERMINISTIC_INVALID | Block deployment/action; exact finding/owner |
| AUTHORIZATION_OR_ABAC_DENIED | DETERMINISTIC_INVALID security | Deny/audit without resource existence leak |
| PROHIBITED_DATA_DETECTED | DETERMINISTIC_INVALID privacy | Quarantine, revoke access/key/session, incident; no retry |
| AUDIT_OR_POLICY_DEPENDENCY_UNAVAILABLE | INCOMPLETE/security | Fail protected writes closed; durable local buffer where approved |
| TELEMETRY_PIPELINE_DEGRADED | TRANSIENT/INCOMPLETE | Preserve audit/completion signals, alarm on gaps/no data |
| RECONCILIATION_DISCREPANCY | INCOMPLETE/CONFLICT | Keep open; safe repair or escalation with evidence |
| REDRIVE_COMPATIBILITY_OR_SCOPE_INVALID | DETERMINISTIC_INVALID | Do not execute; new plan required |
| REDRIVE_PARTIAL_OR_CANCELLED | INCOMPLETE | Stop safely; checkpoint and reconcile every selected item |
| BACKUP_OR_REPLICATION_LAG | INCOMPLETE | RPO risk alarm; block unsafe recovery claim |
| RESTORE_OR_REBUILD_MISMATCH | CONFLICT/INCOMPLETE | No traffic/write cutover; retain prior safe state |
| REGIONAL_FAILOVER_DEPENDENCY_FAILED | TRANSIENT | Follow bounded alternate/rollback; update recovery clock |
| WAIVER_EXPIRED | DETERMINISTIC_INVALID | Fail closed/remove exception and alert owner |

Retries use bounded exponential backoff/jitter only for transient errors and
retain operation identity. Deterministic/privacy failures quarantine. Recovery
never changes immutable evidence to make reconciliation pass.

## 11. Security and Privacy

| ID | Requirement | Priority |
|---|---|---|
| C18-SEC-001 | Organization service control policies, permission boundaries, resource policies and CI policy-as-code must deny leaving approved Regions/accounts, disabling central audit/security, public evidence/projection access, unencrypted storage and production runtime evidence enablement. | P0 |
| C18-SEC-002 | Cross-account access must require explicit organization/account/principal/tag/external-ID or source conditions, short-lived sessions and narrow actions/resources; confused-deputy, wildcard trust and lateral-role tests must fail. | P0 |
| C18-SEC-003 | Break-glass access must require separate vaulted identity, MFA, incident/ticket, time-bound approval, session recording/audit, automatic revocation and post-use review; it may not bypass Object Lock or fabricate approval. | P0 |
| C18-SEC-004 | Security detection must cover anomalous data access/export, disabled controls, public/cross-account policy, KMS/secret misuse, exfiltration/egress, role escalation, prohibited runtime evidence and audit deletion attempts with tested incident routing. | P0 |
| C18-SEC-005 | CloudTrail, S3 data events, configuration snapshots, security findings and recovery evidence must be delivered to a workload-inaccessible immutable store with integrity validation and approved retention/legal hold. | P0 |
| C18-SEC-006 | Logs, metrics, traces, alarms, dashboards, tickets and cost dimensions must use identifiers/low-cardinality metadata only; automated scanners must block known secrets, raw values, sensitive spans and prohibited model context. | P0 |
| C18-SEC-007 | Backup/replica/recovery accounts and keys must enforce the same or stronger classification, retention, ABAC and deletion controls as primary data, and recovery must revalidate access before traffic. | P0 |
| C18-SEC-008 | Vulnerability and threat-model reviews must cover every trust boundary and release; critical exploitable findings block promotion unless risk acceptance meets C18 waiver controls. | P0 |

## 12. Scale, Performance, and Availability

- Capacity models include 10,000 repositories, 10,000 daily deployment
  decisions, baseline/release bursts, telemetry volume, audit data events,
  reconciliation full joins, backups/replication and Region rebuild traffic.
- Queue/worker/reserved-capacity fairness protects Tier-1 and security/audit
  processing. Optional backfill, Lane C, exports and analytics shed first.
- Central telemetry uses bounded-cardinality labels and durable buffering;
  audit is independent from ordinary log sampling/retention.
- Primary Region is Multi-AZ. Warm standby resources, quotas, images, policies,
  endpoints, DNS/certificates, secrets and key grants are continuously checked,
  not created for the first time during an incident.
- S3 immutable truth is replicated with retention/Object Lock requirements.
  DynamoDB strategy is table-specific to conflict semantics. Neptune and
  OpenSearch recovery may restore or rebuild only after measured benchmarks.
- Cost alarms cannot terminate authoritative writes mid-transaction. They may
  pause new optional work through controlled scheduler policies.

## 13. Observability

| ID | Signal | Dimensions / alarm |
|---|---|---|
| C18-OBS-001 | End-to-end stage latency/success/incomplete/failure | component/stage/domain/priority/error; SLO burn |
| C18-OBS-002 | Queue age/depth/throughput/DLQ and workflow retry/redrive | queue/workflow/priority; fairness/backlog |
| C18-OBS-003 | Inventory/run/deployment/binding/graph/search reconciliation | rule/domain/status/age; any Tier-1 gap |
| C18-OBS-004 | Evidence/manifest/proposal/pointer/replication checksums and lag | store/Region/class; truth/RPO alarm |
| C18-OBS-005 | IAM/ABAC/egress/KMS/secrets/audit/security findings | account/control/severity; incident routing |
| C18-OBS-006 | Prohibited-data scan and production hard-deny attempts | source/stage/environment; immediate security alarm |
| C18-OBS-007 | Backup/restore/rebuild/failover phase and RPO/RTO clock | resource/Region/exercise; recovery escalation |
| C18-OBS-008 | Neptune/OpenSearch/Batch/Kinesis/DynamoDB/S3/API capacity | service/component/operation; saturation |
| C18-OBS-009 | Cost and budget/anomaly per run/application/lane/analyzer | owner/environment/workload; budget action |
| C18-OBS-010 | Waiver/control/runbook/exercise age and expiry | owner/control/severity; governance escalation |

Golden dashboards include platform overview, trigger-to-query SLO, intake/
queues, collection/evidence, trust/review/publication, query/projection,
security/privacy, reconciliation, DR/replication and cost. Every panel names
source/query/units/owner and no-data meaning.

## 14. Acceptance Criteria

| ID | Given / When / Then |
|---|---|
| C18-AC-001 | Given a proposed stack, when policy-as-code and deployed probes run, then account/IAM/ABAC/network/KMS/egress/audit/no-payload controls pass or promotion is blocked with an expiring waiver path. |
| C18-AC-002 | Given cross-account, privilege-escalation, public-access or exfiltration attempts, when exercised, then all are denied, centrally detected/audited and routed to the tested response. |
| C18-AC-003 | Given a representative trigger, when it reaches active query, then the common correlation contract joins all applicable stages/artifacts/telemetry/audit without sensitive content. |
| C18-AC-004 | Given missing inventory run, deployment binding, evidence, proposal, pointer or projection watermark, when reconciliation runs, then the gap stays visible and a safe idempotent repair/escalation is recorded. |
| C18-AC-005 | Given duplicate/out-of-order poison messages and dependency outage, when redrive/replay executes, then compatibility, bounds, business idempotency, checkpoint, cancellation and final reconciliation pass. |
| C18-AC-006 | Given prohibited payload/secret evidence, when validator/scanner detects it, then data is quarantined, access/session is contained, audit/incident fires and retry cannot republish it. |
| C18-AC-007 | Given zone/component faults, when chaos executes, then local SLO/failure semantics, prior approved availability, alarm and runbook actions pass without immutable truth loss. |
| C18-AC-008 | Given primary Region loss, when warm standby recovery runs, then authoritative state is restored/reconciled, projections rebuilt/verified, traffic cut over within four-hour RTO and data loss is within 15-minute RPO. |
| C18-AC-009 | Given an expiring waiver, when alert/expiry occurs, then owners are notified and nonconforming behavior fails closed or is removed with immutable history. |

## 15. Component Test Matrix

| ID | Type | Fixture / fault | Action | Expected result | Evidence |
|---|---|---|---|---|---|
| C18-CT-001 | Policy-as-code | Valid/invalid account, IAM, ABAC, KMS, network, audit stacks | Synthesize/scan/deploy probes | Invalid blocked; valid least privilege proven | Signed conformance |
| C18-CT-002 | Cross-account/security | External org, confused deputy, role chain, tag spoof, break-glass | Assume/access/escalate | Denied except approved recorded break-glass | CloudTrail/finding |
| C18-CT-003 | Exfiltration/privacy | Public S3, arbitrary egress, DNS tunnel, secret/raw payload/log injection | Attempt writes/transfers | Denied/quarantined/detected; no prohibited sink data | Scan/incident |
| C18-CT-004 | Audit completeness | Access/review/export/admin/config/data actions | Execute matrix | Required CloudTrail/S3 data events correlate and are immutable | Audit coverage |
| C18-CT-005 | Telemetry/alarms | Golden trigger plus dropped/no-data/high-cardinality/PII signal | Observe/fault | Correlation complete; prohibited data blocked; alarm/runbook works | Trace/dashboard |
| C18-CT-006 | Reconciliation | Missing/duplicate/stale/orphan inventory, run, deploy, binding, pointer, watermark | Dry-run/repair | Every discrepancy classified; safe exact repair or escalation | Reconcile report |
| C18-CT-007 | Redrive/replay | DLQ/archive/workflow duplicates, poison, old schema, cancellation | Plan/execute | Compatibility/bounds/idempotency/checkpoints/reconciliation | Operation report |
| C18-CT-008 | Dependency/zone chaos | IAM/KMS/S3/DDB/Kinesis/Neptune/OpenSearch/Batch/telemetry fault | Run steel threads | Correct transient/incomplete/quarantine/fence behavior | Chaos/incident |
| C18-CT-009 | Backup/rebuild | Deleted/corrupt control/projections with immutable manifests | Restore/rebuild | Exact checksums/counts/pointers/watermarks before traffic | Restore report |
| C18-CT-010 | Regional DR | Primary Region unavailable at random recovery point | Activate warm standby/failback | 15-minute RPO/four-hour RTO and exact truth reconciliation | Exercise record |
| C18-CT-011 | Cost/load | 10k trigger/baseline/deploy profile and anomaly | Load/attribute/throttle optional | SLO/fairness/headroom and cost attribution/guardrails pass | Load/FinOps |
| C18-CT-012 | Waiver/supply chain | Expired waiver, unsigned image, critical CVE, drift | Promote/run expiry | Block/fail closed/alert; immutable evidence | Pipeline/audit |

## 16. Integration Obligations

- **INT-127 C01-C03↔C18:** contract policy, adapter/intake identity, network,
  secret/egress, audit, queue/DLQ and trigger reconciliation controls pass.
- **INT-128 C04-C06↔C18:** classification/UNKNOWN, context/determinants, workflow
  fairness/retry/redrive and run reconciliation are visible and recoverable.
- **INT-129 C07-C10↔C18:** native/deterministic/agentic/opaque compute roles,
  ephemeral workspaces, egress, Bedrock bounds, privacy scans, cost and faults pass.
- **INT-130 C11↔C18:** integration-only AppConfig/IAM/resource/attestation hard-
  deny, metadata schema, sequence/completeness, cleanup and incident paths pass.
- **INT-131 C12↔C18:** Object Lock/KMS/retention/legal hold/data audit/CRR,
  checksum/restore and cache/projection authority boundaries pass.
- **INT-132 C13-C15↔C18:** trust/corpus/proposal/review RBAC/ABAC/separation,
  immutable audit, backlog SLO, waiver/retention and recovery pass.
- **INT-133 C16↔C18:** publication lease/fence/pointer, Neptune/OpenSearch
  capacity/alarms/reconciliation/rebuild and stale-worker chaos pass.
- **INT-134 C17↔C18:** identity/WAF/private path, evidence/export ABAC/audit,
  query SLO, UI synthetic, stale projection and recovery behavior pass.
- **INT-135 External systems↔C18:** SCM/test/deploy/catalog/native sources use
  controlled trust/credentials/egress, outage/circuit-break and audit contracts.
- **INT-136 Audit/SIEM/incident↔C18:** management/data/application events,
  findings, alarm routing, evidence preservation and response exercises pass.
- **INT-137 Primary↔warm standby:** replication, backup/key/IaC/quota readiness,
  restore/rebuild/cutover/failback prove RPO/RTO and exact reconciliation.
- **INT-138 Finance/governance↔C18:** tags/cost attribution/budgets, control
  conformance, waiver approval/expiry and evidence retention pass.

## 17. Definition of Done

- Account/environment topology, reusable security/telemetry constructs, central
  audit, private networking, identity, policies, keys, backups, replication,
  dashboards/alarms, reconciliation/redrive and recovery workflows are deployed.
- C18 P0 requirements and C18-CT-001 through C18-CT-012 pass with signed,
  immutable, production-shaped evidence; no launch-critical permanent waiver.
- INT-127 through INT-138 pass together with every component's local security,
  observability, failure, scale and recovery obligations.
- Threat model, privacy assessment and policy tests prove cross-account denial,
  no-payload/production hard-deny, controlled egress and immutable audit.
- Reconciliation covers 100 percent of inventory/deployment scope and proves
  duplicate/replay/redrive safe closure; no silent discrepancy remains.
- Zone/dependency chaos and regional warm standby/failback exercise meet
  component SLOs, 15-minute RPO and four-hour RTO with exact truth/projection
  reconciliation and corrective-action closure.
- Every alarm has an owned tested runbook; every dashboard/no-data state,
  synthetic, backup, replication, cost guardrail and waiver expiry is monitored.

## 18. Implementation Notes

Approved repository targets:

    infra/lib/constructs/security/
    infra/lib/constructs/observability/
    infra/lib/stacks/audit-stack.ts
    infra/lib/stacks/security-stack.ts
    infra/lib/stacks/operations-stack.ts
    infra/lib/stacks/dr-stack.ts
    services/reconciliation-controller/
    services/operations-api/
    workflows/redrive/
    workflows/regional-recovery/
    packages/telemetry-contract/
    policies/
    dashboards/
    docs/runbooks/
    tests/security/
    tests/operations/
    tests/chaos/
    tests/dr/

Use AWS CDK with TypeScript 5 for infrastructure/policy composition, TypeScript
for control APIs and Python 3.12 for large reconciliation/report workers. Use
OpenTelemetry/ADOT, CloudWatch and X-Ray for operational telemetry, CloudTrail
plus protected S3 for audit, and the enterprise security/SIEM/on-call systems.
Policy tests run locally and against deployed ephemeral accounts; DR tests use
isolated production-shaped accounts/Regions.

Build order: account/audit/key/network foundation; workload identity/ABAC and
secrets/egress; telemetry/correlation and alarms/runbooks; retention/backup;
reconciliation/redrive; Multi-AZ/chaos; warm standby/recovery/failback; cost and
waiver governance. Components cannot promote past their phase gate until their
local controls integrate with C18 and produce retained evidence.

## 19. Traceability

| Source decision | C18 requirements | Component evidence | Integration/launch evidence |
|---|---|---|---|
| Account/IAM/network/encryption/privacy | C18-FR-001-012/030, C18-SEC-001-008 | C18-CT-001-004/012 | INT-127-136/138; security/privacy gates |
| Correlation/telemetry/SLO/runbooks | C18-FR-013-016/027/029 | C18-CT-005/008/011 | INT-127-136/138; operational/performance gates |
| Reconciliation/redrive/replay | C18-FR-017-020 | C18-CT-006-007 | INT-127-135; functional/resilience gates |
| Multi-AZ/backup/warm standby/DR | C18-FR-021-026, C18-NFR-004 | C18-CT-008-010 | INT-131/133/134/137; resilience gate |
| Cost, waiver and supply chain | C18-FR-027-030 | C18-CT-011-012 | INT-129/138; governance gate |


---

# README.md

# AWS Lineage Collection Component PRDs

**Package status:** Complete and mechanically validated implementation specification
**Scope:** Approved end-to-end AWS lineage collection platform
**Design date:** 2026-08-02

This package converts the approved lineage architecture into product and test
contracts that a coding agent can implement without reconstructing behavior
from service diagrams. The component boundary is a product capability, not an
AWS service. Shared contracts define how independently implemented components
compose into one governed application.

## Authoritative Sources

Use this order when requirements appear to disagree:

1. [Component package design](../plans/2026-08-02-lineage-component-prd-package-design.md).
2. [Approved AWS architecture](../plans/2026-08-01-aws-lineage-collection-architecture-design.md).
3. Element-level lineage v2 for Lane A/B/C analysis semantics.
4. [Throughline platform PRD](../../deliverables/Throughline-OpenLineage-Platform-PRD.md) for user journeys and OpenLineage product language.

The element-level document's 70-repository estate is the pilot cohort. The
platform capacity and launch tests remain sized for 10,000 repositories and at
least 10,000 deployed-artifact decisions per day. AWS EventBridge, SQS, Step
Functions, Batch, Kinesis, S3, DynamoDB, Neptune, and OpenSearch remain the
selected initial architecture.

## How to Use This Package

- A coding agent starts with [system context](00-system-context-and-architecture.md), [contracts](shared/contract-catalog.md), [state and errors](shared/state-and-error-model.md), and the [implementation sequence](shared/implementation-sequence.md).
- An owner implementing one component reads its PRD, then follows every linked
  interface and integration test before writing code.
- QA starts with [test strategy and fixtures](shared/test-strategy-and-fixtures.md), [dependency tests](shared/dependency-and-integration-matrix.md), and [end-to-end acceptance](shared/end-to-end-acceptance-tests.md).
- Product and architecture use [traceability](shared/requirements-traceability-matrix.md) to audit scope and launch evidence.
- Security and operations read every component's local controls plus C18; C18
  does not replace local least-privilege, telemetry, or recovery requirements.

## Component PRDs

| ID | Component | PRD |
|---|---|---|
| C01 | Canonical contracts, URNs, and identity resolution | [C01](01-canonical-contracts-and-identity.md) |
| C02 | Source adapters and repository inventory | [C02](02-source-adapters-and-inventory.md) |
| C03 | Event intake, normalization, and priority queues | [C03](03-event-intake-and-queues.md) |
| C04 | Repository eligibility and substrate routing | [C04](04-eligibility-and-substrate-routing.md) |
| C05 | Application context, dependency, and determinant indexes | [C05](05-context-dependency-and-determinants.md) |
| C06 | Workflow orchestration and workload scheduling | [C06](06-orchestration-and-scheduling.md) |
| C07 | Lane B native lineage collectors | [C07](07-lane-b-native-collectors.md) |
| C08 | Lane A deterministic analyzers | [C08](08-lane-a-deterministic-analyzers.md) |
| C09 | Lane A agentic residual resolver | [C09](09-lane-a-agentic-resolver.md) |
| C10 | Lane C opaque-substrate collector | [C10](10-lane-c-opaque-collector.md) |
| C11 | Integration runtime session controller and sidecar | [C11](11-runtime-session-and-sidecar.md) |
| C12 | Immutable evidence store and analysis cache | [C12](12-evidence-store-and-cache.md) |
| C13 | Reconciliation, verification, and two-axis confidence | [C13](13-reconciliation-verification-confidence.md) |
| C14 | CI drift, artifact binding, and freshness | [C14](14-ci-artifact-binding-and-freshness.md) |
| C15 | Proposal, human review, and calibration corpus | [C15](15-proposal-review-and-corpus.md) |
| C16 | Fenced publication and graph/search projections | [C16](16-publication-and-projections.md) |
| C17 | Query APIs, discovery, review UI, and run timeline | [C17](17-query-api-review-ui-and-timeline.md) |
| C18 | Security, observability, operations, and disaster recovery | [C18](18-security-observability-operations-dr.md) |

## Shared Specifications

- [Contract catalog](shared/contract-catalog.md)
- [State and error model](shared/state-and-error-model.md)
- [Dependency and integration matrix](shared/dependency-and-integration-matrix.md)
- [Test strategy and canonical fixtures](shared/test-strategy-and-fixtures.md)
- [End-to-end acceptance tests](shared/end-to-end-acceptance-tests.md)
- [Requirements traceability](shared/requirements-traceability-matrix.md)
- [Implementation sequence](shared/implementation-sequence.md)
- [Coding-agent handoff](shared/coding-agent-handoff.md)

## Global Conventions

- `must` and `must not` are normative; `may` identifies optional behavior.
- P0 is required for launch. P1 is a planned post-launch capability with an
  explicit safe launch behavior. P2 is an optimization or research item.
- All asynchronous deliveries are duplicateable. Business effects are
  idempotent by immutable, event-type-specific identity.
- Large payloads move by immutable S3 URI plus checksum, never through workflow
  state.
- Structural and derivational confidence are independent. Runtime execution
  cannot prove a transformation, and a single numeric confidence is prohibited.
- Evidence, proposals, accepted manifests, reviewer labels, and audit records
  are immutable. Corrections produce new versions.
- Neptune and OpenSearch are rebuildable projections. Accepted S3 manifests
  and the fenced active pointer define approved state.
- Missing, stale, conflicting, incomplete, excluded, or unresolved work is
  visible and attributable; no component may silently discard it.

## Package Completion Rule

The package is complete only when all 18 PRDs and shared specifications exist;
every P0 requirement maps to a component test, an integration test, a phase
gate, and retained evidence; all producer-consumer boundaries have positive and
failure-path tests; all mandatory steel threads have exact pass rules; and the
documentation validator plus the existing repository tests pass.

## Validated Package Inventory

- 18 component PRDs with all 19 mandatory sections.
- 585 P0 functional, nonfunctional, security, and observability requirements.
- 216 component test definitions (12 per component).
- 138 producer-consumer integration obligations, each with six mandatory paths.
- 14 end-to-end steel threads covering functional, accuracy, privacy, security,
  resilience, recovery, accessibility, and enterprise-scale launch gates.
- Eight shared specifications for contracts, state/errors, integrations,
  fixtures, E2E acceptance, traceability, build sequence, and coding-agent handoff.

Run the current repository validation with:

    python3 -m unittest discover -s tests -v


---

